package com.eospy.util;

public class Point3D
{
  public double x;
  public double y;
  public double z;
  
  public Point3D(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    this.x = paramDouble1;
    this.y = paramDouble2;
    this.z = paramDouble3;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    do
    {
      return true;
      if (paramObject == null) {
        return false;
      }
      if (getClass() != paramObject.getClass()) {
        return false;
      }
      paramObject = (Point3D)paramObject;
      if (Double.doubleToLongBits(this.x) != Double.doubleToLongBits(((Point3D)paramObject).x)) {
        return false;
      }
      if (Double.doubleToLongBits(this.y) != Double.doubleToLongBits(((Point3D)paramObject).y)) {
        return false;
      }
    } while (Double.doubleToLongBits(this.z) == Double.doubleToLongBits(((Point3D)paramObject).z));
    return false;
  }
  
  public int hashCode()
  {
    long l = Double.doubleToLongBits(this.x);
    int i = (int)(l >>> 32 ^ l);
    l = Double.doubleToLongBits(this.y);
    int j = (int)(l >>> 32 ^ l);
    l = Double.doubleToLongBits(this.z);
    return ((i + 31) * 31 + j) * 31 + (int)(l >>> 32 ^ l);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\util\Point3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */