package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.design.R.id;
import android.support.design.R.style;
import android.support.design.R.styleable;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;

public class CollapsingToolbarLayout
  extends FrameLayout
{
  private static final int SCRIM_ANIMATION_DURATION = 600;
  private final CollapsingTextHelper mCollapsingTextHelper = new CollapsingTextHelper(this);
  private Drawable mContentScrim;
  private int mCurrentOffset;
  private View mDummyView;
  private int mExpandedMarginBottom;
  private int mExpandedMarginLeft;
  private int mExpandedMarginRight;
  private int mExpandedMarginTop;
  private WindowInsetsCompat mLastInsets;
  private AppBarLayout.OnOffsetChangedListener mOnOffsetChangedListener;
  private boolean mRefreshToolbar = true;
  private int mScrimAlpha;
  private ValueAnimatorCompat mScrimAnimator;
  private boolean mScrimsAreShown;
  private Drawable mStatusBarScrim;
  private final Rect mTmpRect = new Rect();
  private Toolbar mToolbar;
  private int mToolbarId;
  
  public CollapsingToolbarLayout(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public CollapsingToolbarLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public CollapsingToolbarLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mCollapsingTextHelper.setExpandedTextVerticalGravity(80);
    this.mCollapsingTextHelper.setTextSizeInterpolator(AnimationUtils.DECELERATE_INTERPOLATOR);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.CollapsingToolbarLayout, paramInt, R.style.Widget_Design_CollapsingToolbar);
    paramInt = paramContext.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMargin, 0);
    this.mExpandedMarginBottom = paramInt;
    this.mExpandedMarginRight = paramInt;
    this.mExpandedMarginTop = paramInt;
    this.mExpandedMarginLeft = paramInt;
    if (ViewCompat.getLayoutDirection(this) == 1)
    {
      paramInt = i;
      if (paramContext.hasValue(R.styleable.CollapsingToolbarLayout_expandedTitleMarginStart))
      {
        i = paramContext.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMarginStart, 0);
        if (paramInt == 0) {
          break label313;
        }
        this.mExpandedMarginRight = i;
      }
      label140:
      if (paramContext.hasValue(R.styleable.CollapsingToolbarLayout_expandedTitleMarginEnd))
      {
        i = paramContext.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMarginEnd, 0);
        if (paramInt == 0) {
          break label322;
        }
        this.mExpandedMarginLeft = i;
      }
    }
    for (;;)
    {
      if (paramContext.hasValue(R.styleable.CollapsingToolbarLayout_expandedTitleMarginTop)) {
        this.mExpandedMarginTop = paramContext.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMarginTop, 0);
      }
      if (paramContext.hasValue(R.styleable.CollapsingToolbarLayout_expandedTitleMarginBottom)) {
        this.mExpandedMarginBottom = paramContext.getDimensionPixelSize(R.styleable.CollapsingToolbarLayout_expandedTitleMarginBottom, 0);
      }
      paramInt = paramContext.getResourceId(R.styleable.CollapsingToolbarLayout_expandedTitleTextAppearance, R.style.TextAppearance_AppCompat_Title);
      this.mCollapsingTextHelper.setExpandedTextAppearance(paramInt);
      paramInt = paramContext.getResourceId(R.styleable.CollapsingToolbarLayout_collapsedTitleTextAppearance, R.style.TextAppearance_AppCompat_Widget_ActionBar_Title);
      this.mCollapsingTextHelper.setCollapsedTextAppearance(paramInt);
      setContentScrim(paramContext.getDrawable(R.styleable.CollapsingToolbarLayout_contentScrim));
      setStatusBarScrim(paramContext.getDrawable(R.styleable.CollapsingToolbarLayout_statusBarScrim));
      this.mToolbarId = paramContext.getResourceId(R.styleable.CollapsingToolbarLayout_toolbarId, -1);
      paramContext.recycle();
      setWillNotDraw(false);
      ViewCompat.setOnApplyWindowInsetsListener(this, new OnApplyWindowInsetsListener()
      {
        public WindowInsetsCompat onApplyWindowInsets(View paramAnonymousView, WindowInsetsCompat paramAnonymousWindowInsetsCompat)
        {
          CollapsingToolbarLayout.access$002(CollapsingToolbarLayout.this, paramAnonymousWindowInsetsCompat);
          CollapsingToolbarLayout.this.requestLayout();
          return paramAnonymousWindowInsetsCompat.consumeSystemWindowInsets();
        }
      });
      return;
      paramInt = 0;
      break;
      label313:
      this.mExpandedMarginLeft = i;
      break label140;
      label322:
      this.mExpandedMarginRight = i;
    }
  }
  
  private void animateScrim(int paramInt)
  {
    ensureToolbar();
    if (this.mScrimAnimator == null)
    {
      this.mScrimAnimator = ViewUtils.createAnimator();
      this.mScrimAnimator.setDuration(600);
      this.mScrimAnimator.setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
      this.mScrimAnimator.setUpdateListener(new ValueAnimatorCompat.AnimatorUpdateListener()
      {
        public void onAnimationUpdate(ValueAnimatorCompat paramAnonymousValueAnimatorCompat)
        {
          CollapsingToolbarLayout.this.setScrimAlpha(paramAnonymousValueAnimatorCompat.getAnimatedIntValue());
        }
      });
    }
    for (;;)
    {
      this.mScrimAnimator.setIntValues(this.mScrimAlpha, paramInt);
      this.mScrimAnimator.start();
      return;
      if (this.mScrimAnimator.isRunning()) {
        this.mScrimAnimator.cancel();
      }
    }
  }
  
  private void ensureToolbar()
  {
    if (!this.mRefreshToolbar) {
      return;
    }
    Object localObject2 = null;
    Object localObject3 = null;
    int i = 0;
    int j = getChildCount();
    Object localObject1 = localObject3;
    View localView;
    if (i < j)
    {
      localView = getChildAt(i);
      localObject1 = localObject2;
      if (!(localView instanceof Toolbar)) {
        break label143;
      }
      if (this.mToolbarId == -1) {
        break label153;
      }
      if (this.mToolbarId == localView.getId()) {
        localObject1 = (Toolbar)localView;
      }
    }
    else
    {
      label73:
      localObject3 = localObject1;
      if (localObject1 == null) {
        localObject3 = localObject2;
      }
      if (localObject3 == null) {
        break label162;
      }
      this.mToolbar = ((Toolbar)localObject3);
      this.mDummyView = new View(getContext());
      this.mToolbar.addView(this.mDummyView, -1, -1);
    }
    for (;;)
    {
      this.mRefreshToolbar = false;
      return;
      localObject1 = localObject2;
      if (localObject2 == null) {
        localObject1 = (Toolbar)localView;
      }
      label143:
      i += 1;
      localObject2 = localObject1;
      break;
      label153:
      localObject1 = (Toolbar)localView;
      break label73;
      label162:
      this.mToolbar = null;
      this.mDummyView = null;
    }
  }
  
  private static ViewOffsetHelper getViewOffsetHelper(View paramView)
  {
    ViewOffsetHelper localViewOffsetHelper2 = (ViewOffsetHelper)paramView.getTag(R.id.view_offset_helper);
    ViewOffsetHelper localViewOffsetHelper1 = localViewOffsetHelper2;
    if (localViewOffsetHelper2 == null)
    {
      localViewOffsetHelper1 = new ViewOffsetHelper(paramView);
      paramView.setTag(R.id.view_offset_helper, localViewOffsetHelper1);
    }
    return localViewOffsetHelper1;
  }
  
  private void hideScrim()
  {
    if (this.mScrimsAreShown)
    {
      if ((!ViewCompat.isLaidOut(this)) || (isInEditMode())) {
        break label32;
      }
      animateScrim(0);
    }
    for (;;)
    {
      this.mScrimsAreShown = false;
      return;
      label32:
      setScrimAlpha(0);
    }
  }
  
  private void setScrimAlpha(int paramInt)
  {
    if (paramInt != this.mScrimAlpha)
    {
      if ((this.mContentScrim != null) && (this.mToolbar != null)) {
        ViewCompat.postInvalidateOnAnimation(this.mToolbar);
      }
      this.mScrimAlpha = paramInt;
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  private void showScrim()
  {
    if (!this.mScrimsAreShown)
    {
      if ((!ViewCompat.isLaidOut(this)) || (isInEditMode())) {
        break label34;
      }
      animateScrim(255);
    }
    for (;;)
    {
      this.mScrimsAreShown = true;
      return;
      label34:
      setScrimAlpha(255);
    }
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public void draw(Canvas paramCanvas)
  {
    super.draw(paramCanvas);
    ensureToolbar();
    if ((this.mToolbar == null) && (this.mContentScrim != null) && (this.mScrimAlpha > 0))
    {
      this.mContentScrim.mutate().setAlpha(this.mScrimAlpha);
      this.mContentScrim.draw(paramCanvas);
    }
    this.mCollapsingTextHelper.draw(paramCanvas);
    if ((this.mStatusBarScrim != null) && (this.mScrimAlpha > 0)) {
      if (this.mLastInsets == null) {
        break label139;
      }
    }
    label139:
    for (int i = this.mLastInsets.getSystemWindowInsetTop();; i = 0)
    {
      if (i > 0)
      {
        this.mStatusBarScrim.setBounds(0, -this.mCurrentOffset, getWidth(), i - this.mCurrentOffset);
        this.mStatusBarScrim.mutate().setAlpha(this.mScrimAlpha);
        this.mStatusBarScrim.draw(paramCanvas);
      }
      return;
    }
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong)
  {
    ensureToolbar();
    if ((paramView == this.mToolbar) && (this.mContentScrim != null) && (this.mScrimAlpha > 0))
    {
      this.mContentScrim.mutate().setAlpha(this.mScrimAlpha);
      this.mContentScrim.draw(paramCanvas);
    }
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  protected LayoutParams generateDefaultLayoutParams()
  {
    return new LayoutParams(super.generateDefaultLayoutParams());
  }
  
  public FrameLayout.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected FrameLayout.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new LayoutParams(paramLayoutParams);
  }
  
  public Drawable getContentScrim()
  {
    return this.mContentScrim;
  }
  
  final int getScrimTriggerOffset()
  {
    return ViewCompat.getMinimumHeight(this) * 2;
  }
  
  public Drawable getStatusBarScrim()
  {
    return this.mStatusBarScrim;
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    ViewParent localViewParent = getParent();
    if ((localViewParent instanceof AppBarLayout))
    {
      if (this.mOnOffsetChangedListener == null) {
        this.mOnOffsetChangedListener = new OffsetUpdateListener(null);
      }
      ((AppBarLayout)localViewParent).addOnOffsetChangedListener(this.mOnOffsetChangedListener);
    }
  }
  
  protected void onDetachedFromWindow()
  {
    ViewParent localViewParent = getParent();
    if ((this.mOnOffsetChangedListener != null) && ((localViewParent instanceof AppBarLayout))) {
      ((AppBarLayout)localViewParent).removeOnOffsetChangedListener(this.mOnOffsetChangedListener);
    }
    super.onDetachedFromWindow();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt2 = 0;
    int i = getChildCount();
    while (paramInt2 < i)
    {
      View localView = getChildAt(paramInt2);
      if ((this.mLastInsets != null) && (!ViewCompat.getFitsSystemWindows(localView)))
      {
        int j = this.mLastInsets.getSystemWindowInsetTop();
        if (localView.getTop() < j) {
          localView.offsetTopAndBottom(j);
        }
      }
      getViewOffsetHelper(localView).onViewLayout();
      paramInt2 += 1;
    }
    if (this.mDummyView != null)
    {
      ViewGroupUtils.getDescendantRect(this, this.mDummyView, this.mTmpRect);
      this.mCollapsingTextHelper.setCollapsedBounds(this.mTmpRect.left, paramInt4 - this.mTmpRect.height(), this.mTmpRect.right, paramInt4);
      this.mCollapsingTextHelper.setExpandedBounds(this.mExpandedMarginLeft + paramInt1, this.mTmpRect.bottom + this.mExpandedMarginTop, paramInt3 - this.mExpandedMarginRight, paramInt4 - this.mExpandedMarginBottom);
      this.mCollapsingTextHelper.recalculate();
    }
    if (this.mToolbar != null) {
      setMinimumHeight(this.mToolbar.getHeight());
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    ensureToolbar();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (this.mContentScrim != null) {
      this.mContentScrim.setBounds(0, 0, paramInt1, paramInt2);
    }
  }
  
  public void setCollapsedTitleTextAppearance(int paramInt)
  {
    this.mCollapsingTextHelper.setCollapsedTextAppearance(paramInt);
  }
  
  public void setCollapsedTitleTextColor(int paramInt)
  {
    this.mCollapsingTextHelper.setCollapsedTextColor(paramInt);
  }
  
  public void setContentScrim(@Nullable Drawable paramDrawable)
  {
    if (this.mContentScrim != paramDrawable)
    {
      if (this.mContentScrim != null) {
        this.mContentScrim.setCallback(null);
      }
      this.mContentScrim = paramDrawable;
      paramDrawable.setBounds(0, 0, getWidth(), getHeight());
      paramDrawable.setCallback(this);
      paramDrawable.mutate().setAlpha(this.mScrimAlpha);
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  public void setContentScrimColor(int paramInt)
  {
    setContentScrim(new ColorDrawable(paramInt));
  }
  
  public void setContentScrimResource(@DrawableRes int paramInt)
  {
    setContentScrim(ContextCompat.getDrawable(getContext(), paramInt));
  }
  
  public void setExpandedTitleColor(int paramInt)
  {
    this.mCollapsingTextHelper.setExpandedTextColor(paramInt);
  }
  
  public void setExpandedTitleTextAppearance(int paramInt)
  {
    this.mCollapsingTextHelper.setExpandedTextAppearance(paramInt);
  }
  
  public void setStatusBarScrim(@Nullable Drawable paramDrawable)
  {
    if (this.mStatusBarScrim != paramDrawable)
    {
      if (this.mStatusBarScrim != null) {
        this.mStatusBarScrim.setCallback(null);
      }
      this.mStatusBarScrim = paramDrawable;
      paramDrawable.setCallback(this);
      paramDrawable.mutate().setAlpha(this.mScrimAlpha);
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  public void setStatusBarScrimColor(int paramInt)
  {
    setStatusBarScrim(new ColorDrawable(paramInt));
  }
  
  public void setStatusBarScrimResource(@DrawableRes int paramInt)
  {
    setStatusBarScrim(ContextCompat.getDrawable(getContext(), paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence)
  {
    this.mCollapsingTextHelper.setText(paramCharSequence);
  }
  
  public static class LayoutParams
    extends FrameLayout.LayoutParams
  {
    public static final int COLLAPSE_MODE_OFF = 0;
    public static final int COLLAPSE_MODE_PARALLAX = 2;
    public static final int COLLAPSE_MODE_PIN = 1;
    private static final float DEFAULT_PARALLAX_MULTIPLIER = 0.5F;
    int mCollapseMode = 0;
    float mParallaxMult = 0.5F;
    
    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }
    
    public LayoutParams(int paramInt1, int paramInt2, int paramInt3)
    {
      super(paramInt2, paramInt3);
    }
    
    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.CollapsingAppBarLayout_LayoutParams);
      this.mCollapseMode = paramContext.getInt(R.styleable.CollapsingAppBarLayout_LayoutParams_layout_collapseMode, 0);
      setParallaxMultiplier(paramContext.getFloat(R.styleable.CollapsingAppBarLayout_LayoutParams_layout_collapseParallaxMultiplier, 0.5F));
      paramContext.recycle();
    }
    
    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
    }
    
    public LayoutParams(FrameLayout.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public int getCollapseMode()
    {
      return this.mCollapseMode;
    }
    
    public float getParallaxMultiplier()
    {
      return this.mParallaxMult;
    }
    
    public void setCollapseMode(int paramInt)
    {
      this.mCollapseMode = paramInt;
    }
    
    public void setParallaxMultiplier(float paramFloat)
    {
      this.mParallaxMult = paramFloat;
    }
  }
  
  private class OffsetUpdateListener
    implements AppBarLayout.OnOffsetChangedListener
  {
    private OffsetUpdateListener() {}
    
    public void onOffsetChanged(AppBarLayout paramAppBarLayout, int paramInt)
    {
      CollapsingToolbarLayout.access$302(CollapsingToolbarLayout.this, paramInt);
      int i;
      int k;
      int j;
      int m;
      label48:
      View localView;
      CollapsingToolbarLayout.LayoutParams localLayoutParams;
      ViewOffsetHelper localViewOffsetHelper;
      if (CollapsingToolbarLayout.this.mLastInsets != null)
      {
        i = CollapsingToolbarLayout.this.mLastInsets.getSystemWindowInsetTop();
        k = paramAppBarLayout.getTotalScrollRange();
        j = 0;
        m = CollapsingToolbarLayout.this.getChildCount();
        if (j >= m) {
          break label177;
        }
        localView = CollapsingToolbarLayout.this.getChildAt(j);
        localLayoutParams = (CollapsingToolbarLayout.LayoutParams)localView.getLayoutParams();
        localViewOffsetHelper = CollapsingToolbarLayout.getViewOffsetHelper(localView);
        switch (localLayoutParams.mCollapseMode)
        {
        }
      }
      for (;;)
      {
        j += 1;
        break label48;
        i = 0;
        break;
        if (CollapsingToolbarLayout.this.getHeight() - i + paramInt >= localView.getHeight())
        {
          localViewOffsetHelper.setTopAndBottomOffset(-paramInt);
          continue;
          localViewOffsetHelper.setTopAndBottomOffset(Math.round(-paramInt * localLayoutParams.mParallaxMult));
        }
      }
      label177:
      if ((CollapsingToolbarLayout.this.mContentScrim != null) || (CollapsingToolbarLayout.this.mStatusBarScrim != null))
      {
        if (CollapsingToolbarLayout.this.getHeight() + paramInt >= CollapsingToolbarLayout.this.getScrimTriggerOffset() + i) {
          break label306;
        }
        CollapsingToolbarLayout.this.showScrim();
      }
      for (;;)
      {
        if ((CollapsingToolbarLayout.this.mStatusBarScrim != null) && (i > 0)) {
          ViewCompat.postInvalidateOnAnimation(CollapsingToolbarLayout.this);
        }
        j = CollapsingToolbarLayout.this.getHeight();
        m = ViewCompat.getMinimumHeight(CollapsingToolbarLayout.this);
        CollapsingToolbarLayout.this.mCollapsingTextHelper.setExpansionFraction(Math.abs(paramInt) / (j - m - i));
        if (Math.abs(paramInt) != k) {
          break;
        }
        ViewCompat.setElevation(paramAppBarLayout, paramAppBarLayout.getTargetElevation());
        return;
        label306:
        CollapsingToolbarLayout.this.hideScrim();
      }
      ViewCompat.setElevation(paramAppBarLayout, 0.0F);
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\Simplelink_Sensortag\classes-dex2jar.jar!\android\support\design\widget\CollapsingToolbarLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */