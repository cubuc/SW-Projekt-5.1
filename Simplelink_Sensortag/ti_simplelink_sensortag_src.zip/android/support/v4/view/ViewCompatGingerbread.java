package android.support.v4.view;

import android.view.View;

class ViewCompatGingerbread
{
  public static int getOverScrollMode(View paramView)
  {
    return paramView.getOverScrollMode();
  }
  
  public static void setOverScrollMode(View paramView, int paramInt)
  {
    paramView.setOverScrollMode(paramInt);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\Simplelink_Sensortag\classes-dex2jar.jar!\android\support\v4\view\ViewCompatGingerbread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */