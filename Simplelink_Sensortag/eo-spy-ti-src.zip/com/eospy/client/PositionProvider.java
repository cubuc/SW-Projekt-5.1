package com.eospy.client;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build.VERSION;
import android.preference.PreferenceManager;
import android.util.Log;

public abstract class PositionProvider
{
  protected static final String TAG = PositionProvider.class.getSimpleName();
  public static float accel_xSensor;
  public static float accel_ySensor;
  public static float accel_zSensor;
  public static float gyro_xSensor;
  public static float gyro_ySensor;
  public static float gyro_zSensor;
  public static float humiditySensor;
  public static float ir_tempSensor;
  public static boolean isaccelSensor;
  public static boolean isgyroSensor;
  public static boolean ishumiditySensor;
  public static boolean iskeypressSensor = false;
  public static boolean islightSensor;
  public static boolean ismagnetSensor;
  public static boolean ismbarSensor;
  public static boolean istempSensor;
  public static float keypressSensor;
  public static float lightSensor;
  public static float magnet_xSensor;
  public static float magnet_ySensor;
  public static float magnet_zSensor;
  public static float mbarSensor;
  public static float tempSensor = 0.0F;
  private final Context context;
  private String deviceId;
  private long lastUpdateTime;
  private final PositionListener listener;
  protected final LocationManager locationManager;
  protected final long period;
  private final SharedPreferences preferences;
  protected String type;
  
  static
  {
    ir_tempSensor = 0.0F;
    humiditySensor = 0.0F;
    mbarSensor = 0.0F;
    accel_xSensor = 0.0F;
    accel_ySensor = 0.0F;
    accel_zSensor = 0.0F;
    gyro_xSensor = 0.0F;
    gyro_ySensor = 0.0F;
    gyro_zSensor = 0.0F;
    magnet_xSensor = 0.0F;
    magnet_ySensor = 0.0F;
    magnet_zSensor = 0.0F;
    lightSensor = 0.0F;
    keypressSensor = 0.0F;
    istempSensor = false;
    ishumiditySensor = false;
    ismbarSensor = false;
    isaccelSensor = false;
    isgyroSensor = false;
    ismagnetSensor = false;
    islightSensor = false;
  }
  
  public PositionProvider(Context paramContext, PositionListener paramPositionListener)
  {
    this.context = paramContext;
    this.listener = paramPositionListener;
    this.preferences = PreferenceManager.getDefaultSharedPreferences(paramContext);
    this.locationManager = ((LocationManager)paramContext.getSystemService("location"));
    this.deviceId = this.preferences.getString("id", null);
    this.period = (Long.parseLong(this.preferences.getString("interval", null)) * 1000L);
    this.type = this.preferences.getString("provider", "gps");
  }
  
  public static double getBatteryLevel(Context paramContext)
  {
    if (Build.VERSION.SDK_INT > 5)
    {
      paramContext = paramContext.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
      int i = paramContext.getIntExtra("level", 0);
      int j = paramContext.getIntExtra("scale", 1);
      return i * 100.0D / j;
    }
    return 0.0D;
  }
  
  public static void getSendAlarm() {}
  
  public abstract void startUpdates();
  
  public abstract void stopUpdates();
  
  protected void updateLocation(Location paramLocation)
  {
    if ((paramLocation != null) && (paramLocation.getTime() - this.lastUpdateTime >= this.period))
    {
      Log.i(TAG, "location new");
      this.lastUpdateTime = paramLocation.getTime();
      this.listener.onPositionUpdate(new Position(this.deviceId, paramLocation, getBatteryLevel(this.context), tempSensor, ir_tempSensor, humiditySensor, mbarSensor, accel_xSensor, accel_ySensor, accel_zSensor, gyro_xSensor, gyro_ySensor, gyro_zSensor, magnet_xSensor, magnet_ySensor, magnet_zSensor, lightSensor, keypressSensor));
      keypressSensor = 0.0F;
      return;
    }
    String str = TAG;
    if (paramLocation != null) {}
    for (paramLocation = "location old";; paramLocation = "location nil")
    {
      Log.i(str, paramLocation);
      return;
    }
  }
  
  public static abstract interface PositionListener
  {
    public abstract void onPositionUpdate(Position paramPosition);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\PositionProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */