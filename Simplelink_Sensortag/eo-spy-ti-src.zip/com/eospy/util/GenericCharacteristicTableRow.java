package com.eospy.util;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Switch;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import com.eospy.common.GattInfo;
import java.io.FileNotFoundException;
import java.util.UUID;

public class GenericCharacteristicTableRow
  extends TableRow
  implements View.OnClickListener, Animation.AnimationListener, SeekBar.OnSeekBarChangeListener, CompoundButton.OnCheckedChangeListener
{
  public static final String ACTION_CALIBRATE = "com.eospy.util.ACTION_CALIBRATE";
  public static final String ACTION_ONOFF_UPDATE = "com.eospy.util.ACTION_ONOFF_UPDATE";
  public static final String ACTION_PERIOD_UPDATE = "com.eospy.util.ACTION_PERIOD_UPDATE";
  public static final String EXTRA_ONOFF = "com.eospy.util.EXTRA_ONOFF";
  public static final String EXTRA_PERIOD = "com.eospy.util.EXTRA_PERIOD";
  public static final String EXTRA_SERVICE_UUID = "com.eospy.util.EXTRA_SERVICE_UUID";
  public final Button calibrateButton;
  public boolean config;
  protected final Context context;
  public final ImageView icon;
  public int iconSize = 150;
  private final Paint linePaint;
  public final Switch onOff;
  public final TextView onOffLegend;
  public final SeekBar periodBar;
  public final TextView periodLegend;
  public int periodMinVal;
  protected final RelativeLayout rowLayout;
  public final SparkLineView sl1;
  public final SparkLineView sl2;
  public final SparkLineView sl3;
  public final TextView title;
  public final TextView uuidLabel;
  public final TextView value;
  
  public GenericCharacteristicTableRow(Context paramContext)
  {
    super(paramContext);
    this.context = paramContext;
    this.config = false;
    setLayoutParams(new TableRow.LayoutParams(1));
    setBackgroundColor(0);
    setOnClickListener(this);
    this.periodMinVal = 100;
    new GattInfo(getResources().getXml(2130968576));
    this.rowLayout = new RelativeLayout(this.context);
    this.linePaint = new Paint() {};
    this.icon = new ImageView(paramContext) {};
    this.title = new TextView(paramContext) {};
    this.uuidLabel = new TextView(paramContext) {};
    this.value = new TextView(paramContext) {};
    this.sl1 = new SparkLineView(paramContext) {};
    this.sl2 = new SparkLineView(paramContext) {};
    this.sl3 = new SparkLineView(paramContext) {};
    this.onOff = new Switch(paramContext) {};
    this.periodBar = new SeekBar(paramContext) {};
    this.onOffLegend = new TextView(paramContext) {};
    this.periodLegend = new TextView(paramContext) {};
    this.calibrateButton = new Button(paramContext) {};
    this.periodBar.setOnSeekBarChangeListener(this);
    this.onOff.setOnCheckedChangeListener(this);
    paramContext = new RelativeLayout.LayoutParams(this.iconSize, this.iconSize) {};
    this.icon.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-2, -2);
    paramContext.addRule(10, -1);
    paramContext.addRule(1, this.icon.getId());
    this.title.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-2, -2);
    paramContext.addRule(3, this.title.getId());
    paramContext.addRule(1, this.icon.getId());
    this.uuidLabel.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.title.getId());
    paramContext.addRule(1, this.icon.getId());
    this.value.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.value.getId());
    paramContext.addRule(1, this.icon.getId());
    this.sl1.setLayoutParams(paramContext);
    this.sl2.setLayoutParams(paramContext);
    this.sl3.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-2, -1);
    paramContext.addRule(3, this.value.getId());
    paramContext.addRule(1, this.icon.getId());
    this.onOffLegend.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-2, -1);
    paramContext.addRule(3, this.onOffLegend.getId());
    paramContext.addRule(1, this.icon.getId());
    this.onOff.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-2, -1);
    paramContext.addRule(3, this.value.getId());
    paramContext.addRule(1, this.onOff.getId());
    this.calibrateButton.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-2, -1);
    paramContext.addRule(3, this.onOff.getId());
    paramContext.addRule(1, this.icon.getId());
    this.periodLegend.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.periodLegend.getId());
    paramContext.rightMargin = 50;
    paramContext.addRule(1, this.icon.getId());
    this.periodBar.setLayoutParams(paramContext);
    this.rowLayout.addView(this.icon);
    this.rowLayout.addView(this.title);
    this.rowLayout.addView(this.uuidLabel);
    this.rowLayout.addView(this.value);
    this.rowLayout.addView(this.sl1);
    this.rowLayout.addView(this.sl2);
    this.rowLayout.addView(this.sl3);
    this.rowLayout.addView(this.onOffLegend);
    this.rowLayout.addView(this.onOff);
    this.rowLayout.addView(this.periodLegend);
    this.rowLayout.addView(this.periodBar);
    this.rowLayout.addView(this.calibrateButton);
    addView(this.rowLayout);
  }
  
  public static boolean isCorrectService(String paramString)
  {
    return true;
  }
  
  public void grayedOut(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      this.periodBar.setAlpha(0.4F);
      this.value.setAlpha(0.4F);
      this.title.setAlpha(0.4F);
      this.icon.setAlpha(0.4F);
      this.sl1.setAlpha(0.4F);
      this.sl2.setAlpha(0.4F);
      this.sl3.setAlpha(0.4F);
      this.periodLegend.setAlpha(0.4F);
      return;
    }
    this.periodBar.setAlpha(1.0F);
    this.value.setAlpha(1.0F);
    this.title.setAlpha(1.0F);
    this.icon.setAlpha(1.0F);
    this.sl1.setAlpha(1.0F);
    this.sl2.setAlpha(1.0F);
    this.sl3.setAlpha(1.0F);
    this.periodLegend.setAlpha(1.0F);
  }
  
  public void onAnimationEnd(Animation paramAnimation)
  {
    if (this.config == true)
    {
      this.sl1.setVisibility(4);
      if (this.sl2.isEnabled()) {
        this.sl2.setVisibility(4);
      }
      if (this.sl3.isEnabled()) {
        this.sl3.setVisibility(4);
      }
      this.onOff.setVisibility(0);
      this.onOffLegend.setVisibility(0);
      this.periodBar.setVisibility(0);
      this.periodLegend.setVisibility(0);
      return;
    }
    this.sl1.setVisibility(0);
    if (this.sl2.isEnabled()) {
      this.sl2.setVisibility(0);
    }
    if (this.sl3.isEnabled()) {
      this.sl3.setVisibility(0);
    }
    this.onOff.setVisibility(4);
    this.onOffLegend.setVisibility(4);
    this.periodBar.setVisibility(4);
    this.periodLegend.setVisibility(4);
  }
  
  public void onAnimationRepeat(Animation paramAnimation) {}
  
  public void onAnimationStart(Animation paramAnimation) {}
  
  public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
  {
    Log.d("GenericBluetoothProfile", "Switch changed : " + paramBoolean);
    paramCompoundButton = new Intent("com.eospy.util.ACTION_ONOFF_UPDATE");
    paramCompoundButton.putExtra("com.eospy.util.EXTRA_SERVICE_UUID", this.uuidLabel.getText());
    paramCompoundButton.putExtra("com.eospy.util.EXTRA_ONOFF", paramBoolean);
    this.context.sendBroadcast(paramCompoundButton);
  }
  
  public void onClick(View paramView)
  {
    if (!this.config) {}
    AlphaAnimation localAlphaAnimation;
    for (boolean bool = true;; bool = false)
    {
      this.config = bool;
      Log.d("onClick", "Row ID" + paramView.getId());
      paramView = new AlphaAnimation(1.0F, 0.0F);
      paramView.setAnimationListener(this);
      paramView.setDuration(500L);
      paramView.setStartOffset(0L);
      localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
      localAlphaAnimation.setAnimationListener(this);
      localAlphaAnimation.setDuration(500L);
      localAlphaAnimation.setStartOffset(250L);
      if (this.config != true) {
        break;
      }
      this.sl1.startAnimation(paramView);
      if (this.sl2.isEnabled()) {
        this.sl2.startAnimation(paramView);
      }
      if (this.sl3.isEnabled()) {
        this.sl3.startAnimation(paramView);
      }
      this.value.startAnimation(paramView);
      this.onOffLegend.startAnimation(localAlphaAnimation);
      this.onOff.startAnimation(localAlphaAnimation);
      this.periodLegend.startAnimation(localAlphaAnimation);
      this.periodBar.startAnimation(localAlphaAnimation);
      return;
    }
    this.sl1.startAnimation(localAlphaAnimation);
    if (this.sl2.isEnabled()) {
      this.sl2.startAnimation(localAlphaAnimation);
    }
    if (this.sl3.isEnabled()) {
      this.sl3.startAnimation(localAlphaAnimation);
    }
    this.value.startAnimation(localAlphaAnimation);
    this.onOffLegend.startAnimation(paramView);
    this.onOff.startAnimation(paramView);
    this.periodLegend.startAnimation(paramView);
    this.periodBar.startAnimation(paramView);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    Object localObject = ((WindowManager)this.context.getSystemService("window")).getDefaultDisplay();
    paramConfiguration = new Point();
    ((Display)localObject).getSize(paramConfiguration);
    localObject = this.sl1;
    SparkLineView localSparkLineView1 = this.sl2;
    SparkLineView localSparkLineView2 = this.sl3;
    float f = paramConfiguration.x - this.iconSize - 5;
    localSparkLineView2.displayWidth = f;
    localSparkLineView1.displayWidth = f;
    ((SparkLineView)localObject).displayWidth = f;
    invalidate();
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    paramCanvas.drawLine(0.0F, paramCanvas.getHeight() - this.linePaint.getStrokeWidth(), paramCanvas.getWidth(), paramCanvas.getHeight() - this.linePaint.getStrokeWidth(), this.linePaint);
  }
  
  public void onProgressChanged(SeekBar paramSeekBar, int paramInt, boolean paramBoolean)
  {
    Log.d("GenericBluetoothProfile", "Period changed : " + paramInt);
    this.periodLegend.setText("Sensor period (currently : " + (paramInt * 10 + this.periodMinVal) + "ms)");
  }
  
  public void onStartTrackingTouch(SeekBar paramSeekBar)
  {
    Log.d("GenericBluetoothProfile", "Period Start");
  }
  
  public void onStopTrackingTouch(SeekBar paramSeekBar)
  {
    Log.d("GenericBluetoothProfile", "Period Stop");
    Intent localIntent = new Intent("com.eospy.util.ACTION_PERIOD_UPDATE");
    int i = this.periodMinVal;
    int j = paramSeekBar.getProgress();
    localIntent.putExtra("com.eospy.util.EXTRA_SERVICE_UUID", this.uuidLabel.getText());
    localIntent.putExtra("com.eospy.util.EXTRA_PERIOD", i + j * 10);
    this.context.sendBroadcast(localIntent);
  }
  
  public void setIcon(String paramString1, String paramString2)
  {
    Object localObject1 = ((WindowManager)this.context.getSystemService("window")).getDefaultDisplay();
    Point localPoint = new Point();
    ((Display)localObject1).getSize(localPoint);
    Object localObject2 = null;
    localObject1 = null;
    if (localPoint.x > 1100)
    {
      paramString2 = Uri.parse("android.resource://" + this.context.getPackageName() + "/drawable/" + paramString1 + GattInfo.uuidToIcon(UUID.fromString(paramString2)) + "_300");
      paramString1 = (String)localObject2;
    }
    for (;;)
    {
      try
      {
        paramString2 = Drawable.createFromStream(this.context.getContentResolver().openInputStream(paramString2), paramString2.toString());
        paramString1 = paramString2;
        this.iconSize = 360;
        paramString1 = paramString2;
      }
      catch (FileNotFoundException paramString2)
      {
        float f;
        continue;
      }
      this.icon.setImageDrawable(paramString1);
      paramString1 = this.sl1;
      paramString2 = this.sl2;
      localObject1 = this.sl3;
      f = localPoint.x - this.iconSize - 5;
      ((SparkLineView)localObject1).displayWidth = f;
      paramString2.displayWidth = f;
      paramString1.displayWidth = f;
      paramString1 = new RelativeLayout.LayoutParams(this.iconSize, this.iconSize) {};
      this.icon.setLayoutParams(paramString1);
      return;
      paramString2 = Uri.parse("android.resource://" + this.context.getPackageName() + "/drawable/" + paramString1 + GattInfo.uuidToIcon(UUID.fromString(paramString2)));
      paramString1 = (String)localObject1;
      try
      {
        paramString2 = Drawable.createFromStream(this.context.getContentResolver().openInputStream(paramString2), paramString2.toString());
        paramString1 = paramString2;
        this.iconSize = 210;
        paramString1 = paramString2;
      }
      catch (FileNotFoundException paramString2) {}
    }
  }
  
  public void setIcon(String paramString1, String paramString2, String paramString3)
  {
    paramString2 = ((WindowManager)this.context.getSystemService("window")).getDefaultDisplay();
    Point localPoint = new Point();
    paramString2.getSize(localPoint);
    SparkLineView localSparkLineView = null;
    paramString2 = null;
    if (localPoint.x > 1100)
    {
      paramString2 = Uri.parse("android.resource://" + this.context.getPackageName() + "/drawable/" + paramString1 + paramString3 + "_300");
      paramString1 = localSparkLineView;
    }
    for (;;)
    {
      try
      {
        paramString2 = Drawable.createFromStream(this.context.getContentResolver().openInputStream(paramString2), paramString2.toString());
        paramString1 = paramString2;
        this.iconSize = 360;
        paramString1 = paramString2;
      }
      catch (FileNotFoundException paramString2)
      {
        float f;
        continue;
      }
      paramString2 = this.sl1;
      paramString3 = this.sl2;
      localSparkLineView = this.sl3;
      f = localPoint.x - this.iconSize - 5;
      localSparkLineView.displayWidth = f;
      paramString3.displayWidth = f;
      paramString2.displayWidth = f;
      this.icon.setImageDrawable(paramString1);
      paramString1 = new RelativeLayout.LayoutParams(this.iconSize, this.iconSize) {};
      this.icon.setLayoutParams(paramString1);
      return;
      paramString3 = Uri.parse("android.resource://" + this.context.getPackageName() + "/drawable/" + paramString1 + paramString3);
      paramString1 = paramString2;
      try
      {
        paramString2 = Drawable.createFromStream(this.context.getContentResolver().openInputStream(paramString3), paramString3.toString());
        paramString1 = paramString2;
        this.iconSize = 210;
        paramString1 = paramString2;
      }
      catch (FileNotFoundException paramString2) {}
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\util\GenericCharacteristicTableRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */