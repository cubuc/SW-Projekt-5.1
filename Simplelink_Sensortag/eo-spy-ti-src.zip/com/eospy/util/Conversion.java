package com.eospy.util;

import java.util.Formatter;

public class Conversion
{
  public static String BytetohexString(byte[] paramArrayOfByte, int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder(paramArrayOfByte.length * 3);
    Formatter localFormatter = new Formatter(localStringBuilder);
    int i = 0;
    if (i < paramInt)
    {
      if (i < paramInt - 1) {
        localFormatter.format("%02X:", new Object[] { Byte.valueOf(paramArrayOfByte[i]) });
      }
      for (;;)
      {
        i += 1;
        break;
        localFormatter.format("%02X", new Object[] { Byte.valueOf(paramArrayOfByte[i]) });
      }
    }
    localFormatter.close();
    return localStringBuilder.toString();
  }
  
  static String BytetohexString(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    StringBuilder localStringBuilder = new StringBuilder(paramArrayOfByte.length * 3);
    Formatter localFormatter = new Formatter(localStringBuilder);
    int i;
    if (!paramBoolean)
    {
      i = 0;
      if (i < paramArrayOfByte.length)
      {
        if (i < paramArrayOfByte.length - 1) {
          localFormatter.format("%02X:", new Object[] { Byte.valueOf(paramArrayOfByte[i]) });
        }
        for (;;)
        {
          i += 1;
          break;
          localFormatter.format("%02X", new Object[] { Byte.valueOf(paramArrayOfByte[i]) });
        }
      }
    }
    else
    {
      i = paramArrayOfByte.length - 1;
      if (i >= 0)
      {
        if (i > 0) {
          localFormatter.format("%02X:", new Object[] { Byte.valueOf(paramArrayOfByte[i]) });
        }
        for (;;)
        {
          i -= 1;
          break;
          localFormatter.format("%02X", new Object[] { Byte.valueOf(paramArrayOfByte[i]) });
        }
      }
    }
    localFormatter.close();
    return localStringBuilder.toString();
  }
  
  public static short buildUint16(byte paramByte1, byte paramByte2)
  {
    return (short)((paramByte1 << 8) + (paramByte2 & 0xFF));
  }
  
  public static int hexStringtoByte(String paramString, byte[] paramArrayOfByte)
  {
    int j = 0;
    int i = 0;
    int m = 0;
    if (paramString != null)
    {
      int k = 0;
      j = i;
      if (k < paramString.length())
      {
        if (((paramString.charAt(k) < '0') || (paramString.charAt(k) > '9')) && ((paramString.charAt(k) < 'a') || (paramString.charAt(k) > 'f')))
        {
          n = i;
          j = m;
          if (paramString.charAt(k) >= 'A')
          {
            n = i;
            j = m;
            if (paramString.charAt(k) > 'F') {}
          }
        }
        else
        {
          if (m == 0) {
            break label157;
          }
          paramArrayOfByte[i] = ((byte)(paramArrayOfByte[i] + (byte)Character.digit(paramString.charAt(k), 16)));
          i += 1;
          label132:
          if (m != 0) {
            break label177;
          }
          j = 1;
        }
        for (int n = i;; n = i)
        {
          k += 1;
          i = n;
          m = j;
          break;
          label157:
          paramArrayOfByte[i] = ((byte)(Character.digit(paramString.charAt(k), 16) << 4));
          break label132;
          label177:
          j = 0;
        }
      }
    }
    return j;
  }
  
  public static byte hiUint16(short paramShort)
  {
    return (byte)(paramShort >> 8);
  }
  
  private static boolean isAsciiPrintable(char paramChar)
  {
    return (paramChar >= ' ') && (paramChar < '');
  }
  
  public static boolean isAsciiPrintable(String paramString)
  {
    if (paramString == null) {
      return false;
    }
    int j = paramString.length();
    int i = 0;
    for (;;)
    {
      if (i >= j) {
        break label36;
      }
      if (!isAsciiPrintable(paramString.charAt(i))) {
        break;
      }
      i += 1;
    }
    label36:
    return true;
  }
  
  public static byte loUint16(short paramShort)
  {
    return (byte)(paramShort & 0xFF);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\util\Conversion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */