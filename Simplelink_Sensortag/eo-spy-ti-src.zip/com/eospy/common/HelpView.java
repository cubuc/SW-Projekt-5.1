package com.eospy.common;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

public class HelpView
  extends Fragment
{
  private String mFile = "about.html";
  private int mIdFragment;
  private int mIdWebPage;
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    paramLayoutInflater = paramLayoutInflater.inflate(this.mIdFragment, paramViewGroup, false);
    ((WebView)paramLayoutInflater.findViewById(this.mIdWebPage)).loadUrl("file:///android_asset/" + this.mFile);
    return paramLayoutInflater;
  }
  
  public void setParameters(String paramString, int paramInt1, int paramInt2)
  {
    if (paramString != null) {
      this.mFile = paramString;
    }
    this.mIdFragment = paramInt1;
    this.mIdWebPage = paramInt2;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\common\HelpView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */