package com.eospy.util;

import android.content.Context;
import android.widget.Toast;

public class CustomToast
{
  public static void middleBottom(Context paramContext, String paramString)
  {
    paramContext = Toast.makeText(paramContext, paramString, 0);
    paramContext.setGravity(81, 0, 300);
    paramContext.show();
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\util\CustomToast.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */