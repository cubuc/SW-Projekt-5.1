package com.eospy.util;

import android.widget.ProgressBar;
import java.util.Timer;
import java.util.TimerTask;

public class CustomTimer
{
  private CustomTimerCallback mCb = null;
  private ProgressBar mProgressBar;
  private int mTimeout;
  private Timer mTimer;
  
  public CustomTimer(ProgressBar paramProgressBar, int paramInt, CustomTimerCallback paramCustomTimerCallback)
  {
    this.mTimeout = paramInt;
    this.mProgressBar = paramProgressBar;
    this.mTimer = new Timer();
    paramProgressBar = new ProgressTask(null);
    this.mTimer.schedule(paramProgressBar, 0L, 1000L);
    this.mCb = paramCustomTimerCallback;
  }
  
  public void stop()
  {
    if (this.mTimer != null)
    {
      this.mTimer.cancel();
      this.mTimer = null;
    }
  }
  
  private class ProgressTask
    extends TimerTask
  {
    int i = 0;
    
    private ProgressTask() {}
    
    public void run()
    {
      this.i += 1;
      if (CustomTimer.this.mProgressBar != null) {
        CustomTimer.this.mProgressBar.setProgress(this.i);
      }
      if (this.i >= CustomTimer.this.mTimeout)
      {
        CustomTimer.this.mTimer.cancel();
        CustomTimer.access$302(CustomTimer.this, null);
        if (CustomTimer.this.mCb != null) {
          CustomTimer.this.mCb.onTimeout();
        }
      }
      while (CustomTimer.this.mCb == null) {
        return;
      }
      CustomTimer.this.mCb.onTick(this.i);
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\util\CustomTimer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */