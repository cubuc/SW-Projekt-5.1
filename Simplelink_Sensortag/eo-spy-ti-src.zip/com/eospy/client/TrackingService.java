package com.eospy.client;

import android.annotation.TargetApi;
import android.app.Service;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.util.Log;

public class TrackingService
  extends Service
{
  private static final int NOTIFICATION_ID = 1;
  private static final String TAG = TrackingService.class.getSimpleName();
  private TrackingController trackingController;
  
  /* Error */
  private static android.app.Notification createNotification(android.content.Context paramContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: new 39	android/content/Intent
    //   5: dup
    //   6: aload_0
    //   7: ldc 41
    //   9: invokespecial 44	android/content/Intent:<init>	(Landroid/content/Context;Ljava/lang/Class;)V
    //   12: iconst_0
    //   13: invokestatic 50	android/app/PendingIntent:getActivity	(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   16: astore_2
    //   17: new 52	android/app/Notification
    //   20: dup
    //   21: ldc 53
    //   23: aconst_null
    //   24: lconst_0
    //   25: invokespecial 56	android/app/Notification:<init>	(ILjava/lang/CharSequence;J)V
    //   28: astore_1
    //   29: aload_1
    //   30: invokevirtual 62	java/lang/Object:getClass	()Ljava/lang/Class;
    //   33: ldc 64
    //   35: iconst_4
    //   36: anewarray 15	java/lang/Class
    //   39: dup
    //   40: iconst_0
    //   41: ldc 66
    //   43: aastore
    //   44: dup
    //   45: iconst_1
    //   46: ldc 68
    //   48: aastore
    //   49: dup
    //   50: iconst_2
    //   51: ldc 68
    //   53: aastore
    //   54: dup
    //   55: iconst_3
    //   56: ldc 46
    //   58: aastore
    //   59: invokevirtual 72	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   62: astore_3
    //   63: aload_3
    //   64: aload_1
    //   65: iconst_4
    //   66: anewarray 58	java/lang/Object
    //   69: dup
    //   70: iconst_0
    //   71: aload_0
    //   72: aastore
    //   73: dup
    //   74: iconst_1
    //   75: aload_0
    //   76: ldc 73
    //   78: invokevirtual 77	android/content/Context:getString	(I)Ljava/lang/String;
    //   81: aastore
    //   82: dup
    //   83: iconst_2
    //   84: aload_0
    //   85: ldc 78
    //   87: invokevirtual 77	android/content/Context:getString	(I)Ljava/lang/String;
    //   90: aastore
    //   91: dup
    //   92: iconst_3
    //   93: aload_2
    //   94: aastore
    //   95: invokevirtual 84	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   98: pop
    //   99: getstatic 89	android/os/Build$VERSION:SDK_INT	I
    //   102: bipush 18
    //   104: if_icmplt +9 -> 113
    //   107: aload_1
    //   108: bipush -2
    //   110: putfield 92	android/app/Notification:priority	I
    //   113: aload_1
    //   114: areturn
    //   115: astore_0
    //   116: getstatic 21	com/eospy/client/TrackingService:TAG	Ljava/lang/String;
    //   119: aload_0
    //   120: invokestatic 98	android/util/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   123: pop
    //   124: goto -25 -> 99
    //   127: astore_0
    //   128: getstatic 21	com/eospy/client/TrackingService:TAG	Ljava/lang/String;
    //   131: aload_0
    //   132: invokestatic 98	android/util/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   135: pop
    //   136: goto -37 -> 99
    //   139: astore_0
    //   140: goto -24 -> 116
    //   143: astore_0
    //   144: goto -28 -> 116
    //   147: astore_0
    //   148: goto -20 -> 128
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	151	0	paramContext	android.content.Context
    //   28	86	1	localNotification	android.app.Notification
    //   16	78	2	localPendingIntent	android.app.PendingIntent
    //   62	2	3	localMethod	java.lang.reflect.Method
    // Exception table:
    //   from	to	target	type
    //   63	99	115	java/lang/IllegalArgumentException
    //   29	63	127	java/lang/SecurityException
    //   63	99	127	java/lang/SecurityException
    //   116	124	127	java/lang/SecurityException
    //   63	99	139	java/lang/IllegalAccessException
    //   63	99	143	java/lang/reflect/InvocationTargetException
    //   29	63	147	java/lang/NoSuchMethodException
    //   63	99	147	java/lang/NoSuchMethodException
    //   116	124	147	java/lang/NoSuchMethodException
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    Log.i(TAG, "service create");
    StatusDialog.addMessage(getString(2131034228));
    this.trackingController = new TrackingController(this);
    this.trackingController.start();
    if (Build.VERSION.SDK_INT >= 5) {
      startForeground(1, createNotification(this));
    }
  }
  
  public void onDestroy()
  {
    Log.i(TAG, "service destroy");
    StatusDialog.addMessage(getString(2131034229));
    if (Build.VERSION.SDK_INT >= 5) {
      stopForeground(true);
    }
    if (this.trackingController != null) {
      this.trackingController.stop();
    }
  }
  
  public void onStart(Intent paramIntent, int paramInt)
  {
    if (paramIntent != null) {}
  }
  
  @TargetApi(5)
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    onStart(paramIntent, paramInt2);
    return 1;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\TrackingService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */