package android.support.v4.animation;

abstract interface AnimatorProvider
{
  public abstract ValueAnimatorCompat emptyValueAnimator();
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\android\support\v4\animation\AnimatorProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */