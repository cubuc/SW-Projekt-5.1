package com.eospy.client;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class AutostartReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if (PreferenceManager.getDefaultSharedPreferences(paramContext).getBoolean("status", false)) {}
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\AutostartReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */