package com.eospy.common;

import android.bluetooth.BluetoothDevice;

public class BleDeviceInfo
{
  private BluetoothDevice mBtDevice;
  private int mRssi;
  
  public BleDeviceInfo(BluetoothDevice paramBluetoothDevice, int paramInt)
  {
    this.mBtDevice = paramBluetoothDevice;
    this.mRssi = paramInt;
  }
  
  public BluetoothDevice getBluetoothDevice()
  {
    return this.mBtDevice;
  }
  
  public int getRssi()
  {
    return this.mRssi;
  }
  
  public void updateRssi(int paramInt)
  {
    this.mRssi = paramInt;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\common\BleDeviceInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */