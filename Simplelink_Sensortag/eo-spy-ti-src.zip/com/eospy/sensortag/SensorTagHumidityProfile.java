package com.eospy.sensortag;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.util.Log;
import android.widget.SeekBar;
import android.widget.TextView;
import com.eospy.common.BluetoothLeService;
import com.eospy.common.GattInfo;
import com.eospy.common.GenericBluetoothProfile;
import com.eospy.util.GenericCharacteristicTableRow;
import com.eospy.util.Point3D;
import com.eospy.util.SparkLineView;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SensorTagHumidityProfile
  extends GenericBluetoothProfile
{
  public SensorTagHumidityProfile(Context paramContext, BluetoothDevice paramBluetoothDevice, BluetoothGattService paramBluetoothGattService, BluetoothLeService paramBluetoothLeService)
  {
    super(paramContext, paramBluetoothDevice, paramBluetoothGattService, paramBluetoothLeService);
    this.tRow = new GenericCharacteristicTableRow(paramContext);
    paramContext = this.mBTService.getCharacteristics().iterator();
    while (paramContext.hasNext())
    {
      paramBluetoothDevice = (BluetoothGattCharacteristic)paramContext.next();
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_HUM_DATA.toString())) {
        this.dataC = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_HUM_CONF.toString())) {
        this.configC = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_HUM_PERI.toString())) {
        this.periodC = paramBluetoothDevice;
      }
    }
    this.tRow.setIcon(getIconPrefix(), this.dataC.getUuid().toString());
    this.tRow.title.setText(GattInfo.uuidToName(UUID.fromString(this.dataC.getUuid().toString())));
    this.tRow.uuidLabel.setText(this.dataC.getUuid().toString());
    this.tRow.value.setText("0.0%rH");
    this.tRow.periodBar.setProgress(100);
  }
  
  public static boolean isCorrectService(BluetoothGattService paramBluetoothGattService)
  {
    if (paramBluetoothGattService.getUuid().toString().compareTo(SensorTagGatt.UUID_HUM_SERV.toString()) == 0)
    {
      Log.d("Test", "Match !");
      return true;
    }
    return false;
  }
  
  public void didReadValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic) {}
  
  public void didUpdateValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic)
  {
    byte[] arrayOfByte = paramBluetoothGattCharacteristic.getValue();
    if (paramBluetoothGattCharacteristic.equals(this.dataC))
    {
      paramBluetoothGattCharacteristic = Sensor.HUMIDITY.convert(arrayOfByte);
      if (!this.tRow.config) {
        this.tRow.value.setText(String.format("%.1f %%rH", new Object[] { Double.valueOf(paramBluetoothGattCharacteristic.x) }));
      }
      this.tRow.sl1.maxVal = 100.0F;
      this.tRow.sl1.minVal = 0.0F;
      this.tRow.sl1.addValue((float)paramBluetoothGattCharacteristic.x);
      com.eospy.client.PositionProvider.humiditySensor = (float)paramBluetoothGattCharacteristic.x;
    }
  }
  
  public void didWriteValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic) {}
  
  public Map<String, String> getMQTTMap()
  {
    Point3D localPoint3D = Sensor.HUMIDITY.convert(this.dataC.getValue());
    HashMap localHashMap = new HashMap();
    localHashMap.put("humidity", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.x) }));
    return localHashMap;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\SensorTagHumidityProfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */