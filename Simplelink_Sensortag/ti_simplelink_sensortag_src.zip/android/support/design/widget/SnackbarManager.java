package android.support.design.widget;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import java.lang.ref.WeakReference;

class SnackbarManager
{
  private static final int LONG_DURATION_MS = 2750;
  private static final int MSG_TIMEOUT = 0;
  private static final int SHORT_DURATION_MS = 1500;
  private static SnackbarManager sSnackbarManager;
  private SnackbarRecord mCurrentSnackbar;
  private final Handler mHandler = new Handler(Looper.getMainLooper(), new Handler.Callback()
  {
    public boolean handleMessage(Message paramAnonymousMessage)
    {
      switch (paramAnonymousMessage.what)
      {
      default: 
        return false;
      }
      SnackbarManager.this.handleTimeout((SnackbarManager.SnackbarRecord)paramAnonymousMessage.obj);
      return true;
    }
  });
  private final Object mLock = new Object();
  private SnackbarRecord mNextSnackbar;
  
  private boolean cancelSnackbarLocked(SnackbarRecord paramSnackbarRecord)
  {
    paramSnackbarRecord = (Callback)paramSnackbarRecord.callback.get();
    if (paramSnackbarRecord != null)
    {
      paramSnackbarRecord.dismiss();
      return true;
    }
    return false;
  }
  
  static SnackbarManager getInstance()
  {
    if (sSnackbarManager == null) {
      sSnackbarManager = new SnackbarManager();
    }
    return sSnackbarManager;
  }
  
  private void handleTimeout(SnackbarRecord paramSnackbarRecord)
  {
    synchronized (this.mLock)
    {
      if ((this.mCurrentSnackbar == paramSnackbarRecord) || (this.mNextSnackbar == paramSnackbarRecord)) {
        cancelSnackbarLocked(paramSnackbarRecord);
      }
      return;
    }
  }
  
  private boolean isCurrentSnackbar(Callback paramCallback)
  {
    return (this.mCurrentSnackbar != null) && (this.mCurrentSnackbar.isSnackbar(paramCallback));
  }
  
  private boolean isNextSnackbar(Callback paramCallback)
  {
    return (this.mNextSnackbar != null) && (this.mNextSnackbar.isSnackbar(paramCallback));
  }
  
  private void scheduleTimeoutLocked(SnackbarRecord paramSnackbarRecord)
  {
    if (paramSnackbarRecord.duration == -2) {
      return;
    }
    int i = 2750;
    if (paramSnackbarRecord.duration > 0) {
      i = paramSnackbarRecord.duration;
    }
    for (;;)
    {
      this.mHandler.removeCallbacksAndMessages(paramSnackbarRecord);
      this.mHandler.sendMessageDelayed(Message.obtain(this.mHandler, 0, paramSnackbarRecord), i);
      return;
      if (paramSnackbarRecord.duration == -1) {
        i = 1500;
      }
    }
  }
  
  private void showNextSnackbarLocked()
  {
    if (this.mNextSnackbar != null)
    {
      this.mCurrentSnackbar = this.mNextSnackbar;
      this.mNextSnackbar = null;
      Callback localCallback = (Callback)this.mCurrentSnackbar.callback.get();
      if (localCallback != null) {
        localCallback.show();
      }
    }
    else
    {
      return;
    }
    this.mCurrentSnackbar = null;
  }
  
  public void cancelTimeout(Callback paramCallback)
  {
    synchronized (this.mLock)
    {
      if (isCurrentSnackbar(paramCallback)) {
        this.mHandler.removeCallbacksAndMessages(this.mCurrentSnackbar);
      }
      return;
    }
  }
  
  public void dismiss(Callback paramCallback)
  {
    synchronized (this.mLock)
    {
      if (isCurrentSnackbar(paramCallback)) {
        cancelSnackbarLocked(this.mCurrentSnackbar);
      }
      if (isNextSnackbar(paramCallback)) {
        cancelSnackbarLocked(this.mNextSnackbar);
      }
      return;
    }
  }
  
  public void onDismissed(Callback paramCallback)
  {
    synchronized (this.mLock)
    {
      if (isCurrentSnackbar(paramCallback))
      {
        this.mCurrentSnackbar = null;
        if (this.mNextSnackbar != null) {
          showNextSnackbarLocked();
        }
      }
      return;
    }
  }
  
  public void onShown(Callback paramCallback)
  {
    synchronized (this.mLock)
    {
      if (isCurrentSnackbar(paramCallback)) {
        scheduleTimeoutLocked(this.mCurrentSnackbar);
      }
      return;
    }
  }
  
  public void restoreTimeout(Callback paramCallback)
  {
    synchronized (this.mLock)
    {
      if (isCurrentSnackbar(paramCallback)) {
        scheduleTimeoutLocked(this.mCurrentSnackbar);
      }
      return;
    }
  }
  
  public void show(int paramInt, Callback paramCallback)
  {
    for (;;)
    {
      synchronized (this.mLock)
      {
        if (isCurrentSnackbar(paramCallback))
        {
          SnackbarRecord.access$102(this.mCurrentSnackbar, paramInt);
          this.mHandler.removeCallbacksAndMessages(this.mCurrentSnackbar);
          scheduleTimeoutLocked(this.mCurrentSnackbar);
          return;
        }
        if (isNextSnackbar(paramCallback))
        {
          SnackbarRecord.access$102(this.mNextSnackbar, paramInt);
          if ((this.mCurrentSnackbar == null) || (!cancelSnackbarLocked(this.mCurrentSnackbar))) {
            break;
          }
          return;
        }
      }
      this.mNextSnackbar = new SnackbarRecord(paramInt, paramCallback);
    }
    this.mCurrentSnackbar = null;
    showNextSnackbarLocked();
  }
  
  static abstract interface Callback
  {
    public abstract void dismiss();
    
    public abstract void show();
  }
  
  private static class SnackbarRecord
  {
    private final WeakReference<SnackbarManager.Callback> callback;
    private int duration;
    
    SnackbarRecord(int paramInt, SnackbarManager.Callback paramCallback)
    {
      this.callback = new WeakReference(paramCallback);
      this.duration = paramInt;
    }
    
    boolean isSnackbar(SnackbarManager.Callback paramCallback)
    {
      return (paramCallback != null) && (this.callback.get() == paramCallback);
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\Simplelink_Sensortag\classes-dex2jar.jar!\android\support\design\widget\SnackbarManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */