package com.google.android.gms.appindexing;

public final class R
{
  public static final class attr
  {
    public static final int circleCrop = 2130771970;
    public static final int imageAspectRatio = 2130771969;
    public static final int imageAspectRatioAdjust = 2130771968;
  }
  
  public static final class color
  {
    public static final int common_action_bar_splitter = 2131165184;
    public static final int common_signin_btn_dark_text_default = 2131165185;
    public static final int common_signin_btn_dark_text_disabled = 2131165186;
    public static final int common_signin_btn_dark_text_focused = 2131165187;
    public static final int common_signin_btn_dark_text_pressed = 2131165188;
    public static final int common_signin_btn_default_background = 2131165189;
    public static final int common_signin_btn_light_text_default = 2131165190;
    public static final int common_signin_btn_light_text_disabled = 2131165191;
    public static final int common_signin_btn_light_text_focused = 2131165192;
    public static final int common_signin_btn_light_text_pressed = 2131165193;
    public static final int common_signin_btn_text_dark = 2131165194;
    public static final int common_signin_btn_text_light = 2131165195;
  }
  
  public static final class drawable
  {
    public static final int common_full_open_on_phone = 2130837518;
    public static final int common_ic_googleplayservices = 2130837519;
  }
  
  public static final class id
  {
    public static final int adjust_height = 2131492864;
    public static final int adjust_width = 2131492865;
    public static final int none = 2131492866;
  }
  
  public static final class integer
  {
    public static final int google_play_services_version = 2131296256;
  }
  
  public static final class string
  {
    public static final int auth_google_play_services_client_facebook_display_name = 2131034150;
    public static final int auth_google_play_services_client_google_display_name = 2131034151;
    public static final int common_android_wear_notification_needs_update_text = 2131034112;
    public static final int common_android_wear_update_text = 2131034113;
    public static final int common_android_wear_update_title = 2131034114;
    public static final int common_google_play_services_api_unavailable_text = 2131034115;
    public static final int common_google_play_services_enable_button = 2131034116;
    public static final int common_google_play_services_enable_text = 2131034117;
    public static final int common_google_play_services_enable_title = 2131034118;
    public static final int common_google_play_services_error_notification_requested_by_msg = 2131034119;
    public static final int common_google_play_services_install_button = 2131034120;
    public static final int common_google_play_services_install_text_phone = 2131034121;
    public static final int common_google_play_services_install_text_tablet = 2131034122;
    public static final int common_google_play_services_install_title = 2131034123;
    public static final int common_google_play_services_invalid_account_text = 2131034124;
    public static final int common_google_play_services_invalid_account_title = 2131034125;
    public static final int common_google_play_services_needs_enabling_title = 2131034126;
    public static final int common_google_play_services_network_error_text = 2131034127;
    public static final int common_google_play_services_network_error_title = 2131034128;
    public static final int common_google_play_services_notification_needs_update_title = 2131034129;
    public static final int common_google_play_services_notification_ticker = 2131034130;
    public static final int common_google_play_services_sign_in_failed_text = 2131034131;
    public static final int common_google_play_services_sign_in_failed_title = 2131034132;
    public static final int common_google_play_services_unknown_issue = 2131034133;
    public static final int common_google_play_services_unsupported_text = 2131034134;
    public static final int common_google_play_services_unsupported_title = 2131034135;
    public static final int common_google_play_services_update_button = 2131034136;
    public static final int common_google_play_services_update_text = 2131034137;
    public static final int common_google_play_services_update_title = 2131034138;
    public static final int common_google_play_services_updating_text = 2131034139;
    public static final int common_google_play_services_updating_title = 2131034140;
    public static final int common_open_on_phone = 2131034141;
  }
  
  public static final class styleable
  {
    public static final int[] LoadingImageView = { 2130771968, 2130771969, 2130771970 };
    public static final int LoadingImageView_circleCrop = 2;
    public static final int LoadingImageView_imageAspectRatio = 1;
    public static final int LoadingImageView_imageAspectRatioAdjust = 0;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\google\android\gms\appindexing\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */