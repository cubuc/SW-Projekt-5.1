package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.design.R.layout;
import android.support.design.R.style;
import android.support.design.R.styleable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v7.app.ActionBar.Tab;
import android.support.v7.internal.widget.TintManager;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

public class TabLayout
  extends HorizontalScrollView
{
  private static final int ANIMATION_DURATION = 300;
  private static final int DEFAULT_HEIGHT = 48;
  private static final int FIXED_WRAP_GUTTER_MIN = 16;
  public static final int GRAVITY_CENTER = 1;
  public static final int GRAVITY_FILL = 0;
  private static final int MAX_TAB_TEXT_LINES = 2;
  public static final int MODE_FIXED = 1;
  public static final int MODE_SCROLLABLE = 0;
  private static final int MOTION_NON_ADJACENT_OFFSET = 24;
  private static final int TAB_MIN_WIDTH_MARGIN = 56;
  private int mContentInsetStart;
  private ValueAnimatorCompat mIndicatorAnimator;
  private int mMode;
  private OnTabSelectedListener mOnTabSelectedListener;
  private final int mRequestedTabMaxWidth;
  private ValueAnimatorCompat mScrollAnimator;
  private Tab mSelectedTab;
  private final int mTabBackgroundResId;
  private View.OnClickListener mTabClickListener;
  private int mTabGravity;
  private int mTabMaxWidth;
  private final int mTabMinWidth;
  private int mTabPaddingBottom;
  private int mTabPaddingEnd;
  private int mTabPaddingStart;
  private int mTabPaddingTop;
  private final SlidingTabStrip mTabStrip;
  private int mTabTextAppearance;
  private ColorStateList mTabTextColors;
  private final ArrayList<Tab> mTabs = new ArrayList();
  
  public TabLayout(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public TabLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public TabLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    setHorizontalScrollBarEnabled(false);
    setFillViewport(true);
    this.mTabStrip = new SlidingTabStrip(paramContext);
    addView(this.mTabStrip, -2, -1);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.TabLayout, paramInt, R.style.Widget_Design_TabLayout);
    this.mTabStrip.setSelectedIndicatorHeight(paramContext.getDimensionPixelSize(R.styleable.TabLayout_tabIndicatorHeight, 0));
    this.mTabStrip.setSelectedIndicatorColor(paramContext.getColor(R.styleable.TabLayout_tabIndicatorColor, 0));
    this.mTabTextAppearance = paramContext.getResourceId(R.styleable.TabLayout_tabTextAppearance, R.style.TextAppearance_Design_Tab);
    paramInt = paramContext.getDimensionPixelSize(R.styleable.TabLayout_tabPadding, 0);
    this.mTabPaddingBottom = paramInt;
    this.mTabPaddingEnd = paramInt;
    this.mTabPaddingTop = paramInt;
    this.mTabPaddingStart = paramInt;
    this.mTabPaddingStart = paramContext.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingStart, this.mTabPaddingStart);
    this.mTabPaddingTop = paramContext.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingTop, this.mTabPaddingTop);
    this.mTabPaddingEnd = paramContext.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingEnd, this.mTabPaddingEnd);
    this.mTabPaddingBottom = paramContext.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingBottom, this.mTabPaddingBottom);
    this.mTabTextColors = loadTextColorFromTextAppearance(this.mTabTextAppearance);
    if (paramContext.hasValue(R.styleable.TabLayout_tabTextColor)) {
      this.mTabTextColors = paramContext.getColorStateList(R.styleable.TabLayout_tabTextColor);
    }
    if (paramContext.hasValue(R.styleable.TabLayout_tabSelectedTextColor))
    {
      paramInt = paramContext.getColor(R.styleable.TabLayout_tabSelectedTextColor, 0);
      this.mTabTextColors = createColorStateList(this.mTabTextColors.getDefaultColor(), paramInt);
    }
    this.mTabMinWidth = paramContext.getDimensionPixelSize(R.styleable.TabLayout_tabMinWidth, 0);
    this.mRequestedTabMaxWidth = paramContext.getDimensionPixelSize(R.styleable.TabLayout_tabMaxWidth, 0);
    this.mTabBackgroundResId = paramContext.getResourceId(R.styleable.TabLayout_tabBackground, 0);
    this.mContentInsetStart = paramContext.getDimensionPixelSize(R.styleable.TabLayout_tabContentStart, 0);
    this.mMode = paramContext.getInt(R.styleable.TabLayout_tabMode, 1);
    this.mTabGravity = paramContext.getInt(R.styleable.TabLayout_tabGravity, 0);
    paramContext.recycle();
    applyModeAndGravity();
  }
  
  private void addTabView(Tab paramTab, int paramInt, boolean paramBoolean)
  {
    paramTab = createTabView(paramTab);
    this.mTabStrip.addView(paramTab, paramInt, createLayoutParamsForTabs());
    if (paramBoolean) {
      paramTab.setSelected(true);
    }
  }
  
  private void addTabView(Tab paramTab, boolean paramBoolean)
  {
    paramTab = createTabView(paramTab);
    this.mTabStrip.addView(paramTab, createLayoutParamsForTabs());
    if (paramBoolean) {
      paramTab.setSelected(true);
    }
  }
  
  private void animateToTab(int paramInt)
  {
    if (paramInt == -1) {
      return;
    }
    if ((getWindowToken() == null) || (!ViewCompat.isLaidOut(this)) || (this.mTabStrip.childrenNeedLayout()))
    {
      setScrollPosition(paramInt, 0.0F, true);
      return;
    }
    int i = getScrollX();
    int j = calculateScrollXForTab(paramInt, 0.0F);
    if (i != j)
    {
      if (this.mScrollAnimator == null)
      {
        this.mScrollAnimator = ViewUtils.createAnimator();
        this.mScrollAnimator.setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
        this.mScrollAnimator.setDuration(300);
        this.mScrollAnimator.setUpdateListener(new ValueAnimatorCompat.AnimatorUpdateListener()
        {
          public void onAnimationUpdate(ValueAnimatorCompat paramAnonymousValueAnimatorCompat)
          {
            TabLayout.this.scrollTo(paramAnonymousValueAnimatorCompat.getAnimatedIntValue(), 0);
          }
        });
      }
      this.mScrollAnimator.setIntValues(i, j);
      this.mScrollAnimator.start();
    }
    this.mTabStrip.animateIndicatorToPosition(paramInt, 300);
  }
  
  private void applyModeAndGravity()
  {
    int i = 0;
    if (this.mMode == 0) {
      i = Math.max(0, this.mContentInsetStart - this.mTabPaddingStart);
    }
    ViewCompat.setPaddingRelative(this.mTabStrip, i, 0, 0, 0);
    switch (this.mMode)
    {
    }
    for (;;)
    {
      updateTabViewsLayoutParams();
      return;
      this.mTabStrip.setGravity(1);
      continue;
      this.mTabStrip.setGravity(8388611);
    }
  }
  
  private int calculateScrollXForTab(int paramInt, float paramFloat)
  {
    int i = 0;
    int j = 0;
    View localView2;
    View localView1;
    if (this.mMode == 0)
    {
      localView2 = this.mTabStrip.getChildAt(paramInt);
      if (paramInt + 1 >= this.mTabStrip.getChildCount()) {
        break label107;
      }
      localView1 = this.mTabStrip.getChildAt(paramInt + 1);
      if (localView2 == null) {
        break label113;
      }
    }
    label107:
    label113:
    for (paramInt = localView2.getWidth();; paramInt = 0)
    {
      i = j;
      if (localView1 != null) {
        i = localView1.getWidth();
      }
      i = localView2.getLeft() + (int)((paramInt + i) * paramFloat * 0.5F) + localView2.getWidth() / 2 - getWidth() / 2;
      return i;
      localView1 = null;
      break;
    }
  }
  
  private void configureTab(Tab paramTab, int paramInt)
  {
    paramTab.setPosition(paramInt);
    this.mTabs.add(paramInt, paramTab);
    int i = this.mTabs.size();
    paramInt += 1;
    while (paramInt < i)
    {
      ((Tab)this.mTabs.get(paramInt)).setPosition(paramInt);
      paramInt += 1;
    }
  }
  
  private static ColorStateList createColorStateList(int paramInt1, int paramInt2)
  {
    int[][] arrayOfInt = new int[2][];
    int[] arrayOfInt1 = new int[2];
    arrayOfInt[0] = SELECTED_STATE_SET;
    arrayOfInt1[0] = paramInt2;
    paramInt2 = 0 + 1;
    arrayOfInt[paramInt2] = EMPTY_STATE_SET;
    arrayOfInt1[paramInt2] = paramInt1;
    return new ColorStateList(arrayOfInt, arrayOfInt1);
  }
  
  private LinearLayout.LayoutParams createLayoutParamsForTabs()
  {
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, -1);
    updateTabViewLayoutParams(localLayoutParams);
    return localLayoutParams;
  }
  
  private TabView createTabView(Tab paramTab)
  {
    paramTab = new TabView(getContext(), paramTab);
    paramTab.setFocusable(true);
    if (this.mTabClickListener == null) {
      this.mTabClickListener = new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          ((TabLayout.TabView)paramAnonymousView).getTab().select();
        }
      };
    }
    paramTab.setOnClickListener(this.mTabClickListener);
    return paramTab;
  }
  
  private int dpToPx(int paramInt)
  {
    return Math.round(getResources().getDisplayMetrics().density * paramInt);
  }
  
  private ColorStateList loadTextColorFromTextAppearance(int paramInt)
  {
    TypedArray localTypedArray = getContext().obtainStyledAttributes(paramInt, R.styleable.TextAppearance);
    try
    {
      ColorStateList localColorStateList = localTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColor);
      return localColorStateList;
    }
    finally
    {
      localTypedArray.recycle();
    }
  }
  
  private void removeTabViewAt(int paramInt)
  {
    this.mTabStrip.removeViewAt(paramInt);
    requestLayout();
  }
  
  private void setSelectedTabView(int paramInt)
  {
    int j = this.mTabStrip.getChildCount();
    int i = 0;
    if (i < j)
    {
      View localView = this.mTabStrip.getChildAt(i);
      if (i == paramInt) {}
      for (boolean bool = true;; bool = false)
      {
        localView.setSelected(bool);
        i += 1;
        break;
      }
    }
  }
  
  private void updateAllTabs()
  {
    int i = 0;
    int j = this.mTabStrip.getChildCount();
    while (i < j)
    {
      updateTab(i);
      i += 1;
    }
  }
  
  private void updateTab(int paramInt)
  {
    TabView localTabView = (TabView)this.mTabStrip.getChildAt(paramInt);
    if (localTabView != null) {
      localTabView.update();
    }
  }
  
  private void updateTabViewLayoutParams(LinearLayout.LayoutParams paramLayoutParams)
  {
    if ((this.mMode == 1) && (this.mTabGravity == 0))
    {
      paramLayoutParams.width = 0;
      paramLayoutParams.weight = 1.0F;
      return;
    }
    paramLayoutParams.width = -2;
    paramLayoutParams.weight = 0.0F;
  }
  
  private void updateTabViewsLayoutParams()
  {
    int i = 0;
    while (i < this.mTabStrip.getChildCount())
    {
      View localView = this.mTabStrip.getChildAt(i);
      updateTabViewLayoutParams((LinearLayout.LayoutParams)localView.getLayoutParams());
      localView.requestLayout();
      i += 1;
    }
  }
  
  public void addTab(@NonNull Tab paramTab)
  {
    addTab(paramTab, this.mTabs.isEmpty());
  }
  
  public void addTab(@NonNull Tab paramTab, int paramInt)
  {
    addTab(paramTab, paramInt, this.mTabs.isEmpty());
  }
  
  public void addTab(@NonNull Tab paramTab, int paramInt, boolean paramBoolean)
  {
    if (paramTab.mParent != this) {
      throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
    }
    addTabView(paramTab, paramInt, paramBoolean);
    configureTab(paramTab, paramInt);
    if (paramBoolean) {
      paramTab.select();
    }
  }
  
  public void addTab(@NonNull Tab paramTab, boolean paramBoolean)
  {
    if (paramTab.mParent != this) {
      throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
    }
    addTabView(paramTab, paramBoolean);
    configureTab(paramTab, this.mTabs.size());
    if (paramBoolean) {
      paramTab.select();
    }
  }
  
  public int getSelectedTabPosition()
  {
    if (this.mSelectedTab != null) {
      return this.mSelectedTab.getPosition();
    }
    return -1;
  }
  
  @Nullable
  public Tab getTabAt(int paramInt)
  {
    return (Tab)this.mTabs.get(paramInt);
  }
  
  public int getTabCount()
  {
    return this.mTabs.size();
  }
  
  public int getTabGravity()
  {
    return this.mTabGravity;
  }
  
  public int getTabMode()
  {
    return this.mMode;
  }
  
  @Nullable
  public ColorStateList getTabTextColors()
  {
    return this.mTabTextColors;
  }
  
  @NonNull
  public Tab newTab()
  {
    return new Tab(this);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = dpToPx(48) + getPaddingTop() + getPaddingBottom();
    switch (View.MeasureSpec.getMode(paramInt2))
    {
    }
    for (;;)
    {
      super.onMeasure(paramInt1, paramInt2);
      if ((this.mMode == 1) && (getChildCount() == 1))
      {
        View localView = getChildAt(0);
        paramInt1 = getMeasuredWidth();
        if (localView.getMeasuredWidth() > paramInt1)
        {
          paramInt2 = getChildMeasureSpec(paramInt2, getPaddingTop() + getPaddingBottom(), localView.getLayoutParams().height);
          localView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2);
        }
      }
      paramInt2 = this.mRequestedTabMaxWidth;
      i = getMeasuredWidth() - dpToPx(56);
      if (paramInt2 != 0)
      {
        paramInt1 = paramInt2;
        if (paramInt2 <= i) {}
      }
      else
      {
        paramInt1 = i;
      }
      this.mTabMaxWidth = paramInt1;
      return;
      paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.min(i, View.MeasureSpec.getSize(paramInt2)), 1073741824);
      continue;
      paramInt2 = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
    }
  }
  
  public void removeAllTabs()
  {
    this.mTabStrip.removeAllViews();
    Iterator localIterator = this.mTabs.iterator();
    while (localIterator.hasNext())
    {
      ((Tab)localIterator.next()).setPosition(-1);
      localIterator.remove();
    }
    this.mSelectedTab = null;
  }
  
  public void removeTab(Tab paramTab)
  {
    if (paramTab.mParent != this) {
      throw new IllegalArgumentException("Tab does not belong to this TabLayout.");
    }
    removeTabAt(paramTab.getPosition());
  }
  
  public void removeTabAt(int paramInt)
  {
    if (this.mSelectedTab != null) {}
    for (int i = this.mSelectedTab.getPosition();; i = 0)
    {
      removeTabViewAt(paramInt);
      localTab = (Tab)this.mTabs.remove(paramInt);
      if (localTab != null) {
        localTab.setPosition(-1);
      }
      int k = this.mTabs.size();
      int j = paramInt;
      while (j < k)
      {
        ((Tab)this.mTabs.get(j)).setPosition(j);
        j += 1;
      }
    }
    if (i == paramInt) {
      if (!this.mTabs.isEmpty()) {
        break label113;
      }
    }
    label113:
    for (Tab localTab = null;; localTab = (Tab)this.mTabs.get(Math.max(0, paramInt - 1)))
    {
      selectTab(localTab);
      return;
    }
  }
  
  void selectTab(Tab paramTab)
  {
    selectTab(paramTab, true);
  }
  
  void selectTab(Tab paramTab, boolean paramBoolean)
  {
    if (this.mSelectedTab == paramTab)
    {
      if (this.mSelectedTab != null)
      {
        if (this.mOnTabSelectedListener != null) {
          this.mOnTabSelectedListener.onTabReselected(this.mSelectedTab);
        }
        animateToTab(paramTab.getPosition());
      }
      return;
    }
    int i;
    if (paramTab != null)
    {
      i = paramTab.getPosition();
      label53:
      setSelectedTabView(i);
      if (paramBoolean)
      {
        if (((this.mSelectedTab != null) && (this.mSelectedTab.getPosition() != -1)) || (i == -1)) {
          break label157;
        }
        setScrollPosition(i, 0.0F, true);
      }
    }
    for (;;)
    {
      if ((this.mSelectedTab != null) && (this.mOnTabSelectedListener != null)) {
        this.mOnTabSelectedListener.onTabUnselected(this.mSelectedTab);
      }
      this.mSelectedTab = paramTab;
      if ((this.mSelectedTab == null) || (this.mOnTabSelectedListener == null)) {
        break;
      }
      this.mOnTabSelectedListener.onTabSelected(this.mSelectedTab);
      return;
      i = -1;
      break label53;
      label157:
      animateToTab(i);
    }
  }
  
  public void setOnTabSelectedListener(OnTabSelectedListener paramOnTabSelectedListener)
  {
    this.mOnTabSelectedListener = paramOnTabSelectedListener;
  }
  
  public void setScrollPosition(int paramInt, float paramFloat, boolean paramBoolean)
  {
    if ((this.mIndicatorAnimator != null) && (this.mIndicatorAnimator.isRunning())) {}
    do
    {
      do
      {
        return;
      } while ((paramInt < 0) || (paramInt >= this.mTabStrip.getChildCount()));
      this.mTabStrip.setIndicatorPositionFromTabPosition(paramInt, paramFloat);
      scrollTo(calculateScrollXForTab(paramInt, paramFloat), 0);
    } while (!paramBoolean);
    setSelectedTabView(Math.round(paramInt + paramFloat));
  }
  
  public void setTabGravity(int paramInt)
  {
    if (this.mTabGravity != paramInt)
    {
      this.mTabGravity = paramInt;
      applyModeAndGravity();
    }
  }
  
  public void setTabMode(int paramInt)
  {
    if (paramInt != this.mMode)
    {
      this.mMode = paramInt;
      applyModeAndGravity();
    }
  }
  
  public void setTabTextColors(int paramInt1, int paramInt2)
  {
    setTabTextColors(createColorStateList(paramInt1, paramInt2));
  }
  
  public void setTabTextColors(@Nullable ColorStateList paramColorStateList)
  {
    if (this.mTabTextColors != paramColorStateList)
    {
      this.mTabTextColors = paramColorStateList;
      updateAllTabs();
    }
  }
  
  public void setTabsFromPagerAdapter(@NonNull PagerAdapter paramPagerAdapter)
  {
    removeAllTabs();
    int i = 0;
    int j = paramPagerAdapter.getCount();
    while (i < j)
    {
      addTab(newTab().setText(paramPagerAdapter.getPageTitle(i)));
      i += 1;
    }
  }
  
  public void setupWithViewPager(@NonNull ViewPager paramViewPager)
  {
    PagerAdapter localPagerAdapter = paramViewPager.getAdapter();
    if (localPagerAdapter == null) {
      throw new IllegalArgumentException("ViewPager does not have a PagerAdapter set");
    }
    setTabsFromPagerAdapter(localPagerAdapter);
    paramViewPager.addOnPageChangeListener(new TabLayoutOnPageChangeListener(this));
    setOnTabSelectedListener(new ViewPagerOnTabSelectedListener(paramViewPager));
    if ((this.mSelectedTab == null) || (this.mSelectedTab.getPosition() != paramViewPager.getCurrentItem())) {
      getTabAt(paramViewPager.getCurrentItem()).select();
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Mode {}
  
  public static abstract interface OnTabSelectedListener
  {
    public abstract void onTabReselected(TabLayout.Tab paramTab);
    
    public abstract void onTabSelected(TabLayout.Tab paramTab);
    
    public abstract void onTabUnselected(TabLayout.Tab paramTab);
  }
  
  private class SlidingTabStrip
    extends LinearLayout
  {
    private int mIndicatorLeft = -1;
    private int mIndicatorRight = -1;
    private int mSelectedIndicatorHeight;
    private final Paint mSelectedIndicatorPaint;
    private int mSelectedPosition = -1;
    private float mSelectionOffset;
    
    SlidingTabStrip(Context paramContext)
    {
      super();
      setWillNotDraw(false);
      this.mSelectedIndicatorPaint = new Paint();
    }
    
    private void setIndicatorPosition(int paramInt1, int paramInt2)
    {
      if ((paramInt1 != this.mIndicatorLeft) || (paramInt2 != this.mIndicatorRight))
      {
        this.mIndicatorLeft = paramInt1;
        this.mIndicatorRight = paramInt2;
        ViewCompat.postInvalidateOnAnimation(this);
      }
    }
    
    private void updateIndicatorPosition()
    {
      View localView = getChildAt(this.mSelectedPosition);
      int i;
      int j;
      if ((localView != null) && (localView.getWidth() > 0))
      {
        int m = localView.getLeft();
        int k = localView.getRight();
        i = m;
        j = k;
        if (this.mSelectionOffset > 0.0F)
        {
          i = m;
          j = k;
          if (this.mSelectedPosition < getChildCount() - 1)
          {
            localView = getChildAt(this.mSelectedPosition + 1);
            i = (int)(this.mSelectionOffset * localView.getLeft() + (1.0F - this.mSelectionOffset) * m);
            j = (int)(this.mSelectionOffset * localView.getRight() + (1.0F - this.mSelectionOffset) * k);
          }
        }
      }
      for (;;)
      {
        setIndicatorPosition(i, j);
        return;
        j = -1;
        i = -1;
      }
    }
    
    void animateIndicatorToPosition(final int paramInt1, int paramInt2)
    {
      final int i;
      Object localObject;
      final int k;
      final int m;
      final int j;
      if (ViewCompat.getLayoutDirection(this) == 1)
      {
        i = 1;
        localObject = getChildAt(paramInt1);
        k = ((View)localObject).getLeft();
        m = ((View)localObject).getRight();
        if (Math.abs(paramInt1 - this.mSelectedPosition) > 1) {
          break label146;
        }
        i = this.mIndicatorLeft;
        j = this.mIndicatorRight;
      }
      for (;;)
      {
        if ((i != k) || (j != m))
        {
          localObject = TabLayout.access$1102(TabLayout.this, ViewUtils.createAnimator());
          ((ValueAnimatorCompat)localObject).setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
          ((ValueAnimatorCompat)localObject).setDuration(paramInt2);
          ((ValueAnimatorCompat)localObject).setFloatValues(0.0F, 1.0F);
          ((ValueAnimatorCompat)localObject).setUpdateListener(new ValueAnimatorCompat.AnimatorUpdateListener()
          {
            public void onAnimationUpdate(ValueAnimatorCompat paramAnonymousValueAnimatorCompat)
            {
              float f = paramAnonymousValueAnimatorCompat.getAnimatedFraction();
              TabLayout.SlidingTabStrip.this.setIndicatorPosition(AnimationUtils.lerp(i, k, f), AnimationUtils.lerp(j, m, f));
            }
          });
          ((ValueAnimatorCompat)localObject).setListener(new ValueAnimatorCompat.AnimatorListenerAdapter()
          {
            public void onAnimationCancel(ValueAnimatorCompat paramAnonymousValueAnimatorCompat)
            {
              TabLayout.SlidingTabStrip.access$1702(TabLayout.SlidingTabStrip.this, paramInt1);
              TabLayout.SlidingTabStrip.access$1802(TabLayout.SlidingTabStrip.this, 0.0F);
            }
            
            public void onAnimationEnd(ValueAnimatorCompat paramAnonymousValueAnimatorCompat)
            {
              TabLayout.SlidingTabStrip.access$1702(TabLayout.SlidingTabStrip.this, paramInt1);
              TabLayout.SlidingTabStrip.access$1802(TabLayout.SlidingTabStrip.this, 0.0F);
            }
          });
          ((ValueAnimatorCompat)localObject).start();
        }
        return;
        i = 0;
        break;
        label146:
        j = TabLayout.this.dpToPx(24);
        if (paramInt1 < this.mSelectedPosition)
        {
          if (i != 0)
          {
            j = k - j;
            i = j;
          }
          else
          {
            j = m + j;
            i = j;
          }
        }
        else if (i != 0)
        {
          j = m + j;
          i = j;
        }
        else
        {
          j = k - j;
          i = j;
        }
      }
    }
    
    boolean childrenNeedLayout()
    {
      int i = 0;
      int j = getChildCount();
      while (i < j)
      {
        if (getChildAt(i).getWidth() <= 0) {
          return true;
        }
        i += 1;
      }
      return false;
    }
    
    public void draw(Canvas paramCanvas)
    {
      super.draw(paramCanvas);
      if ((this.mIndicatorLeft >= 0) && (this.mIndicatorRight > this.mIndicatorLeft)) {
        paramCanvas.drawRect(this.mIndicatorLeft, getHeight() - this.mSelectedIndicatorHeight, this.mIndicatorRight, getHeight(), this.mSelectedIndicatorPaint);
      }
    }
    
    protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      updateIndicatorPosition();
    }
    
    protected void onMeasure(int paramInt1, int paramInt2)
    {
      super.onMeasure(paramInt1, paramInt2);
      if (View.MeasureSpec.getMode(paramInt1) != 1073741824) {}
      int k;
      int i;
      Object localObject;
      do
      {
        do
        {
          return;
        } while ((TabLayout.this.mMode != 1) || (TabLayout.this.mTabGravity != 1));
        k = getChildCount();
        int m = View.MeasureSpec.makeMeasureSpec(0, 0);
        i = 0;
        j = 0;
        while (j < k)
        {
          localObject = getChildAt(j);
          ((View)localObject).measure(m, paramInt2);
          i = Math.max(i, ((View)localObject).getMeasuredWidth());
          j += 1;
        }
      } while (i <= 0);
      int j = TabLayout.this.dpToPx(16);
      if (i * k <= getMeasuredWidth() - j * 2)
      {
        j = 0;
        while (j < k)
        {
          localObject = (LinearLayout.LayoutParams)getChildAt(j).getLayoutParams();
          ((LinearLayout.LayoutParams)localObject).width = i;
          ((LinearLayout.LayoutParams)localObject).weight = 0.0F;
          j += 1;
        }
      }
      TabLayout.access$1302(TabLayout.this, 0);
      TabLayout.this.updateTabViewsLayoutParams();
      super.onMeasure(paramInt1, paramInt2);
    }
    
    void setIndicatorPositionFromTabPosition(int paramInt, float paramFloat)
    {
      if ((TabLayout.this.mIndicatorAnimator != null) && (TabLayout.this.mIndicatorAnimator.isRunning())) {
        return;
      }
      this.mSelectedPosition = paramInt;
      this.mSelectionOffset = paramFloat;
      updateIndicatorPosition();
    }
    
    void setSelectedIndicatorColor(int paramInt)
    {
      this.mSelectedIndicatorPaint.setColor(paramInt);
      ViewCompat.postInvalidateOnAnimation(this);
    }
    
    void setSelectedIndicatorHeight(int paramInt)
    {
      this.mSelectedIndicatorHeight = paramInt;
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  public static final class Tab
  {
    public static final int INVALID_POSITION = -1;
    private CharSequence mContentDesc;
    private View mCustomView;
    private Drawable mIcon;
    private final TabLayout mParent;
    private int mPosition = -1;
    private Object mTag;
    private CharSequence mText;
    
    Tab(TabLayout paramTabLayout)
    {
      this.mParent = paramTabLayout;
    }
    
    @Nullable
    public CharSequence getContentDescription()
    {
      return this.mContentDesc;
    }
    
    View getCustomView()
    {
      return this.mCustomView;
    }
    
    @Nullable
    public Drawable getIcon()
    {
      return this.mIcon;
    }
    
    public int getPosition()
    {
      return this.mPosition;
    }
    
    @Nullable
    public Object getTag()
    {
      return this.mTag;
    }
    
    @Nullable
    public CharSequence getText()
    {
      return this.mText;
    }
    
    public boolean isSelected()
    {
      return this.mParent.getSelectedTabPosition() == this.mPosition;
    }
    
    public void select()
    {
      this.mParent.selectTab(this);
    }
    
    @NonNull
    public Tab setContentDescription(@StringRes int paramInt)
    {
      return setContentDescription(this.mParent.getResources().getText(paramInt));
    }
    
    @NonNull
    public Tab setContentDescription(@Nullable CharSequence paramCharSequence)
    {
      this.mContentDesc = paramCharSequence;
      if (this.mPosition >= 0) {
        this.mParent.updateTab(this.mPosition);
      }
      return this;
    }
    
    @NonNull
    public Tab setCustomView(@LayoutRes int paramInt)
    {
      return setCustomView(LayoutInflater.from(this.mParent.getContext()).inflate(paramInt, null));
    }
    
    @NonNull
    public Tab setCustomView(@Nullable View paramView)
    {
      this.mCustomView = paramView;
      if (this.mPosition >= 0) {
        this.mParent.updateTab(this.mPosition);
      }
      return this;
    }
    
    @NonNull
    public Tab setIcon(@DrawableRes int paramInt)
    {
      return setIcon(TintManager.getDrawable(this.mParent.getContext(), paramInt));
    }
    
    @NonNull
    public Tab setIcon(@Nullable Drawable paramDrawable)
    {
      this.mIcon = paramDrawable;
      if (this.mPosition >= 0) {
        this.mParent.updateTab(this.mPosition);
      }
      return this;
    }
    
    void setPosition(int paramInt)
    {
      this.mPosition = paramInt;
    }
    
    @NonNull
    public Tab setTag(@Nullable Object paramObject)
    {
      this.mTag = paramObject;
      return this;
    }
    
    @NonNull
    public Tab setText(@StringRes int paramInt)
    {
      return setText(this.mParent.getResources().getText(paramInt));
    }
    
    @NonNull
    public Tab setText(@Nullable CharSequence paramCharSequence)
    {
      this.mText = paramCharSequence;
      if (this.mPosition >= 0) {
        this.mParent.updateTab(this.mPosition);
      }
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface TabGravity {}
  
  public static class TabLayoutOnPageChangeListener
    implements ViewPager.OnPageChangeListener
  {
    private int mPreviousScrollState;
    private int mScrollState;
    private final WeakReference<TabLayout> mTabLayoutRef;
    
    public TabLayoutOnPageChangeListener(TabLayout paramTabLayout)
    {
      this.mTabLayoutRef = new WeakReference(paramTabLayout);
    }
    
    public void onPageScrollStateChanged(int paramInt)
    {
      this.mPreviousScrollState = this.mScrollState;
      this.mScrollState = paramInt;
    }
    
    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
    {
      boolean bool2 = true;
      TabLayout localTabLayout = (TabLayout)this.mTabLayoutRef.get();
      if (localTabLayout != null)
      {
        bool1 = bool2;
        if (this.mScrollState != 1) {
          if ((this.mScrollState != 2) || (this.mPreviousScrollState != 1)) {
            break label62;
          }
        }
      }
      label62:
      for (boolean bool1 = bool2;; bool1 = false)
      {
        localTabLayout.setScrollPosition(paramInt1, paramFloat, bool1);
        return;
      }
    }
    
    public void onPageSelected(int paramInt)
    {
      TabLayout localTabLayout = (TabLayout)this.mTabLayoutRef.get();
      TabLayout.Tab localTab;
      if (localTabLayout != null)
      {
        localTab = localTabLayout.getTabAt(paramInt);
        if (this.mScrollState != 0) {
          break label39;
        }
      }
      label39:
      for (boolean bool = true;; bool = false)
      {
        localTabLayout.selectTab(localTab, bool);
        return;
      }
    }
  }
  
  class TabView
    extends LinearLayout
    implements View.OnLongClickListener
  {
    private ImageView mCustomIconView;
    private TextView mCustomTextView;
    private View mCustomView;
    private ImageView mIconView;
    private final TabLayout.Tab mTab;
    private TextView mTextView;
    
    public TabView(Context paramContext, TabLayout.Tab paramTab)
    {
      super();
      this.mTab = paramTab;
      if (TabLayout.this.mTabBackgroundResId != 0) {
        setBackgroundDrawable(TintManager.getDrawable(paramContext, TabLayout.this.mTabBackgroundResId));
      }
      ViewCompat.setPaddingRelative(this, TabLayout.this.mTabPaddingStart, TabLayout.this.mTabPaddingTop, TabLayout.this.mTabPaddingEnd, TabLayout.this.mTabPaddingBottom);
      setGravity(17);
      update();
    }
    
    private void updateTextAndIcon(TabLayout.Tab paramTab, TextView paramTextView, ImageView paramImageView)
    {
      Drawable localDrawable = paramTab.getIcon();
      CharSequence localCharSequence = paramTab.getText();
      int i;
      if (paramImageView != null)
      {
        if (localDrawable != null)
        {
          paramImageView.setImageDrawable(localDrawable);
          paramImageView.setVisibility(0);
          setVisibility(0);
          paramImageView.setContentDescription(paramTab.getContentDescription());
        }
      }
      else
      {
        if (TextUtils.isEmpty(localCharSequence)) {
          break label124;
        }
        i = 1;
        label56:
        if (paramTextView != null)
        {
          if (i == 0) {
            break label130;
          }
          paramTextView.setText(localCharSequence);
          paramTextView.setContentDescription(paramTab.getContentDescription());
          paramTextView.setVisibility(0);
          setVisibility(0);
        }
      }
      for (;;)
      {
        if ((i != 0) || (TextUtils.isEmpty(paramTab.getContentDescription()))) {
          break label144;
        }
        setOnLongClickListener(this);
        return;
        paramImageView.setVisibility(8);
        paramImageView.setImageDrawable(null);
        break;
        label124:
        i = 0;
        break label56;
        label130:
        paramTextView.setVisibility(8);
        paramTextView.setText(null);
      }
      label144:
      setOnLongClickListener(null);
      setLongClickable(false);
    }
    
    public TabLayout.Tab getTab()
    {
      return this.mTab;
    }
    
    @TargetApi(14)
    public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
    {
      super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
      paramAccessibilityEvent.setClassName(ActionBar.Tab.class.getName());
    }
    
    @TargetApi(14)
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo)
    {
      super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
      paramAccessibilityNodeInfo.setClassName(ActionBar.Tab.class.getName());
    }
    
    public boolean onLongClick(View paramView)
    {
      paramView = new int[2];
      getLocationOnScreen(paramView);
      Object localObject = getContext();
      int i = getWidth();
      int j = getHeight();
      int k = ((Context)localObject).getResources().getDisplayMetrics().widthPixels;
      localObject = Toast.makeText((Context)localObject, this.mTab.getContentDescription(), 0);
      ((Toast)localObject).setGravity(49, paramView[0] + i / 2 - k / 2, j);
      ((Toast)localObject).show();
      return true;
    }
    
    public void onMeasure(int paramInt1, int paramInt2)
    {
      super.onMeasure(paramInt1, paramInt2);
      paramInt1 = getMeasuredWidth();
      if ((paramInt1 < TabLayout.this.mTabMinWidth) || (paramInt1 > TabLayout.this.mTabMaxWidth)) {
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(MathUtils.constrain(paramInt1, TabLayout.this.mTabMinWidth, TabLayout.this.mTabMaxWidth), 1073741824), paramInt2);
      }
    }
    
    public void setSelected(boolean paramBoolean)
    {
      if (isSelected() != paramBoolean) {}
      for (int i = 1;; i = 0)
      {
        super.setSelected(paramBoolean);
        if ((i != 0) && (paramBoolean))
        {
          sendAccessibilityEvent(4);
          if (this.mTextView != null) {
            this.mTextView.setSelected(paramBoolean);
          }
          if (this.mIconView != null) {
            this.mIconView.setSelected(paramBoolean);
          }
        }
        return;
      }
    }
    
    final void update()
    {
      TabLayout.Tab localTab = this.mTab;
      Object localObject = localTab.getCustomView();
      if (localObject != null)
      {
        ViewParent localViewParent = ((View)localObject).getParent();
        if (localViewParent != this)
        {
          if (localViewParent != null) {
            ((ViewGroup)localViewParent).removeView((View)localObject);
          }
          addView((View)localObject);
        }
        this.mCustomView = ((View)localObject);
        if (this.mTextView != null) {
          this.mTextView.setVisibility(8);
        }
        if (this.mIconView != null)
        {
          this.mIconView.setVisibility(8);
          this.mIconView.setImageDrawable(null);
        }
        this.mCustomTextView = ((TextView)((View)localObject).findViewById(16908308));
        this.mCustomIconView = ((ImageView)((View)localObject).findViewById(16908294));
        if (this.mCustomView != null) {
          break label283;
        }
        if (this.mIconView == null)
        {
          localObject = (ImageView)LayoutInflater.from(getContext()).inflate(R.layout.layout_tab_icon, this, false);
          addView((View)localObject, 0);
          this.mIconView = ((ImageView)localObject);
        }
        if (this.mTextView == null)
        {
          localObject = (TextView)LayoutInflater.from(getContext()).inflate(R.layout.layout_tab_text, this, false);
          addView((View)localObject);
          this.mTextView = ((TextView)localObject);
        }
        this.mTextView.setTextAppearance(getContext(), TabLayout.this.mTabTextAppearance);
        if (TabLayout.this.mTabTextColors != null) {
          this.mTextView.setTextColor(TabLayout.this.mTabTextColors);
        }
        updateTextAndIcon(localTab, this.mTextView, this.mIconView);
      }
      label283:
      while ((this.mCustomTextView == null) && (this.mCustomIconView == null))
      {
        return;
        if (this.mCustomView != null)
        {
          removeView(this.mCustomView);
          this.mCustomView = null;
        }
        this.mCustomTextView = null;
        this.mCustomIconView = null;
        break;
      }
      updateTextAndIcon(localTab, this.mCustomTextView, this.mCustomIconView);
    }
  }
  
  public static class ViewPagerOnTabSelectedListener
    implements TabLayout.OnTabSelectedListener
  {
    private final ViewPager mViewPager;
    
    public ViewPagerOnTabSelectedListener(ViewPager paramViewPager)
    {
      this.mViewPager = paramViewPager;
    }
    
    public void onTabReselected(TabLayout.Tab paramTab) {}
    
    public void onTabSelected(TabLayout.Tab paramTab)
    {
      this.mViewPager.setCurrentItem(paramTab.getPosition());
    }
    
    public void onTabUnselected(TabLayout.Tab paramTab) {}
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\Simplelink_Sensortag\classes-dex2jar.jar!\android\support\design\widget\TabLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */