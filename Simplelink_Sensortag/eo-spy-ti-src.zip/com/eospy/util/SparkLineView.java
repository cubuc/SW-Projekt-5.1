package com.eospy.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.PointF;
import android.view.View;
import android.view.View.MeasureSpec;
import java.util.ArrayList;

@SuppressLint({"DrawAllocation"})
public class SparkLineView
  extends View
{
  public boolean autoScale = false;
  public boolean autoScaleBounceBack = false;
  private ArrayList<Float> dataPoints = new ArrayList();
  public float displayWidth;
  public float maxVal = 1.0F;
  public float minVal = 0.0F;
  private final int numberOfPoints = 15;
  private final Paint pointFillPaint = new Paint() {};
  private final Paint pointStrokePaint = new Paint() {};
  private final Paint sparkLinePaint = new Paint() {};
  
  public SparkLineView(Context paramContext)
  {
    super(paramContext);
    int i = 0;
    while (i < 15)
    {
      this.dataPoints.add(Float.valueOf(0.0F));
      i += 1;
    }
    setWillNotDraw(false);
    setBackgroundColor(0);
    this.displayWidth = 200.0F;
  }
  
  public void addValue(float paramFloat)
  {
    this.dataPoints.add(Float.valueOf(paramFloat));
    invalidate();
  }
  
  PointF controlPointForPoints(PointF paramPointF1, PointF paramPointF2)
  {
    PointF localPointF = midPointForPoints(paramPointF1, paramPointF2);
    Float localFloat = Float.valueOf(Math.abs(paramPointF2.y - localPointF.y));
    if (paramPointF1.y < paramPointF2.y) {
      localPointF.y += localFloat.floatValue();
    }
    while (paramPointF1.y <= paramPointF2.y) {
      return localPointF;
    }
    localPointF.y -= localFloat.floatValue();
    return localPointF;
  }
  
  PointF midPointForPoints(PointF paramPointF1, PointF paramPointF2)
  {
    PointF localPointF = new PointF();
    localPointF.x = ((paramPointF1.x + paramPointF2.x) / 2.0F);
    localPointF.y = ((paramPointF1.y + paramPointF2.y) / 2.0F);
    return localPointF;
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    int i = 15;
    float f5 = getWidth();
    float f6 = getHeight();
    float f3 = 0.0F;
    float f1 = 0.0F;
    super.onDraw(paramCanvas);
    Object localObject1 = new Path();
    if (this.dataPoints.size() - 1 - 15 < 0) {
      i = this.dataPoints.size() - 1;
    }
    ArrayList localArrayList = new ArrayList(this.dataPoints.subList(this.dataPoints.size() - 1 - i, this.dataPoints.size() - 1));
    int j = 0;
    Object localObject2;
    if (j < i)
    {
      localObject2 = (Float)localArrayList.get(j);
      float f2 = f3;
      if (((Float)localObject2).floatValue() > f3) {
        f2 = ((Float)localObject2).floatValue();
      }
      float f4 = f1;
      if (((Float)localObject2).floatValue() < f1) {
        f4 = ((Float)localObject2).floatValue();
      }
      if (this.autoScale)
      {
        if (((Float)localObject2).floatValue() <= this.maxVal) {
          break label242;
        }
        this.maxVal = (((Float)localObject2).floatValue() + 0.01F);
        if (this.minVal >= -0.001D) {
          break label234;
        }
        this.minVal = (-((Float)localObject2).floatValue() - 0.01F);
      }
      for (;;)
      {
        j += 1;
        f3 = f2;
        f1 = f4;
        break;
        label234:
        this.minVal = 0.0F;
        continue;
        label242:
        if (((Float)localObject2).floatValue() < this.minVal)
        {
          this.minVal = (((Float)localObject2).floatValue() - 0.01F);
          this.maxVal = (-((Float)localObject2).floatValue() + 0.01F);
        }
      }
    }
    if (this.autoScaleBounceBack)
    {
      f1 = Math.max(f3, Math.abs(f1));
      this.maxVal = f1;
      if (this.minVal < -0.1F) {
        this.minVal = (-f1);
      }
    }
    else
    {
      j = 0;
      label324:
      if (j >= i) {
        break label650;
      }
      if (j != 0) {
        break label397;
      }
      localObject2 = (Float)localArrayList.get(j);
      ((Path)localObject1).moveTo(0.0F, f6 - f6 / (this.maxVal - this.minVal) * (((Float)localObject2).floatValue() - this.minVal));
    }
    for (;;)
    {
      j += 1;
      break label324;
      this.minVal = 0.0F;
      break;
      label397:
      Object localObject3 = (Float)localArrayList.get(j - 1);
      Float localFloat = (Float)localArrayList.get(j);
      PointF localPointF = new PointF();
      localObject2 = new PointF();
      localPointF.x = ((f5 - 2.0F * 15.0F) / i * (j - 1) + 15.0F);
      localPointF.y = (f6 - 15.0F - (f6 - 2.0F * 15.0F) / (this.maxVal - this.minVal) * (((Float)localObject3).floatValue() - this.minVal));
      ((PointF)localObject2).x = ((f5 - 2.0F * 15.0F) / i * j + 15.0F);
      ((PointF)localObject2).y = (f6 - 15.0F - (f6 - 2.0F * 15.0F) / (this.maxVal - this.minVal) * (localFloat.floatValue() - this.minVal));
      localObject3 = midPointForPoints(localPointF, (PointF)localObject2);
      localPointF = controlPointForPoints((PointF)localObject3, localPointF);
      ((Path)localObject1).quadTo(localPointF.x, localPointF.y, ((PointF)localObject3).x, ((PointF)localObject3).y);
      localPointF = controlPointForPoints((PointF)localObject3, (PointF)localObject2);
      ((Path)localObject1).quadTo(localPointF.x, localPointF.y, ((PointF)localObject2).x, ((PointF)localObject2).y);
    }
    label650:
    paramCanvas.drawPath((Path)localObject1, this.sparkLinePaint);
    j = 0;
    while (j < i)
    {
      localObject2 = (Float)localArrayList.get(j);
      localObject1 = Float.valueOf((f5 - 2.0F * 15.0F) / i * j + 15.0F);
      localObject2 = Float.valueOf(f6 - 15.0F - (f6 - 2.0F * 15.0F) / (this.maxVal - this.minVal) * (((Float)localObject2).floatValue() - this.minVal));
      paramCanvas.drawCircle(((Float)localObject1).floatValue(), ((Float)localObject2).floatValue(), 10.0F, this.pointStrokePaint);
      paramCanvas.drawCircle(((Float)localObject1).floatValue(), ((Float)localObject2).floatValue(), 7.0F, this.pointFillPaint);
      j += 1;
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    int i = View.MeasureSpec.getSize(paramInt1) - 40;
    paramInt1 = paramInt2;
    if (paramInt2 < 200) {
      paramInt1 = 200;
    }
    paramInt2 = i;
    if (i < this.displayWidth) {
      paramInt2 = (int)this.displayWidth;
    }
    setMeasuredDimension(paramInt2, paramInt1);
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setColor(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.pointFillPaint.setARGB(paramInt1, paramInt2, paramInt3, paramInt4);
    this.sparkLinePaint.setARGB(paramInt1, paramInt2, paramInt3, paramInt4);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\util\SparkLineView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */