package com.eospy.client;

import android.os.AsyncTask;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class RequestManager
{
  private static final int TIMEOUT = 15000;
  
  public static boolean sendRequest(String paramString)
  {
    boolean bool = false;
    Object localObject4 = null;
    Object localObject3 = null;
    Object localObject1 = localObject3;
    Object localObject2 = localObject4;
    for (;;)
    {
      try
      {
        paramString = (HttpURLConnection)new URL(paramString).openConnection();
        localObject1 = localObject3;
        localObject2 = localObject4;
        paramString.setReadTimeout(15000);
        localObject1 = localObject3;
        localObject2 = localObject4;
        paramString.setConnectTimeout(15000);
        localObject1 = localObject3;
        localObject2 = localObject4;
        paramString.connect();
        localObject1 = localObject3;
        localObject2 = localObject4;
        paramString = paramString.getInputStream();
        localObject1 = paramString;
        localObject2 = paramString;
        int i = paramString.read();
        if (i != -1) {
          continue;
        }
        if (paramString == null) {}
      }
      catch (IOException paramString)
      {
        if (localObject1 == null) {
          continue;
        }
        try
        {
          ((InputStream)localObject1).close();
          return false;
        }
        catch (IOException paramString)
        {
          return false;
        }
      }
      finally
      {
        if (localObject2 == null) {
          continue;
        }
        try
        {
          ((InputStream)localObject2).close();
          throw paramString;
        }
        catch (IOException paramString) {}
      }
      try
      {
        paramString.close();
        bool = true;
        return bool;
      }
      catch (IOException paramString)
      {
        return false;
      }
    }
    return false;
  }
  
  public static void sendRequestAsync(String paramString, RequestHandler paramRequestHandler)
  {
    new RequestAsyncTask(paramRequestHandler).execute(new String[] { paramString });
  }
  
  private static class RequestAsyncTask
    extends AsyncTask<String, Void, Boolean>
  {
    private RequestManager.RequestHandler handler;
    
    public RequestAsyncTask(RequestManager.RequestHandler paramRequestHandler)
    {
      this.handler = paramRequestHandler;
    }
    
    protected Boolean doInBackground(String... paramVarArgs)
    {
      return Boolean.valueOf(RequestManager.sendRequest(paramVarArgs[0]));
    }
    
    protected void onPostExecute(Boolean paramBoolean)
    {
      this.handler.onComplete(paramBoolean.booleanValue());
    }
  }
  
  public static abstract interface RequestHandler
  {
    public abstract void onComplete(boolean paramBoolean);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\RequestManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */