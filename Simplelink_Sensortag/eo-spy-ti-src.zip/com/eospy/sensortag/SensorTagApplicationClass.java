package com.eospy.sensortag;

import android.app.Application;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.widget.Toast;
import com.eospy.common.BluetoothLeService;
import com.eospy.common.BluetoothLeService.LocalBinder;
import com.eospy.util.CustomToast;

public class SensorTagApplicationClass
  extends Application
{
  private static final int REQ_ENABLE_BT = 0;
  public static BluetoothManager mBluetoothManager;
  public boolean mBleSupported = true;
  private BluetoothLeService mBluetoothLeService = null;
  public BluetoothAdapter mBtAdapter = null;
  public boolean mBtAdapterEnabled = false;
  private IntentFilter mFilter;
  private BroadcastReceiver mReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      if ("android.bluetooth.adapter.action.STATE_CHANGED".equals(paramAnonymousIntent.getAction())) {}
      switch (SensorTagApplicationClass.this.mBtAdapter.getState())
      {
      case 10: 
      case 11: 
      default: 
        return;
      }
      SensorTagApplicationClass.this.startBluetoothLeService();
    }
  };
  private final ServiceConnection mServiceConnection = new ServiceConnection()
  {
    public void onServiceConnected(ComponentName paramAnonymousComponentName, IBinder paramAnonymousIBinder)
    {
      SensorTagApplicationClass.access$002(SensorTagApplicationClass.this, ((BluetoothLeService.LocalBinder)paramAnonymousIBinder).getService());
      if (!SensorTagApplicationClass.this.mBluetoothLeService.initialize()) {}
      while (SensorTagApplicationClass.this.mBluetoothLeService.numConnectedDevices() <= 0) {
        return;
      }
    }
    
    public void onServiceDisconnected(ComponentName paramAnonymousComponentName)
    {
      SensorTagApplicationClass.access$002(SensorTagApplicationClass.this, null);
    }
  };
  
  private void startBluetoothLeService()
  {
    Intent localIntent = new Intent(this, BluetoothLeService.class);
    startService(localIntent);
    if (!bindService(localIntent, this.mServiceConnection, 1)) {
      CustomToast.middleBottom(this, "Bind to BluetoothLeService failed");
    }
  }
  
  public void onCreate()
  {
    if (!getPackageManager().hasSystemFeature("android.hardware.bluetooth_le"))
    {
      Toast.makeText(this, 2131034153, 1).show();
      this.mBleSupported = false;
    }
    mBluetoothManager = (BluetoothManager)getSystemService("bluetooth");
    this.mBtAdapter = mBluetoothManager.getAdapter();
    if (this.mBtAdapter == null)
    {
      Toast.makeText(this, 2131034158, 1).show();
      this.mBleSupported = false;
    }
    this.mFilter = new IntentFilter("android.bluetooth.adapter.action.STATE_CHANGED");
    registerReceiver(this.mReceiver, this.mFilter);
    if (!this.mBtAdapter.isEnabled())
    {
      Intent localIntent = new Intent("android.bluetooth.adapter.action.REQUEST_ENABLE");
      localIntent.setFlags(268435456);
      startActivity(localIntent);
    }
    startBluetoothLeService();
    super.onCreate();
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\SensorTagApplicationClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */