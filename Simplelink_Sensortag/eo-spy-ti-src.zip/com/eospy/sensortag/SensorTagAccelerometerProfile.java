package com.eospy.sensortag;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.widget.TextView;
import com.eospy.common.BluetoothLeService;
import com.eospy.common.GattInfo;
import com.eospy.common.GenericBluetoothProfile;
import com.eospy.util.GenericCharacteristicTableRow;
import com.eospy.util.Point3D;
import com.eospy.util.SparkLineView;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SensorTagAccelerometerProfile
  extends GenericBluetoothProfile
{
  public SensorTagAccelerometerProfile(Context paramContext, BluetoothDevice paramBluetoothDevice, BluetoothGattService paramBluetoothGattService, BluetoothLeService paramBluetoothLeService)
  {
    super(paramContext, paramBluetoothDevice, paramBluetoothGattService, paramBluetoothLeService);
    this.tRow = new GenericCharacteristicTableRow(paramContext);
    paramContext = this.mBTService.getCharacteristics().iterator();
    while (paramContext.hasNext())
    {
      paramBluetoothDevice = (BluetoothGattCharacteristic)paramContext.next();
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_ACC_DATA.toString())) {
        this.dataC = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_ACC_CONF.toString())) {
        this.configC = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_ACC_PERI.toString())) {
        this.periodC = paramBluetoothDevice;
      }
    }
    this.tRow.sl1.autoScale = true;
    this.tRow.sl1.autoScaleBounceBack = true;
    this.tRow.sl2.autoScale = true;
    this.tRow.sl2.autoScaleBounceBack = true;
    this.tRow.sl2.setColor(255, 0, 150, 125);
    this.tRow.sl2.setVisibility(0);
    this.tRow.sl2.setEnabled(true);
    this.tRow.sl3.autoScale = true;
    this.tRow.sl3.autoScaleBounceBack = true;
    this.tRow.sl3.setColor(255, 0, 0, 0);
    this.tRow.sl3.setVisibility(0);
    this.tRow.sl3.setEnabled(true);
    this.tRow.setIcon(getIconPrefix(), this.dataC.getUuid().toString());
    this.tRow.title.setText(GattInfo.uuidToName(UUID.fromString(this.dataC.getUuid().toString())));
    this.tRow.uuidLabel.setText(this.dataC.getUuid().toString());
    this.tRow.value.setText("X:0.00G, Y:0.00G, Z:0.00G");
  }
  
  public static boolean isCorrectService(BluetoothGattService paramBluetoothGattService)
  {
    return paramBluetoothGattService.getUuid().toString().compareTo(SensorTagGatt.UUID_ACC_SERV.toString()) == 0;
  }
  
  public void didUpdateValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic)
  {
    if (paramBluetoothGattCharacteristic.equals(this.dataC))
    {
      paramBluetoothGattCharacteristic = Sensor.ACCELEROMETER.convert(this.dataC.getValue());
      if (!this.tRow.config) {
        this.tRow.value.setText(String.format("X:%.2fG, Y:%.2fG, Z:%.2fG", new Object[] { Double.valueOf(paramBluetoothGattCharacteristic.x), Double.valueOf(paramBluetoothGattCharacteristic.y), Double.valueOf(paramBluetoothGattCharacteristic.z) }));
      }
      this.tRow.sl1.addValue((float)paramBluetoothGattCharacteristic.x);
      this.tRow.sl2.addValue((float)paramBluetoothGattCharacteristic.y);
      this.tRow.sl3.addValue((float)paramBluetoothGattCharacteristic.z);
    }
  }
  
  public Map<String, String> getMQTTMap()
  {
    Point3D localPoint3D = Sensor.ACCELEROMETER.convert(this.dataC.getValue());
    HashMap localHashMap = new HashMap();
    localHashMap.put("acc_x", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.x) }));
    localHashMap.put("acc_y", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.y) }));
    localHashMap.put("acc_z", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.z) }));
    com.eospy.client.PositionProvider.accel_xSensor = (float)localPoint3D.x;
    com.eospy.client.PositionProvider.accel_ySensor = (float)localPoint3D.y;
    com.eospy.client.PositionProvider.accel_zSensor = (float)localPoint3D.z;
    return localHashMap;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\SensorTagAccelerometerProfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */