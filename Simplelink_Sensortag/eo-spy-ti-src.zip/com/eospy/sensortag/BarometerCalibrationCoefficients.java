package com.eospy.sensortag;

import java.util.List;

public enum BarometerCalibrationCoefficients
{
  INSTANCE;
  
  public volatile List<Integer> barometerCalibrationCoefficients;
  public volatile double heightCalibration;
  
  private BarometerCalibrationCoefficients() {}
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\BarometerCalibrationCoefficients.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */