package com.eospy.sensortag;

import android.content.Context;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.TextView;
import com.eospy.util.GenericCharacteristicTableRow;
import com.eospy.util.SparkLineView;
import java.util.Timer;
import java.util.TimerTask;

public class SensorTagSimpleKeysTableRow
  extends GenericCharacteristicTableRow
{
  protected byte lastKeys;
  protected ImageView leftKeyPressStateImage;
  protected ImageView reedStateImage;
  protected ImageView rightKeyPressStateImage;
  protected updateSparkLinesTimerTask sparkLineUpdateTask;
  protected Timer sparkLineUpdateTimer;
  
  public SensorTagSimpleKeysTableRow(Context paramContext)
  {
    super(paramContext);
    this.periodBar.setEnabled(false);
    this.periodLegend.setText("Sensor period (\"Notification\")");
    this.sl1.maxVal = 1.0F;
    this.sl1.setColor(255, 255, 0, 0);
    this.sl2.maxVal = 1.0F;
    this.sl2.setColor(255, 17, 136, 153);
    this.sl2.setVisibility(0);
    this.sl3.maxVal = 1.0F;
    this.sl3.setColor(255, 0, 0, 0);
    this.sl3.setVisibility(0);
    this.sl2.setEnabled(true);
    this.sl3.setEnabled(true);
    this.value.setVisibility(4);
    final int i = this.sl3.getId();
    this.leftKeyPressStateImage = new ImageView(paramContext) {};
    this.leftKeyPressStateImage.setImageResource(2130837538);
    this.rightKeyPressStateImage = new ImageView(paramContext) {};
    this.rightKeyPressStateImage.setImageResource(2130837550);
    this.reedStateImage = new ImageView(paramContext) {};
    this.reedStateImage.setImageResource(2130837547);
    paramContext = new RelativeLayout.LayoutParams(210, 180) {};
    this.leftKeyPressStateImage.setLayoutParams(paramContext);
    this.leftKeyPressStateImage.setPadding(20, 20, 20, 20);
    paramContext = new RelativeLayout.LayoutParams(160, 160) {};
    this.rightKeyPressStateImage.setPadding(10, 10, 10, 10);
    this.rightKeyPressStateImage.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(160, 160) {};
    this.reedStateImage.setLayoutParams(paramContext);
    this.reedStateImage.setPadding(10, 10, 10, 10);
    paramContext = new RelativeLayout.LayoutParams(-1, -1) {};
    this.sl1.setLayoutParams(paramContext);
    this.sl2.setLayoutParams(paramContext);
    this.sl3.setLayoutParams(paramContext);
    this.rowLayout.addView(this.leftKeyPressStateImage);
    this.rowLayout.addView(this.rightKeyPressStateImage);
    this.rowLayout.addView(this.reedStateImage);
    this.sparkLineUpdateTimer = new Timer();
    this.sparkLineUpdateTask = new updateSparkLinesTimerTask(this);
    this.sparkLineUpdateTimer.scheduleAtFixedRate(this.sparkLineUpdateTask, 1000L, 100L);
  }
  
  public void grayedOut(boolean paramBoolean)
  {
    super.grayedOut(paramBoolean);
    if (paramBoolean)
    {
      this.leftKeyPressStateImage.setAlpha(0.4F);
      this.rightKeyPressStateImage.setAlpha(0.4F);
      this.reedStateImage.setAlpha(0.4F);
      this.sl3.setAlpha(0.2F);
      return;
    }
    this.leftKeyPressStateImage.setAlpha(1.0F);
    this.rightKeyPressStateImage.setAlpha(1.0F);
    this.reedStateImage.setAlpha(1.0F);
    this.sl3.setAlpha(1.0F);
  }
  
  public void onAnimationEnd(Animation paramAnimation)
  {
    super.onAnimationEnd(paramAnimation);
    if (this.config == true)
    {
      this.leftKeyPressStateImage.setVisibility(4);
      this.rightKeyPressStateImage.setVisibility(4);
      this.reedStateImage.setVisibility(4);
      return;
    }
    this.leftKeyPressStateImage.setVisibility(0);
    this.rightKeyPressStateImage.setVisibility(0);
    this.reedStateImage.setVisibility(0);
  }
  
  public void onClick(View paramView)
  {
    super.onClick(paramView);
    paramView = new AlphaAnimation(1.0F, 0.0F);
    paramView.setAnimationListener(this);
    paramView.setDuration(500L);
    paramView.setStartOffset(0L);
    AlphaAnimation localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
    localAlphaAnimation.setAnimationListener(this);
    localAlphaAnimation.setDuration(500L);
    localAlphaAnimation.setStartOffset(250L);
    if (this.config == true)
    {
      this.leftKeyPressStateImage.startAnimation(paramView);
      this.rightKeyPressStateImage.startAnimation(paramView);
      this.reedStateImage.startAnimation(paramView);
      return;
    }
    this.leftKeyPressStateImage.startAnimation(localAlphaAnimation);
    this.rightKeyPressStateImage.startAnimation(localAlphaAnimation);
    this.reedStateImage.startAnimation(localAlphaAnimation);
  }
  
  class updateSparkLinesTimerTask
    extends TimerTask
  {
    SensorTagSimpleKeysTableRow param;
    
    public updateSparkLinesTimerTask(SensorTagSimpleKeysTableRow paramSensorTagSimpleKeysTableRow)
    {
      this.param = paramSensorTagSimpleKeysTableRow;
    }
    
    public void run()
    {
      this.param.post(new Runnable()
      {
        public void run()
        {
          if ((SensorTagSimpleKeysTableRow.updateSparkLinesTimerTask.this.param.lastKeys & 0x1) == 1)
          {
            SensorTagSimpleKeysTableRow.updateSparkLinesTimerTask.this.param.sl1.addValue(1.0F);
            if ((SensorTagSimpleKeysTableRow.updateSparkLinesTimerTask.this.param.lastKeys & 0x2) != 2) {
              break label108;
            }
            SensorTagSimpleKeysTableRow.updateSparkLinesTimerTask.this.param.sl2.addValue(1.0F);
          }
          for (;;)
          {
            if ((SensorTagSimpleKeysTableRow.updateSparkLinesTimerTask.this.param.lastKeys & 0x4) != 4) {
              break label125;
            }
            SensorTagSimpleKeysTableRow.updateSparkLinesTimerTask.this.param.sl3.addValue(1.0F);
            return;
            SensorTagSimpleKeysTableRow.updateSparkLinesTimerTask.this.param.sl1.addValue(0.0F);
            break;
            label108:
            SensorTagSimpleKeysTableRow.updateSparkLinesTimerTask.this.param.sl2.addValue(0.0F);
          }
          label125:
          SensorTagSimpleKeysTableRow.updateSparkLinesTimerTask.this.param.sl3.addValue(0.0F);
        }
      });
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\SensorTagSimpleKeysTableRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */