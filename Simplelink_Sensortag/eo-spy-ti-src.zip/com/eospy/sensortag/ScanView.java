package com.eospy.sensortag;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.eospy.common.BleDeviceInfo;
import com.eospy.util.CustomTimer;
import com.eospy.util.CustomTimerCallback;
import java.util.List;

public class ScanView
  extends Fragment
{
  private final int CONNECT_TIMEOUT = 20;
  private final int SCAN_TIMEOUT = 10;
  private MainActivity mActivity = null;
  private Button mBtnScan = null;
  private boolean mBusy;
  private CustomTimerCallback mClearStatusCallback = new CustomTimerCallback()
  {
    public void onTick(int paramAnonymousInt) {}
    
    public void onTimeout()
    {
      ScanView.this.mActivity.runOnUiThread(new Runnable()
      {
        public void run()
        {
          ScanView.this.setStatus("");
        }
      });
      ScanView.access$502(ScanView.this, null);
    }
  };
  private CustomTimer mConnectTimer = null;
  private Context mContext;
  private DeviceListAdapter mDeviceAdapter = null;
  private AdapterView.OnItemClickListener mDeviceClickListener = new AdapterView.OnItemClickListener()
  {
    public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
    {
      ScanView.access$002(ScanView.this, new CustomTimer(null, 20, ScanView.this.mPgConnectCallback));
      ScanView.this.mBtnScan.setEnabled(false);
      ScanView.this.mDeviceAdapter.notifyDataSetChanged();
      ScanView.this.mActivity.onDeviceClick(paramAnonymousInt);
    }
  };
  private ListView mDeviceListView = null;
  private TextView mEmptyMsg;
  private CustomTimerCallback mPgConnectCallback = new CustomTimerCallback()
  {
    public void onTick(int paramAnonymousInt)
    {
      ScanView.this.mActivity.refreshBusyIndicator();
    }
    
    public void onTimeout()
    {
      ScanView.this.mActivity.onConnectTimeout();
      ScanView.this.mBtnScan.setEnabled(true);
    }
  };
  private CustomTimerCallback mPgScanCallback = new CustomTimerCallback()
  {
    public void onTick(int paramAnonymousInt)
    {
      ScanView.this.mActivity.refreshBusyIndicator();
    }
    
    public void onTimeout()
    {
      ScanView.this.mActivity.onScanTimeout();
    }
  };
  private CustomTimer mScanTimer = null;
  private TextView mStatus;
  private CustomTimer mStatusTimer;
  
  private void stopTimers()
  {
    if (this.mScanTimer != null)
    {
      this.mScanTimer.stop();
      this.mScanTimer = null;
    }
    if (this.mConnectTimer != null)
    {
      this.mConnectTimer.stop();
      this.mConnectTimer = null;
    }
  }
  
  void notifyDataSetChanged()
  {
    List localList = this.mActivity.getDeviceInfoList();
    if (this.mDeviceAdapter == null) {
      this.mDeviceAdapter = new DeviceListAdapter(this.mActivity, localList);
    }
    this.mDeviceListView.setAdapter(this.mDeviceAdapter);
    this.mDeviceAdapter.notifyDataSetChanged();
    if (localList.size() > 0)
    {
      this.mEmptyMsg.setVisibility(8);
      return;
    }
    this.mEmptyMsg.setVisibility(0);
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    paramLayoutInflater = paramLayoutInflater.inflate(2130903049, paramViewGroup, false);
    this.mActivity = ((MainActivity)getActivity());
    this.mContext = this.mActivity.getApplicationContext();
    this.mStatus = ((TextView)paramLayoutInflater.findViewById(2131492883));
    this.mBtnScan = ((Button)paramLayoutInflater.findViewById(2131492894));
    this.mDeviceListView = ((ListView)paramLayoutInflater.findViewById(2131492892));
    this.mDeviceListView.setClickable(true);
    this.mDeviceListView.setOnItemClickListener(this.mDeviceClickListener);
    this.mEmptyMsg = ((TextView)paramLayoutInflater.findViewById(2131492893));
    this.mBusy = false;
    this.mActivity.onScanViewReady(paramLayoutInflater);
    return paramLayoutInflater;
  }
  
  public void onDestroy()
  {
    super.onDestroy();
  }
  
  void setBusy(boolean paramBoolean)
  {
    if (paramBoolean != this.mBusy)
    {
      this.mBusy = paramBoolean;
      if (!this.mBusy)
      {
        stopTimers();
        this.mBtnScan.setEnabled(true);
        this.mDeviceAdapter.notifyDataSetChanged();
      }
      this.mActivity.showBusyIndicator(paramBoolean);
    }
  }
  
  void setError(String paramString)
  {
    setBusy(false);
    stopTimers();
    this.mStatus.setText(paramString);
    this.mStatus.setTextAppearance(this.mContext, 2131361814);
  }
  
  void setStatus(String paramString)
  {
    this.mStatus.setText(paramString);
    this.mStatus.setTextAppearance(this.mContext, 2131361815);
  }
  
  void setStatus(String paramString, int paramInt)
  {
    setStatus(paramString);
    this.mStatusTimer = new CustomTimer(null, paramInt, this.mClearStatusCallback);
  }
  
  void updateGui(boolean paramBoolean)
  {
    if (this.mBtnScan == null) {
      return;
    }
    setBusy(paramBoolean);
    if (paramBoolean)
    {
      this.mScanTimer = new CustomTimer(null, 10, this.mPgScanCallback);
      this.mBtnScan.setText("Stop");
      this.mBtnScan.setCompoundDrawablesWithIntrinsicBounds(0, 0, 2130837531, 0);
      this.mStatus.setTextAppearance(this.mContext, 2131361812);
      this.mStatus.setText("Scanning...");
      this.mEmptyMsg.setText(2131034188);
      this.mActivity.updateGuiState();
      return;
    }
    this.mStatus.setTextAppearance(this.mContext, 2131361815);
    this.mBtnScan.setText("Scan");
    this.mBtnScan.setCompoundDrawablesWithIntrinsicBounds(0, 0, 2130837532, 0);
    this.mEmptyMsg.setText(2131034193);
    this.mActivity.setProgressBarIndeterminateVisibility(false);
    this.mDeviceAdapter.notifyDataSetChanged();
  }
  
  @SuppressLint({"InflateParams"})
  class DeviceListAdapter
    extends BaseAdapter
  {
    private List<BleDeviceInfo> mDevices;
    private LayoutInflater mInflater;
    
    public DeviceListAdapter(List<BleDeviceInfo> paramList)
    {
      this.mInflater = LayoutInflater.from(paramList);
      List localList;
      this.mDevices = localList;
    }
    
    public int getCount()
    {
      return this.mDevices.size();
    }
    
    public Object getItem(int paramInt)
    {
      return this.mDevices.get(paramInt);
    }
    
    public long getItemId(int paramInt)
    {
      return paramInt;
    }
    
    public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      Object localObject;
      if (paramView != null)
      {
        paramView = (ViewGroup)paramView;
        paramViewGroup = (BleDeviceInfo)this.mDevices.get(paramInt);
        BluetoothDevice localBluetoothDevice = paramViewGroup.getBluetoothDevice();
        paramInt = paramViewGroup.getRssi();
        localObject = localBluetoothDevice.getName();
        paramViewGroup = (ViewGroup)localObject;
        if (localObject == null) {
          paramViewGroup = new String("Unknown device");
        }
        localObject = paramViewGroup + "\n" + localBluetoothDevice.getAddress() + "\nRssi: " + paramInt + " dBm";
        ((TextView)paramView.findViewById(2131492888)).setText((CharSequence)localObject);
        localObject = (ImageView)paramView.findViewById(2131492887);
        if ((!paramViewGroup.equals("SensorTag2")) && (!paramViewGroup.equals("CC2650 SensorTag"))) {
          break label200;
        }
        ((ImageView)localObject).setImageResource(2130837554);
        label152:
        paramViewGroup = (Button)paramView.findViewById(2131492889);
        if (ScanView.this.mConnectTimer != null) {
          break label210;
        }
      }
      label200:
      label210:
      for (boolean bool = true;; bool = false)
      {
        paramViewGroup.setEnabled(bool);
        return paramView;
        paramView = (ViewGroup)this.mInflater.inflate(2130903045, null);
        break;
        ((ImageView)localObject).setImageResource(2130837588);
        break label152;
      }
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\ScanView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */