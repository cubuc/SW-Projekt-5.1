package com.eospy.sensortag;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import com.eospy.util.GenericCharacteristicTableRow;
import com.eospy.util.SparkLineView;

public class SensorTagMovementTableRow
  extends GenericCharacteristicTableRow
{
  public final TextView gyroValue;
  public final TextView magValue;
  public final SparkLineView sl4;
  public final SparkLineView sl5;
  public final SparkLineView sl6;
  public final SparkLineView sl7;
  public final SparkLineView sl8;
  public final SparkLineView sl9;
  
  public SensorTagMovementTableRow(Context paramContext)
  {
    super(paramContext);
    SparkLineView localSparkLineView1 = this.sl1;
    SparkLineView localSparkLineView2 = this.sl2;
    this.sl3.autoScale = true;
    localSparkLineView2.autoScale = true;
    localSparkLineView1.autoScale = true;
    localSparkLineView1 = this.sl1;
    localSparkLineView2 = this.sl2;
    this.sl3.autoScaleBounceBack = true;
    localSparkLineView2.autoScaleBounceBack = true;
    localSparkLineView1.autoScaleBounceBack = true;
    this.sl2.setVisibility(0);
    this.sl3.setVisibility(0);
    this.sl2.setEnabled(true);
    this.sl3.setEnabled(true);
    this.sl2.setColor(255, 0, 150, 125);
    this.sl3.setColor(255, 0, 0, 0);
    this.sl2.autoScale = true;
    this.sl3.autoScale = true;
    this.sl2.autoScaleBounceBack = true;
    this.sl3.autoScaleBounceBack = true;
    this.sl4 = new SparkLineView(paramContext) {};
    this.sl5 = new SparkLineView(paramContext) {};
    this.sl6 = new SparkLineView(paramContext) {};
    this.sl7 = new SparkLineView(paramContext) {};
    this.sl8 = new SparkLineView(paramContext) {};
    this.sl9 = new SparkLineView(paramContext) {};
    this.gyroValue = new TextView(paramContext) {};
    this.magValue = new TextView(paramContext) {};
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.sl3.getId());
    paramContext.addRule(1, this.icon.getId());
    this.gyroValue.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.gyroValue.getId());
    paramContext.addRule(1, this.icon.getId());
    this.sl4.setLayoutParams(paramContext);
    this.sl5.setLayoutParams(paramContext);
    this.sl6.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.sl6.getId());
    paramContext.addRule(1, this.icon.getId());
    this.magValue.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.magValue.getId());
    paramContext.addRule(1, this.icon.getId());
    this.sl7.setLayoutParams(paramContext);
    this.sl8.setLayoutParams(paramContext);
    this.sl9.setLayoutParams(paramContext);
    this.rowLayout.addView(this.gyroValue);
    this.rowLayout.addView(this.sl4);
    this.rowLayout.addView(this.sl5);
    this.rowLayout.addView(this.sl6);
    this.rowLayout.addView(this.magValue);
    this.rowLayout.addView(this.sl7);
    this.rowLayout.addView(this.sl8);
    this.rowLayout.addView(this.sl9);
  }
  
  public void onAnimationEnd(Animation paramAnimation)
  {
    if (this.config == true)
    {
      this.sl1.setVisibility(4);
      this.sl2.setVisibility(4);
      this.sl3.setVisibility(4);
      this.sl4.setVisibility(4);
      this.sl5.setVisibility(4);
      this.sl6.setVisibility(4);
      this.sl7.setVisibility(4);
      this.sl8.setVisibility(4);
      this.sl9.setVisibility(4);
      this.onOff.setVisibility(0);
      this.onOffLegend.setVisibility(0);
      this.periodBar.setVisibility(0);
      this.periodLegend.setVisibility(0);
      this.gyroValue.setVisibility(4);
      this.magValue.setVisibility(4);
      this.value.setVisibility(4);
      return;
    }
    this.sl1.setVisibility(0);
    this.sl2.setVisibility(0);
    this.sl3.setVisibility(0);
    this.sl4.setVisibility(0);
    this.sl5.setVisibility(0);
    this.sl6.setVisibility(0);
    this.sl7.setVisibility(0);
    this.sl8.setVisibility(0);
    this.sl9.setVisibility(0);
    this.gyroValue.setVisibility(0);
    this.magValue.setVisibility(0);
    this.value.setVisibility(0);
    this.onOff.setVisibility(4);
    this.onOffLegend.setVisibility(4);
    this.periodBar.setVisibility(4);
    this.periodLegend.setVisibility(4);
  }
  
  public void onAnimationStart(Animation paramAnimation) {}
  
  public void onClick(View paramView)
  {
    if (!this.config) {}
    AlphaAnimation localAlphaAnimation;
    for (boolean bool = true;; bool = false)
    {
      this.config = bool;
      Log.d("onClick", "Row ID" + paramView.getId());
      paramView = new AlphaAnimation(1.0F, 0.0F);
      paramView.setAnimationListener(this);
      paramView.setDuration(500L);
      paramView.setStartOffset(0L);
      localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
      localAlphaAnimation.setAnimationListener(this);
      localAlphaAnimation.setDuration(500L);
      localAlphaAnimation.setStartOffset(250L);
      if (this.config != true) {
        break;
      }
      this.sl1.startAnimation(paramView);
      this.sl2.startAnimation(paramView);
      this.sl3.startAnimation(paramView);
      this.sl4.startAnimation(paramView);
      this.sl5.startAnimation(paramView);
      this.sl6.startAnimation(paramView);
      this.sl7.startAnimation(paramView);
      this.sl8.startAnimation(paramView);
      this.sl9.startAnimation(paramView);
      this.value.startAnimation(paramView);
      this.gyroValue.startAnimation(paramView);
      this.magValue.startAnimation(paramView);
      this.onOffLegend.startAnimation(localAlphaAnimation);
      this.onOff.startAnimation(localAlphaAnimation);
      this.periodLegend.startAnimation(localAlphaAnimation);
      this.periodBar.startAnimation(localAlphaAnimation);
      return;
    }
    this.sl1.startAnimation(localAlphaAnimation);
    this.sl1.startAnimation(localAlphaAnimation);
    this.sl2.startAnimation(localAlphaAnimation);
    this.sl3.startAnimation(localAlphaAnimation);
    this.sl4.startAnimation(localAlphaAnimation);
    this.sl5.startAnimation(localAlphaAnimation);
    this.sl6.startAnimation(localAlphaAnimation);
    this.sl7.startAnimation(localAlphaAnimation);
    this.sl8.startAnimation(localAlphaAnimation);
    this.sl9.startAnimation(localAlphaAnimation);
    this.value.startAnimation(localAlphaAnimation);
    this.gyroValue.startAnimation(localAlphaAnimation);
    this.magValue.startAnimation(localAlphaAnimation);
    this.onOffLegend.startAnimation(paramView);
    this.onOff.startAnimation(paramView);
    this.periodLegend.startAnimation(paramView);
    this.periodBar.startAnimation(paramView);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\SensorTagMovementTableRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */