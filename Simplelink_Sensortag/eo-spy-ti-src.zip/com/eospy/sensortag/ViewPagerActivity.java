package com.eospy.sensortag;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.ActionBar.TabListener;
import android.app.Dialog;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.SimpleOnPageChangeListener;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import com.eospy.client.StatusDialog;
import java.util.ArrayList;
import java.util.List;

public class ViewPagerActivity
  extends FragmentActivity
{
  protected static ViewPagerActivity mThis = null;
  protected boolean mBusy;
  private int mCurrentTab = 0;
  protected int mResourceFragmentPager;
  protected int mResourceIdPager;
  protected SectionsPagerAdapter mSectionsPagerAdapter;
  private ViewPager mViewPager;
  protected Menu optionsMenu;
  private MenuItem refreshItem;
  ActionBar.TabListener tabListener = new ActionBar.TabListener()
  {
    public void onTabReselected(ActionBar.Tab paramAnonymousTab, FragmentTransaction paramAnonymousFragmentTransaction) {}
    
    public void onTabSelected(ActionBar.Tab paramAnonymousTab, FragmentTransaction paramAnonymousFragmentTransaction)
    {
      int i = paramAnonymousTab.getPosition();
      ViewPagerActivity.access$002(ViewPagerActivity.this, i);
      ViewPagerActivity.this.mViewPager.setCurrentItem(i);
    }
    
    public void onTabUnselected(ActionBar.Tab paramAnonymousTab, FragmentTransaction paramAnonymousFragmentTransaction) {}
  };
  
  protected ViewPagerActivity()
  {
    mThis = this;
    this.mBusy = false;
    this.refreshItem = null;
  }
  
  public void onBackPressed()
  {
    if (this.mCurrentTab != 0)
    {
      getActionBar().setSelectedNavigationItem(0);
      return;
    }
    super.onBackPressed();
  }
  
  protected void onCreate(final Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(this.mResourceFragmentPager);
    paramBundle = getActionBar();
    paramBundle.setNavigationMode(2);
    ((ImageView)findViewById(16908332)).setPadding(10, 0, 20, 10);
    this.mViewPager = ((ViewPager)findViewById(this.mResourceIdPager));
    this.mViewPager.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener()
    {
      public void onPageSelected(int paramAnonymousInt)
      {
        paramBundle.setSelectedNavigationItem(paramAnonymousInt);
      }
    });
    this.mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
    this.mViewPager.setAdapter(this.mSectionsPagerAdapter);
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    this.mSectionsPagerAdapter = null;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    switch (paramMenuItem.getItemId())
    {
    default: 
      return super.onOptionsItemSelected(paramMenuItem);
    }
    onBackPressed();
    return true;
  }
  
  protected void openAboutDialog()
  {
    new AboutDialog(this).show();
  }
  
  protected void openStatusDialog()
  {
    new StatusDialog(this).show();
  }
  
  protected void refreshBusyIndicator()
  {
    if (this.refreshItem == null) {
      runOnUiThread(new Runnable()
      {
        public void run()
        {
          ViewPagerActivity.this.showBusyIndicator(ViewPagerActivity.this.mBusy);
        }
      });
    }
  }
  
  protected void showBusyIndicator(boolean paramBoolean)
  {
    if (this.optionsMenu != null)
    {
      this.refreshItem = this.optionsMenu.findItem(2131492897);
      if (this.refreshItem != null)
      {
        if (!paramBoolean) {
          break label62;
        }
        this.refreshItem.setActionView(2130903050);
      }
    }
    for (;;)
    {
      this.refreshItem.setVisible(paramBoolean);
      this.mBusy = paramBoolean;
      return;
      label62:
      this.refreshItem.setActionView(null);
    }
  }
  
  public class SectionsPagerAdapter
    extends FragmentStatePagerAdapter
  {
    private List<Fragment> mFragmentList = new ArrayList();
    private List<String> mTitles = new ArrayList();
    
    public SectionsPagerAdapter(FragmentManager paramFragmentManager)
    {
      super();
    }
    
    public void addSection(Fragment paramFragment, String paramString)
    {
      ActionBar localActionBar = ViewPagerActivity.this.getActionBar();
      this.mFragmentList.add(paramFragment);
      this.mTitles.add(paramString);
      localActionBar.addTab(localActionBar.newTab().setText(paramString).setTabListener(ViewPagerActivity.this.tabListener));
      notifyDataSetChanged();
    }
    
    public int getCount()
    {
      return this.mTitles.size();
    }
    
    public Fragment getItem(int paramInt)
    {
      return (Fragment)this.mFragmentList.get(paramInt);
    }
    
    public CharSequence getPageTitle(int paramInt)
    {
      if (paramInt < getCount()) {
        return (CharSequence)this.mTitles.get(paramInt);
      }
      return null;
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\ViewPagerActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */