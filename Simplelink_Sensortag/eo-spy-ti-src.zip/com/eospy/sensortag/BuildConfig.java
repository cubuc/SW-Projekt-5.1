package com.eospy.sensortag;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "com.eospy.sensortag";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "regular";
  public static final int VERSION_CODE = 45;
  public static final String VERSION_NAME = "4.16";
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */