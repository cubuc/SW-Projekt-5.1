package com.eospy.btsig.profiles;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.eospy.util.GenericCharacteristicTableRow;

public class DeviceInformationServiceTableRow
  extends GenericCharacteristicTableRow
{
  TextView FirmwareREVLabel;
  TextView HardwareREVLabel;
  TextView ManifacturerNAMELabel;
  TextView ModelNRLabel;
  TextView SerialNRLabel;
  TextView SoftwareREVLabel;
  TextView SystemIDLabel;
  
  public DeviceInformationServiceTableRow(Context paramContext)
  {
    super(paramContext);
    this.SystemIDLabel = new TextView(paramContext) {};
    this.ModelNRLabel = new TextView(paramContext) {};
    this.SerialNRLabel = new TextView(paramContext) {};
    this.FirmwareREVLabel = new TextView(paramContext) {};
    this.HardwareREVLabel = new TextView(paramContext) {};
    this.SoftwareREVLabel = new TextView(paramContext) {};
    this.ManifacturerNAMELabel = new TextView(paramContext) {};
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.value.getId());
    paramContext.addRule(1, this.icon.getId());
    this.SystemIDLabel.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.SystemIDLabel.getId());
    paramContext.addRule(1, this.icon.getId());
    this.ModelNRLabel.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.ModelNRLabel.getId());
    paramContext.addRule(1, this.icon.getId());
    this.SerialNRLabel.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.SerialNRLabel.getId());
    paramContext.addRule(1, this.icon.getId());
    this.FirmwareREVLabel.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.FirmwareREVLabel.getId());
    paramContext.addRule(1, this.icon.getId());
    this.HardwareREVLabel.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.HardwareREVLabel.getId());
    paramContext.addRule(1, this.icon.getId());
    this.SoftwareREVLabel.setLayoutParams(paramContext);
    paramContext = new RelativeLayout.LayoutParams(-1, -1);
    paramContext.addRule(3, this.SoftwareREVLabel.getId());
    paramContext.addRule(1, this.icon.getId());
    this.ManifacturerNAMELabel.setLayoutParams(paramContext);
    this.rowLayout.addView(this.SystemIDLabel);
    this.rowLayout.addView(this.ModelNRLabel);
    this.rowLayout.addView(this.SerialNRLabel);
    this.rowLayout.addView(this.FirmwareREVLabel);
    this.rowLayout.addView(this.HardwareREVLabel);
    this.rowLayout.addView(this.SoftwareREVLabel);
    this.rowLayout.addView(this.ManifacturerNAMELabel);
  }
  
  public void onClick(View paramView) {}
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\btsig\profiles\DeviceInformationServiceTableRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */