package com.eospy.sensortag;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Build.VERSION;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.PreferenceFragment;
import android.preference.TwoStatePreference;
import android.util.Log;
import com.eospy.client.AutostartReceiver;
import com.eospy.client.TrackingService;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PreferencesListener
  implements SharedPreferences.OnSharedPreferenceChangeListener
{
  public static final String KEY_ADDRESS = "address";
  public static final String KEY_DEVICE = "id";
  public static final String KEY_INTERVAL = "interval";
  public static final String KEY_PORT = "port";
  public static final String KEY_PROVIDER = "provider";
  public static final String KEY_SECURE = "secure";
  public static final String KEY_STATUS = "status";
  private static final int MAX_NOTIFICATIONS = 4;
  private static final int PERMISSIONS_REQUEST_LOCATION = 2;
  private static final String TAG = MainActivity.class.getSimpleName();
  private PendingIntent alarmIntent;
  private AlarmManager alarmManager;
  private Context context;
  private PreferenceFragment preferenceFragment;
  private SharedPreferences sharedPreferences;
  
  public PreferencesListener(Context paramContext, SharedPreferences paramSharedPreferences, PreferenceFragment paramPreferenceFragment)
  {
    this.context = paramContext;
    this.sharedPreferences = paramSharedPreferences;
    this.preferenceFragment = paramPreferenceFragment;
    this.preferenceFragment.findPreference("id").setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener()
    {
      public boolean onPreferenceChange(Preference paramAnonymousPreference, Object paramAnonymousObject)
      {
        return (paramAnonymousObject != null) && (!paramAnonymousObject.equals(""));
      }
    });
    this.preferenceFragment.findPreference("address").setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener()
    {
      public boolean onPreferenceChange(Preference paramAnonymousPreference, Object paramAnonymousObject)
      {
        if (Build.VERSION.SDK_INT >= 8) {
          if ((paramAnonymousObject == null) || (!Patterns.DOMAIN_NAME.matcher((String)paramAnonymousObject).matches())) {}
        }
        while ((paramAnonymousObject != null) && (!((String)paramAnonymousObject).isEmpty()))
        {
          return true;
          return false;
        }
        return false;
      }
    });
    this.preferenceFragment.findPreference("port").setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener()
    {
      public boolean onPreferenceChange(Preference paramAnonymousPreference, Object paramAnonymousObject)
      {
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (paramAnonymousObject != null) {}
        try
        {
          int i = Integer.parseInt((String)paramAnonymousObject);
          bool1 = bool2;
          if (i > 0)
          {
            bool1 = bool2;
            if (i <= 65536) {
              bool1 = true;
            }
          }
          return bool1;
        }
        catch (NumberFormatException paramAnonymousPreference)
        {
          Log.w(PreferencesListener.TAG, paramAnonymousPreference);
        }
        return false;
      }
    });
    this.preferenceFragment.findPreference("interval").setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener()
    {
      public boolean onPreferenceChange(Preference paramAnonymousPreference, Object paramAnonymousObject)
      {
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (paramAnonymousObject != null) {}
        try
        {
          int i = Integer.parseInt((String)paramAnonymousObject);
          bool1 = bool2;
          if (i > 0) {
            bool1 = true;
          }
          return bool1;
        }
        catch (NumberFormatException paramAnonymousPreference)
        {
          Log.w(PreferencesListener.TAG, paramAnonymousPreference);
        }
        return false;
      }
    });
    this.preferenceFragment.findPreference("status").setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener()
    {
      public boolean onPreferenceChange(Preference paramAnonymousPreference, Object paramAnonymousObject)
      {
        if (paramAnonymousObject.equals(Boolean.valueOf(true)))
        {
          PreferencesListener.this.startTrackingService(true, false);
          return true;
        }
        PreferencesListener.this.stopTrackingService();
        return true;
      }
    });
    paramContext = MainActivity.mThis;
    paramPreferenceFragment = MainActivity.mThis;
    this.alarmManager = ((AlarmManager)paramContext.getSystemService("alarm"));
    this.alarmIntent = PendingIntent.getBroadcast(MainActivity.mThis, 0, new Intent(MainActivity.mThis, AutostartReceiver.class), 0);
    if (paramSharedPreferences.getBoolean("status", false)) {
      setPreferencesEnabled(false);
    }
  }
  
  private void alertNotifyLimitaion()
  {
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(this.context);
    localBuilder.setTitle("Notifications limit");
    localBuilder.setMessage("Android 4.3 BLE allows a maximum of 4 simultaneous notifications.\n");
    localBuilder.setIcon(2130837510);
    localBuilder.setNeutralButton(17039370, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {}
    });
    localBuilder.create().show();
  }
  
  private List<Sensor> enabledSensors()
  {
    ArrayList localArrayList = new ArrayList();
    Sensor[] arrayOfSensor = Sensor.values();
    int j = arrayOfSensor.length;
    int i = 0;
    while (i < j)
    {
      Sensor localSensor = arrayOfSensor[i];
      if (isEnabledByPrefs(localSensor)) {
        localArrayList.add(localSensor);
      }
      i += 1;
    }
    return localArrayList;
  }
  
  private Sensor getSensorFromPrefKey(String paramString)
  {
    try
    {
      paramString = Sensor.valueOf(paramString.substring("pref_".length(), paramString.length() - "_on".length()).toUpperCase(Locale.ENGLISH));
      return paramString;
    }
    catch (NullPointerException paramString)
    {
      return null;
    }
    catch (IllegalArgumentException paramString)
    {
      for (;;) {}
    }
    catch (IndexOutOfBoundsException paramString)
    {
      for (;;) {}
    }
  }
  
  private boolean hasPermission(String paramString)
  {
    if (Build.VERSION.SDK_INT <= 21) {}
    return true;
  }
  
  private boolean isEnabledByPrefs(Sensor paramSensor)
  {
    paramSensor = "pref_" + paramSensor.name().toLowerCase(Locale.ENGLISH) + "_on";
    if (this.sharedPreferences.contains(paramSensor)) {
      return this.sharedPreferences.getBoolean(paramSensor, true);
    }
    return false;
  }
  
  private void startTrackingService(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramBoolean1)
    {
      HashSet localHashSet = new HashSet();
      if (!hasPermission("android.permission.ACCESS_FINE_LOCATION")) {
        localHashSet.add("android.permission.ACCESS_FINE_LOCATION");
      }
      if (!hasPermission("android.permission.ACCESS_COARSE_LOCATION")) {
        localHashSet.add("android.permission.ACCESS_COARSE_LOCATION");
      }
      if (localHashSet.isEmpty()) {
        paramBoolean2 = true;
      }
    }
    else
    {
      if (!paramBoolean2) {
        break label112;
      }
      setPreferencesEnabled(false);
      this.context.startService(new Intent(MainActivity.mThis, TrackingService.class));
      this.alarmManager.setInexactRepeating(2, 15000L, 15000L, this.alarmIntent);
    }
    return;
    label112:
    this.sharedPreferences.edit().putBoolean("status", false).commit();
    if (Build.VERSION.SDK_INT >= 14)
    {
      ((TwoStatePreference)this.preferenceFragment.findPreference("status")).setChecked(false);
      return;
    }
    ((CheckBoxPreference)this.preferenceFragment.findPreference("status")).setChecked(false);
  }
  
  private void stopTrackingService()
  {
    this.alarmManager.cancel(this.alarmIntent);
    this.context.stopService(new Intent(MainActivity.mThis, TrackingService.class));
    setPreferencesEnabled(true);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfInt)
  {
    boolean bool2;
    int i;
    if (paramInt == 2)
    {
      bool2 = true;
      i = paramArrayOfInt.length;
      paramInt = 0;
    }
    for (;;)
    {
      boolean bool1 = bool2;
      if (paramInt < i)
      {
        if (paramArrayOfInt[paramInt] != 0) {
          bool1 = false;
        }
      }
      else
      {
        startTrackingService(false, bool1);
        return;
      }
      paramInt += 1;
    }
  }
  
  public void onSharedPreferenceChanged(SharedPreferences paramSharedPreferences, String paramString)
  {
    if (Build.VERSION.SDK_INT > 18) {}
    label98:
    label104:
    do
    {
      for (;;)
      {
        return;
        if (getSensorFromPrefKey(paramString) == null) {}
        for (int i = 1; i == 0; i = 0)
        {
          if ((paramSharedPreferences.getBoolean(paramString, true)) && (enabledSensors().size() > 4))
          {
            ((CheckBoxPreference)this.preferenceFragment.findPreference(paramString)).setChecked(false);
            alertNotifyLimitaion();
          }
          if (!paramString.equals("status")) {
            break label104;
          }
          if (!paramSharedPreferences.getBoolean("status", false)) {
            break label98;
          }
          setPreferencesEnabled(true);
          return;
        }
      }
      setPreferencesEnabled(false);
      return;
    } while (!paramString.equals("id"));
    this.preferenceFragment.findPreference("id").setSummary(paramSharedPreferences.getString("id", null));
  }
  
  public void setPreferencesEnabled(boolean paramBoolean)
  {
    this.preferenceFragment.findPreference("id").setEnabled(paramBoolean);
    this.preferenceFragment.findPreference("address").setEnabled(paramBoolean);
    this.preferenceFragment.findPreference("port").setEnabled(paramBoolean);
    this.preferenceFragment.findPreference("interval").setEnabled(paramBoolean);
    this.preferenceFragment.findPreference("provider").setEnabled(paramBoolean);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\PreferencesListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */