package com.eospy.client;

import android.location.Location;
import java.util.Date;

public class Position
{
  private double accel_x;
  private double accel_y;
  private double accel_z;
  private double altitude;
  private double battery;
  private double course;
  private String deviceId;
  private double gyro_x;
  private double gyro_y;
  private double gyro_z;
  private double humidity;
  private long id;
  private double ir_temp;
  private double keypress;
  private double latitude;
  private double light;
  private double longitude;
  private double magnet_x;
  private double magnet_y;
  private double magnet_z;
  private double mbar;
  private double speed;
  private double temp;
  private Date time;
  
  public Position() {}
  
  public Position(String paramString, Location paramLocation, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, double paramDouble13, double paramDouble14, double paramDouble15, double paramDouble16)
  {
    this.deviceId = paramString;
    this.time = new Date(paramLocation.getTime());
    this.latitude = paramLocation.getLatitude();
    this.longitude = paramLocation.getLongitude();
    this.altitude = paramLocation.getAltitude();
    this.speed = (paramLocation.getSpeed() * 1.943844D);
    this.course = paramLocation.getBearing();
    this.battery = paramDouble1;
    this.temp = paramDouble2;
    this.ir_temp = paramDouble3;
    this.humidity = paramDouble4;
    this.mbar = paramDouble5;
    this.accel_x = paramDouble6;
    this.accel_y = paramDouble7;
    this.accel_z = paramDouble8;
    this.gyro_x = paramDouble9;
    this.gyro_y = paramDouble10;
    this.gyro_z = paramDouble11;
    this.magnet_x = paramDouble12;
    this.magnet_y = paramDouble13;
    this.magnet_z = paramDouble14;
    this.light = paramDouble15;
    this.keypress = paramDouble16;
  }
  
  public double getAccel_x()
  {
    return this.accel_x;
  }
  
  public double getAccel_y()
  {
    return this.accel_y;
  }
  
  public double getAccel_z()
  {
    return this.accel_z;
  }
  
  public double getAltitude()
  {
    return this.altitude;
  }
  
  public double getBattery()
  {
    return this.battery;
  }
  
  public double getCourse()
  {
    return this.course;
  }
  
  public String getDeviceId()
  {
    return this.deviceId;
  }
  
  public double getGyro_x()
  {
    return this.gyro_x;
  }
  
  public double getGyro_y()
  {
    return this.gyro_y;
  }
  
  public double getGyro_z()
  {
    return this.gyro_z;
  }
  
  public double getHumidity()
  {
    return this.humidity;
  }
  
  public double getIR_Temp()
  {
    return this.ir_temp;
  }
  
  public long getId()
  {
    return this.id;
  }
  
  public double getKeyPress()
  {
    return this.keypress;
  }
  
  public double getLatitude()
  {
    return this.latitude;
  }
  
  public double getLight()
  {
    return this.light;
  }
  
  public double getLongitude()
  {
    return this.longitude;
  }
  
  public double getMagnet_x()
  {
    return this.magnet_x;
  }
  
  public double getMagnet_y()
  {
    return this.magnet_y;
  }
  
  public double getMagnet_z()
  {
    return this.magnet_z;
  }
  
  public double getMbar()
  {
    return this.mbar;
  }
  
  public double getSpeed()
  {
    return this.speed;
  }
  
  public double getTemp()
  {
    return this.temp;
  }
  
  public Date getTime()
  {
    return this.time;
  }
  
  public void setAccel_x(double paramDouble)
  {
    this.accel_x = paramDouble;
  }
  
  public void setAccel_y(double paramDouble)
  {
    this.accel_y = paramDouble;
  }
  
  public void setAccel_z(double paramDouble)
  {
    this.accel_z = paramDouble;
  }
  
  public void setAltitude(double paramDouble)
  {
    this.altitude = paramDouble;
  }
  
  public void setBattery(double paramDouble)
  {
    this.battery = paramDouble;
  }
  
  public void setCourse(double paramDouble)
  {
    this.course = paramDouble;
  }
  
  public void setDeviceId(String paramString)
  {
    this.deviceId = paramString;
  }
  
  public void setGyro_x(double paramDouble)
  {
    this.gyro_x = paramDouble;
  }
  
  public void setGyro_y(double paramDouble)
  {
    this.gyro_y = paramDouble;
  }
  
  public void setGyro_z(double paramDouble)
  {
    this.gyro_z = paramDouble;
  }
  
  public void setHumidity(double paramDouble)
  {
    this.humidity = paramDouble;
  }
  
  public void setIR_Temp(double paramDouble)
  {
    this.ir_temp = paramDouble;
  }
  
  public void setId(long paramLong)
  {
    this.id = paramLong;
  }
  
  public void setKeyPress(double paramDouble)
  {
    this.keypress = paramDouble;
  }
  
  public void setLatitude(double paramDouble)
  {
    this.latitude = paramDouble;
  }
  
  public void setLight(double paramDouble)
  {
    this.light = paramDouble;
  }
  
  public void setLongitude(double paramDouble)
  {
    this.longitude = paramDouble;
  }
  
  public void setMagnet_x(double paramDouble)
  {
    this.magnet_x = paramDouble;
  }
  
  public void setMagnet_y(double paramDouble)
  {
    this.magnet_y = paramDouble;
  }
  
  public void setMagnet_z(double paramDouble)
  {
    this.magnet_z = paramDouble;
  }
  
  public void setMbar(double paramDouble)
  {
    this.mbar = paramDouble;
  }
  
  public void setSpeed(double paramDouble)
  {
    this.speed = paramDouble;
  }
  
  public void setTemp(double paramDouble)
  {
    this.temp = paramDouble;
  }
  
  public void setTime(Date paramDate)
  {
    this.time = paramDate;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\Position.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */