package com.eospy.sensortag;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import com.eospy.btsig.profiles.DeviceInformationServiceProfile;
import com.eospy.common.BluetoothLeService;
import com.eospy.common.GattInfo;
import com.eospy.common.GenericBluetoothProfile;
import com.eospy.common.HelpView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

@SuppressLint({"InflateParams"})
public class DeviceActivity
  extends ViewPagerActivity
{
  public static final String EXTRA_DEVICE = "EXTRA_DEVICE";
  private static final int FWUPDATE_ACT_REQ = 1;
  private static final int PREF_ACT_REQ = 0;
  private BluetoothDevice mBluetoothDevice = null;
  private BluetoothGatt mBtGatt = null;
  private BluetoothLeService mBtLeService = null;
  private BluetoothGattService mConnControlService = null;
  private DeviceView mDeviceView = null;
  private String mFwRev = new String("1.5");
  private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver()
  {
    List<BluetoothGattCharacteristic> charList = new ArrayList();
    List<BluetoothGattService> serviceList;
    
    public void onReceive(final Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      Object localObject = paramAnonymousIntent.getAction();
      int k = paramAnonymousIntent.getIntExtra("com.eospy.common.EXTRA_STATUS", 0);
      if ("com.eospy.ble.btsig.ACTION_FW_REV_UPDATED".equals(localObject))
      {
        DeviceActivity.access$002(DeviceActivity.this, paramAnonymousIntent.getStringExtra("com.eospy.ble.btsig.EXTRA_FW_REV_STRING"));
        Log.d("DeviceActivity", "Got FW revision : " + DeviceActivity.this.mFwRev + " from DeviceInformationServiceProfile");
        Iterator localIterator = DeviceActivity.this.mProfiles.iterator();
        while (localIterator.hasNext()) {
          ((GenericBluetoothProfile)localIterator.next()).didUpdateFirmwareRevision(DeviceActivity.this.mFwRev);
        }
      }
      int i;
      if ("com.eospy.common.ACTION_GATT_SERVICES_DISCOVERED".equals(localObject)) {
        if (k == 0)
        {
          this.serviceList = DeviceActivity.this.mBtLeService.getSupportedGattServices();
          if (this.serviceList.size() > 0)
          {
            i = 0;
            while (i < this.serviceList.size())
            {
              paramAnonymousIntent = ((BluetoothGattService)this.serviceList.get(i)).getCharacteristics();
              if (paramAnonymousIntent.size() > 0)
              {
                int j = 0;
                while (j < paramAnonymousIntent.size())
                {
                  this.charList.add(paramAnonymousIntent.get(j));
                  j += 1;
                }
              }
              i += 1;
            }
          }
          Log.d("DeviceActivity", "Total characteristics " + this.charList.size());
          new Thread(new Runnable()
          {
            public void run()
            {
              int m = 0;
              int j = 0;
              final int i = 0;
              Object localObject1 = DeviceActivity.1.this.serviceList.iterator();
              while (((Iterator)localObject1).hasNext()) {
                i += ((BluetoothGattService)((Iterator)localObject1).next()).getCharacteristics().size();
              }
              if (i == 0)
              {
                DeviceActivity.this.runOnUiThread(new Runnable()
                {
                  public void run()
                  {
                    DeviceActivity.this.progressDialog.hide();
                    DeviceActivity.this.progressDialog.dismiss();
                    AlertDialog.Builder localBuilder = new AlertDialog.Builder(DeviceActivity.1.1.this.val$context);
                    localBuilder.setTitle("Error !");
                    localBuilder.setMessage(DeviceActivity.1.this.serviceList.size() + " Services found, but no characteristics found, device will be disconnected !");
                    localBuilder.setPositiveButton("Retry", new DialogInterface.OnClickListener()
                    {
                      public void onClick(DialogInterface paramAnonymous4DialogInterface, int paramAnonymous4Int)
                      {
                        DeviceActivity.this.mBtLeService.refreshDeviceCache(DeviceActivity.this.mBtGatt);
                        DeviceActivity.this.discoverServices();
                      }
                    });
                    localBuilder.setNegativeButton("Disconnect", new DialogInterface.OnClickListener()
                    {
                      public void onClick(DialogInterface paramAnonymous4DialogInterface, int paramAnonymous4Int)
                      {
                        DeviceActivity.this.mBtLeService.disconnect(DeviceActivity.this.mBluetoothDevice.getAddress());
                      }
                    });
                    localBuilder.create().show();
                  }
                });
                return;
              }
              DeviceActivity.this.runOnUiThread(new Runnable()
              {
                public void run()
                {
                  DeviceActivity.this.progressDialog.setIndeterminate(false);
                  DeviceActivity.this.progressDialog.setTitle("Generating GUI");
                  DeviceActivity.this.progressDialog.setMessage("Found a total of " + DeviceActivity.1.this.serviceList.size() + " services with a total of " + i + " characteristics on this device");
                }
              });
              int k;
              if (Build.VERSION.SDK_INT > 18) {
                k = 7;
              }
              for (;;)
              {
                n = 0;
                i = m;
                m = n;
                if (m >= DeviceActivity.1.this.serviceList.size()) {
                  break label1178;
                }
                localObject1 = (BluetoothGattService)DeviceActivity.1.this.serviceList.get(m);
                if (((BluetoothGattService)localObject1).getCharacteristics().size() != 0) {
                  break;
                }
                Log.d("DeviceActivity", "No characteristics found for this service !!!");
                return;
                k = 4;
                DeviceActivity.this.runOnUiThread(new Runnable()
                {
                  public void run()
                  {
                    Toast.makeText(DeviceActivity.1.1.this.val$context, "Android version 4.3 detected, max 4 notifications enabled", 1).show();
                  }
                });
              }
              int n = j + 1;
              final float f1 = n;
              final float f2 = DeviceActivity.1.this.serviceList.size();
              DeviceActivity.this.runOnUiThread(new Runnable()
              {
                public void run()
                {
                  DeviceActivity.this.progressDialog.setProgress((int)(f1 / (f2 - 1.0F) * 100.0F));
                }
              });
              Log.d("DeviceActivity", "Configuring service with uuid : " + ((BluetoothGattService)localObject1).getUuid().toString());
              j = i;
              final Object localObject2;
              if (SensorTagHumidityProfile.isCorrectService((BluetoothGattService)localObject1))
              {
                localObject2 = new SensorTagHumidityProfile(paramAnonymousContext, DeviceActivity.this.mBluetoothDevice, (BluetoothGattService)localObject1, DeviceActivity.this.mBtLeService);
                DeviceActivity.this.mProfiles.add(localObject2);
                if (i < k)
                {
                  ((SensorTagHumidityProfile)localObject2).configureService();
                  i += 1;
                  label357:
                  Log.d("DeviceActivity", "Found Humidity !");
                  j = i;
                }
              }
              else
              {
                i = j;
                if (SensorTagLuxometerProfile.isCorrectService((BluetoothGattService)localObject1))
                {
                  localObject2 = new SensorTagLuxometerProfile(paramAnonymousContext, DeviceActivity.this.mBluetoothDevice, (BluetoothGattService)localObject1, DeviceActivity.this.mBtLeService);
                  DeviceActivity.this.mProfiles.add(localObject2);
                  if (j >= k) {
                    break label1106;
                  }
                  ((SensorTagLuxometerProfile)localObject2).configureService();
                  i = j + 1;
                }
                label449:
                j = i;
                if (SensorTagSimpleKeysProfile.isCorrectService((BluetoothGattService)localObject1))
                {
                  localObject2 = new SensorTagSimpleKeysProfile(paramAnonymousContext, DeviceActivity.this.mBluetoothDevice, (BluetoothGattService)localObject1, DeviceActivity.this.mBtLeService);
                  DeviceActivity.this.mProfiles.add(localObject2);
                  if (i >= k) {
                    break label1118;
                  }
                  ((SensorTagSimpleKeysProfile)localObject2).configureService();
                  i += 1;
                  label528:
                  Log.d("DeviceActivity", "Found Simple Keys !");
                  j = i;
                }
                i = j;
                if (SensorTagBarometerProfile.isCorrectService((BluetoothGattService)localObject1))
                {
                  localObject2 = new SensorTagBarometerProfile(paramAnonymousContext, DeviceActivity.this.mBluetoothDevice, (BluetoothGattService)localObject1, DeviceActivity.this.mBtLeService);
                  DeviceActivity.this.mProfiles.add(localObject2);
                  if (j >= k) {
                    break label1127;
                  }
                  ((SensorTagBarometerProfile)localObject2).configureService();
                  i = j + 1;
                  label620:
                  Log.d("DeviceActivity", "Found Barometer !");
                }
                j = i;
                if (SensorTagAmbientTemperatureProfile.isCorrectService((BluetoothGattService)localObject1))
                {
                  localObject2 = new SensorTagAmbientTemperatureProfile(paramAnonymousContext, DeviceActivity.this.mBluetoothDevice, (BluetoothGattService)localObject1, DeviceActivity.this.mBtLeService);
                  DeviceActivity.this.mProfiles.add(localObject2);
                  if (i >= k) {
                    break label1139;
                  }
                  ((SensorTagAmbientTemperatureProfile)localObject2).configureService();
                  i += 1;
                  label707:
                  Log.d("DeviceActivity", "Found Ambient Temperature !");
                  j = i;
                }
                if (SensorTagIRTemperatureProfile.isCorrectService((BluetoothGattService)localObject1))
                {
                  localObject2 = new SensorTagIRTemperatureProfile(paramAnonymousContext, DeviceActivity.this.mBluetoothDevice, (BluetoothGattService)localObject1, DeviceActivity.this.mBtLeService);
                  DeviceActivity.this.mProfiles.add(localObject2);
                  if (j >= k) {
                    break label1148;
                  }
                  ((SensorTagIRTemperatureProfile)localObject2).configureService();
                  label791:
                  Log.d("DeviceActivity", "Found IR Temperature !");
                }
                i = j;
                if (SensorTagMovementProfile.isCorrectService((BluetoothGattService)localObject1))
                {
                  localObject2 = new SensorTagMovementProfile(paramAnonymousContext, DeviceActivity.this.mBluetoothDevice, (BluetoothGattService)localObject1, DeviceActivity.this.mBtLeService);
                  DeviceActivity.this.mProfiles.add(localObject2);
                  if (j >= k) {
                    break label1157;
                  }
                  ((SensorTagMovementProfile)localObject2).configureService();
                  i = j + 1;
                  label880:
                  Log.d("DeviceActivity", "Found Motion !");
                }
                j = i;
                if (SensorTagAccelerometerProfile.isCorrectService((BluetoothGattService)localObject1))
                {
                  localObject2 = new SensorTagAccelerometerProfile(paramAnonymousContext, DeviceActivity.this.mBluetoothDevice, (BluetoothGattService)localObject1, DeviceActivity.this.mBtLeService);
                  DeviceActivity.this.mProfiles.add(localObject2);
                  if (i >= k) {
                    break label1169;
                  }
                  ((SensorTagAccelerometerProfile)localObject2).configureService();
                  i += 1;
                }
              }
              for (;;)
              {
                Log.d("DeviceActivity", "Found Motion !");
                j = i;
                if (DeviceInformationServiceProfile.isCorrectService((BluetoothGattService)localObject1))
                {
                  localObject2 = new DeviceInformationServiceProfile(paramAnonymousContext, DeviceActivity.this.mBluetoothDevice, (BluetoothGattService)localObject1, DeviceActivity.this.mBtLeService);
                  DeviceActivity.this.mProfiles.add(localObject2);
                  ((DeviceInformationServiceProfile)localObject2).configureService();
                  Log.d("DeviceActivity", "Found Device Information Service");
                }
                if (((BluetoothGattService)localObject1).getUuid().toString().compareTo("f000ccc0-0451-4000-b000-000000000000") == 0) {
                  DeviceActivity.access$602(DeviceActivity.this, (BluetoothGattService)localObject1);
                }
                m += 1;
                i = j;
                j = n;
                break;
                ((SensorTagHumidityProfile)localObject2).grayOutCell(true);
                break label357;
                label1106:
                ((SensorTagLuxometerProfile)localObject2).grayOutCell(true);
                i = j;
                break label449;
                label1118:
                ((SensorTagSimpleKeysProfile)localObject2).grayOutCell(true);
                break label528;
                label1127:
                ((SensorTagBarometerProfile)localObject2).grayOutCell(true);
                i = j;
                break label620;
                label1139:
                ((SensorTagAmbientTemperatureProfile)localObject2).grayOutCell(true);
                break label707;
                label1148:
                ((SensorTagIRTemperatureProfile)localObject2).grayOutCell(true);
                break label791;
                label1157:
                ((SensorTagMovementProfile)localObject2).grayOutCell(true);
                i = j;
                break label880;
                label1169:
                ((SensorTagAccelerometerProfile)localObject2).grayOutCell(true);
              }
              label1178:
              DeviceActivity.this.runOnUiThread(new Runnable()
              {
                public void run()
                {
                  DeviceActivity.this.progressDialog.setTitle("Enabling Services");
                  DeviceActivity.this.progressDialog.setMax(DeviceActivity.this.mProfiles.size());
                  DeviceActivity.this.progressDialog.setProgress(0);
                }
              });
              localObject1 = DeviceActivity.this.mProfiles.iterator();
              while (((Iterator)localObject1).hasNext())
              {
                localObject2 = (GenericBluetoothProfile)((Iterator)localObject1).next();
                DeviceActivity.this.runOnUiThread(new Runnable()
                {
                  public void run()
                  {
                    DeviceActivity.this.mDeviceView.addRowToTable(localObject2.getTableRow());
                    localObject2.enableService();
                    DeviceActivity.this.progressDialog.setProgress(DeviceActivity.this.progressDialog.getProgress() + 1);
                  }
                });
                ((GenericBluetoothProfile)localObject2).onResume();
              }
              DeviceActivity.this.runOnUiThread(new Runnable()
              {
                public void run()
                {
                  DeviceActivity.this.progressDialog.hide();
                  DeviceActivity.this.progressDialog.dismiss();
                }
              });
            }
          }).start();
        }
      }
      label525:
      label644:
      label763:
      for (;;)
      {
        if (k != 0) {
          DeviceActivity.this.setError("GATT error code: " + k);
        }
        return;
        Toast.makeText(DeviceActivity.this.getApplication(), "Service discovery failed", 1).show();
        return;
        if ("com.eospy.common.ACTION_DATA_NOTIFY".equals(localObject))
        {
          paramAnonymousIntent.getByteArrayExtra("com.eospy.common.EXTRA_DATA");
          paramAnonymousIntent = paramAnonymousIntent.getStringExtra("com.eospy.common.EXTRA_UUID");
          i = 0;
          for (;;)
          {
            if (i >= this.charList.size()) {
              break label525;
            }
            paramAnonymousContext = (BluetoothGattCharacteristic)this.charList.get(i);
            if (paramAnonymousContext.getUuid().toString().equals(paramAnonymousIntent))
            {
              i = 0;
              while (i < DeviceActivity.this.mProfiles.size())
              {
                paramAnonymousIntent = (GenericBluetoothProfile)DeviceActivity.this.mProfiles.get(i);
                if (paramAnonymousIntent.isDataC(paramAnonymousContext))
                {
                  paramAnonymousIntent.didUpdateValueForCharacteristic(paramAnonymousContext);
                  paramAnonymousIntent = paramAnonymousIntent.getMQTTMap();
                  if (paramAnonymousIntent != null)
                  {
                    paramAnonymousIntent = paramAnonymousIntent.entrySet().iterator();
                    while (paramAnonymousIntent.hasNext()) {
                      localObject = (Map.Entry)paramAnonymousIntent.next();
                    }
                  }
                }
                i += 1;
              }
              break;
            }
            i += 1;
          }
        }
        else if ("com.eospy.common.ACTION_DATA_WRITE".equals(localObject))
        {
          paramAnonymousIntent.getByteArrayExtra("com.eospy.common.EXTRA_DATA");
          paramAnonymousContext = paramAnonymousIntent.getStringExtra("com.eospy.common.EXTRA_UUID");
          i = 0;
          for (;;)
          {
            if (i >= this.charList.size()) {
              break label644;
            }
            paramAnonymousIntent = (BluetoothGattCharacteristic)this.charList.get(i);
            if (paramAnonymousIntent.getUuid().toString().equals(paramAnonymousContext))
            {
              i = 0;
              while (i < DeviceActivity.this.mProfiles.size())
              {
                ((GenericBluetoothProfile)DeviceActivity.this.mProfiles.get(i)).didWriteValueForCharacteristic(paramAnonymousIntent);
                i += 1;
              }
              break;
            }
            i += 1;
          }
        }
        else if ("com.eospy.common.ACTION_DATA_READ".equals(localObject))
        {
          paramAnonymousIntent.getByteArrayExtra("com.eospy.common.EXTRA_DATA");
          paramAnonymousContext = paramAnonymousIntent.getStringExtra("com.eospy.common.EXTRA_UUID");
          i = 0;
          for (;;)
          {
            if (i >= this.charList.size()) {
              break label763;
            }
            paramAnonymousIntent = (BluetoothGattCharacteristic)this.charList.get(i);
            if (paramAnonymousIntent.getUuid().toString().equals(paramAnonymousContext))
            {
              i = 0;
              while (i < DeviceActivity.this.mProfiles.size())
              {
                ((GenericBluetoothProfile)DeviceActivity.this.mProfiles.get(i)).didReadValueForCharacteristic(paramAnonymousIntent);
                i += 1;
              }
              break;
            }
            i += 1;
          }
        }
      }
    }
  };
  private boolean mIsReceiving = false;
  private boolean mIsSensorTag2;
  private BluetoothGattService mOadService = null;
  private List<GenericBluetoothProfile> mProfiles;
  private List<BluetoothGattService> mServiceList = null;
  private boolean mServicesRdy = false;
  public ProgressDialog progressDialog;
  
  public DeviceActivity()
  {
    this.mResourceFragmentPager = 2130903048;
    this.mResourceIdPager = 2131492891;
  }
  
  private void discoverServices()
  {
    if (this.mBtGatt.discoverServices())
    {
      this.mServiceList.clear();
      setBusy(true);
    }
  }
  
  public static DeviceActivity getInstance()
  {
    return (DeviceActivity)mThis;
  }
  
  private static IntentFilter makeGattUpdateIntentFilter()
  {
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("com.eospy.common.ACTION_GATT_SERVICES_DISCOVERED");
    localIntentFilter.addAction("com.eospy.common.ACTION_DATA_NOTIFY");
    localIntentFilter.addAction("com.eospy.common.ACTION_DATA_WRITE");
    localIntentFilter.addAction("com.eospy.common.ACTION_DATA_READ");
    localIntentFilter.addAction("com.eospy.ble.btsig.ACTION_FW_REV_UPDATED");
    return localIntentFilter;
  }
  
  private void setBusy(boolean paramBoolean)
  {
    this.mDeviceView.setBusy(paramBoolean);
  }
  
  private void setError(String paramString)
  {
    setBusy(false);
    Toast.makeText(this, paramString, 1).show();
  }
  
  private void setStatus(String paramString)
  {
    Toast.makeText(this, paramString, 0).show();
  }
  
  private void startPreferenceActivity()
  {
    Intent localIntent = new Intent(this, PreferencesActivity.class);
    localIntent.putExtra(":android:show_fragment", PreferencesFragment.class.getName());
    localIntent.putExtra(":android:no_headers", true);
    localIntent.putExtra("EXTRA_DEVICE", this.mBluetoothDevice);
    startActivityForResult(localIntent, 0);
  }
  
  String firmwareRevision()
  {
    return this.mFwRev;
  }
  
  BluetoothGattService getConnControlService()
  {
    return this.mConnControlService;
  }
  
  BluetoothGattService getOadService()
  {
    return this.mOadService;
  }
  
  public boolean isEnabledByPrefs(String paramString)
  {
    paramString = "pref_" + paramString;
    return PreferenceManager.getDefaultSharedPreferences(this.mBtLeService).getBoolean(paramString, Boolean.valueOf(true).booleanValue());
  }
  
  boolean isSensorTag2()
  {
    return this.mIsSensorTag2;
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onCreate(Bundle paramBundle)
  {
    requestWindowFeature(5);
    super.onCreate(paramBundle);
    paramBundle = getIntent();
    this.mBtLeService = BluetoothLeService.getInstance();
    this.mBluetoothDevice = ((BluetoothDevice)paramBundle.getParcelableExtra("EXTRA_DEVICE"));
    this.mServiceList = new ArrayList();
    this.mIsSensorTag2 = false;
    paramBundle = this.mBluetoothDevice.getName();
    if ((paramBundle.equals("SensorTag2")) || (paramBundle.equals("CC2650 SensorTag"))) {}
    for (this.mIsSensorTag2 = true;; this.mIsSensorTag2 = false)
    {
      PreferenceManager.setDefaultValues(this, 2130968579, false);
      this.mDeviceView = new DeviceView();
      this.mSectionsPagerAdapter.addSection(this.mDeviceView, "Sensors");
      paramBundle = new HelpView();
      paramBundle.setParameters("help_device.html", 2130903047, 2131492890);
      this.mSectionsPagerAdapter.addSection(paramBundle, "Help");
      this.mProfiles = new ArrayList();
      this.progressDialog = new ProgressDialog(this);
      this.progressDialog.setProgressStyle(1);
      this.progressDialog.setIndeterminate(true);
      this.progressDialog.setTitle("Discovering Services");
      this.progressDialog.setMessage("");
      this.progressDialog.setMax(100);
      this.progressDialog.setProgress(0);
      this.progressDialog.show();
      new GattInfo(getResources().getXml(2130968576));
      return;
    }
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    this.optionsMenu = paramMenu;
    getMenuInflater().inflate(2131427328, paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    if (this.mIsReceiving)
    {
      unregisterReceiver(this.mGattUpdateReceiver);
      this.mIsReceiving = false;
    }
    Iterator localIterator = this.mProfiles.iterator();
    while (localIterator.hasNext()) {
      ((GenericBluetoothProfile)localIterator.next()).onPause();
    }
    if (!isEnabledByPrefs("keepAlive")) {
      this.mBtLeService.timedDisconnect();
    }
    this.mDeviceView.first = true;
    this.mProfiles = null;
    this.mDeviceView.removeRowsFromTable();
    this.mDeviceView = null;
    finishActivity(0);
    finishActivity(1);
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    switch (paramMenuItem.getItemId())
    {
    default: 
      return super.onOptionsItemSelected(paramMenuItem);
    case 2131492898: 
      startPreferenceActivity();
    }
    for (;;)
    {
      return true;
      openStatusDialog();
      continue;
      openAboutDialog();
    }
  }
  
  protected void onPause()
  {
    super.onPause();
  }
  
  protected void onResume()
  {
    super.onResume();
    if (!this.mIsReceiving)
    {
      registerReceiver(this.mGattUpdateReceiver, makeGattUpdateIntentFilter());
      this.mIsReceiving = true;
    }
    Iterator localIterator = this.mProfiles.iterator();
    while (localIterator.hasNext())
    {
      GenericBluetoothProfile localGenericBluetoothProfile = (GenericBluetoothProfile)localIterator.next();
      if (localGenericBluetoothProfile.isConfigured != true) {
        localGenericBluetoothProfile.configureService();
      }
      if (localGenericBluetoothProfile.isEnabled != true) {
        localGenericBluetoothProfile.enableService();
      }
      localGenericBluetoothProfile.onResume();
    }
    this.mBtLeService.abortTimedDisconnect();
  }
  
  void onViewInflated(View paramView)
  {
    setBusy(true);
    setTitle(this.mBluetoothDevice.getName());
    this.mBtGatt = BluetoothLeService.getBtGatt();
    if ((!this.mServicesRdy) && (this.mBtGatt != null) && (this.mBtLeService.getNumServices() == 0)) {
      discoverServices();
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\DeviceActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */