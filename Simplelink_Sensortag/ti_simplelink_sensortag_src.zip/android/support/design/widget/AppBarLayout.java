package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.design.R.style;
import android.support.design.R.styleable;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v4.widget.ScrollerCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@CoordinatorLayout.DefaultBehavior(Behavior.class)
public class AppBarLayout
  extends LinearLayout
{
  private static final int INVALID_SCROLL_RANGE = -1;
  private int mDownPreScrollRange = -1;
  private int mDownScrollRange = -1;
  boolean mHaveChildWithInterpolator;
  private WindowInsetsCompat mLastInsets;
  private final List<WeakReference<OnOffsetChangedListener>> mListeners;
  private float mTargetElevation;
  private int mTotalScrollRange = -1;
  
  public AppBarLayout(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public AppBarLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    setOrientation(1);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.AppBarLayout, 0, R.style.Widget_Design_AppBarLayout);
    this.mTargetElevation = paramContext.getDimensionPixelSize(R.styleable.AppBarLayout_elevation, 0);
    setBackgroundDrawable(paramContext.getDrawable(R.styleable.AppBarLayout_android_background));
    paramContext.recycle();
    ViewUtils.setBoundsViewOutlineProvider(this);
    this.mListeners = new ArrayList();
    ViewCompat.setElevation(this, this.mTargetElevation);
    ViewCompat.setOnApplyWindowInsetsListener(this, new OnApplyWindowInsetsListener()
    {
      public WindowInsetsCompat onApplyWindowInsets(View paramAnonymousView, WindowInsetsCompat paramAnonymousWindowInsetsCompat)
      {
        AppBarLayout.this.setWindowInsets(paramAnonymousWindowInsetsCompat);
        return paramAnonymousWindowInsetsCompat.consumeSystemWindowInsets();
      }
    });
  }
  
  private void setWindowInsets(WindowInsetsCompat paramWindowInsetsCompat)
  {
    this.mTotalScrollRange = -1;
    this.mLastInsets = paramWindowInsetsCompat;
    int i = 0;
    int j = getChildCount();
    for (;;)
    {
      if (i < j)
      {
        paramWindowInsetsCompat = ViewCompat.dispatchApplyWindowInsets(getChildAt(i), paramWindowInsetsCompat);
        if (!paramWindowInsetsCompat.isConsumed()) {}
      }
      else
      {
        return;
      }
      i += 1;
    }
  }
  
  public void addOnOffsetChangedListener(OnOffsetChangedListener paramOnOffsetChangedListener)
  {
    int i = 0;
    int j = this.mListeners.size();
    while (i < j)
    {
      WeakReference localWeakReference = (WeakReference)this.mListeners.get(i);
      if ((localWeakReference != null) && (localWeakReference.get() == paramOnOffsetChangedListener)) {
        return;
      }
      i += 1;
    }
    this.mListeners.add(new WeakReference(paramOnOffsetChangedListener));
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  protected LayoutParams generateDefaultLayoutParams()
  {
    return new LayoutParams(-1, -2);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof LinearLayout.LayoutParams)) {
      return new LayoutParams((LinearLayout.LayoutParams)paramLayoutParams);
    }
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams)) {
      return new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams);
    }
    return new LayoutParams(paramLayoutParams);
  }
  
  final int getDownNestedPreScrollRange()
  {
    if (this.mDownPreScrollRange != -1) {
      return this.mDownPreScrollRange;
    }
    int k = 0;
    int j = getChildCount() - 1;
    if (j >= 0)
    {
      View localView = getChildAt(j);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      int i;
      if (ViewCompat.isLaidOut(localView))
      {
        i = localView.getHeight();
        label57:
        int m = localLayoutParams.mScrollFlags;
        if ((m & 0x5) != 5) {
          break label113;
        }
        if ((m & 0x8) == 0) {
          break label106;
        }
        i = k + ViewCompat.getMinimumHeight(localView);
      }
      label106:
      label113:
      do
      {
        for (;;)
        {
          j -= 1;
          k = i;
          break;
          i = localView.getMeasuredHeight();
          break label57;
          i = k + i;
        }
        i = k;
      } while (k <= 0);
    }
    this.mDownPreScrollRange = k;
    return k;
  }
  
  final int getDownNestedScrollRange()
  {
    if (this.mDownScrollRange != -1) {
      return this.mDownScrollRange;
    }
    int j = 0;
    int i = 0;
    int m = getChildCount();
    while (i < m)
    {
      View localView = getChildAt(i);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      if (ViewCompat.isLaidOut(localView)) {}
      for (int k = localView.getHeight();; k = localView.getMeasuredHeight())
      {
        int n = localLayoutParams.mScrollFlags;
        if ((n & 0x1) == 0) {
          break label109;
        }
        j += k;
        if ((n & 0x2) == 0) {
          break;
        }
        return j - ViewCompat.getMinimumHeight(localView);
      }
      i += 1;
    }
    label109:
    this.mDownScrollRange = j;
    return j;
  }
  
  final int getMinimumHeightForVisibleOverlappingContent()
  {
    int j = 0;
    int i;
    int k;
    if (this.mLastInsets != null)
    {
      i = this.mLastInsets.getSystemWindowInsetTop();
      k = ViewCompat.getMinimumHeight(this);
      if (k == 0) {
        break label39;
      }
      j = k * 2 + i;
    }
    label39:
    do
    {
      return j;
      i = 0;
      break;
      k = getChildCount();
    } while (k < 1);
    return ViewCompat.getMinimumHeight(getChildAt(k - 1)) * 2 + i;
  }
  
  public float getTargetElevation()
  {
    return this.mTargetElevation;
  }
  
  public final int getTotalScrollRange()
  {
    if (this.mTotalScrollRange != -1) {
      return this.mTotalScrollRange;
    }
    int i = 0;
    int j = 0;
    int n = getChildCount();
    int k = i;
    View localView;
    int m;
    if (j < n)
    {
      localView = getChildAt(j);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      if (!ViewCompat.isLaidOut(localView)) {
        break label125;
      }
      m = localView.getHeight();
      label63:
      int i1 = localLayoutParams.mScrollFlags;
      k = i;
      if ((i1 & 0x1) != 0)
      {
        i += m;
        if ((i1 & 0x2) == 0) {
          break label135;
        }
        k = i - ViewCompat.getMinimumHeight(localView);
      }
    }
    if (this.mLastInsets != null) {}
    for (i = this.mLastInsets.getSystemWindowInsetTop();; i = 0)
    {
      i = k - i;
      this.mTotalScrollRange = i;
      return i;
      label125:
      m = localView.getMeasuredHeight();
      break label63;
      label135:
      j += 1;
      break;
    }
  }
  
  final int getUpNestedPreScrollRange()
  {
    return getTotalScrollRange();
  }
  
  final boolean hasChildWithInterpolator()
  {
    return this.mHaveChildWithInterpolator;
  }
  
  final boolean hasScrollableChildren()
  {
    return getTotalScrollRange() != 0;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    this.mTotalScrollRange = -1;
    this.mDownPreScrollRange = -1;
    this.mDownPreScrollRange = -1;
    this.mHaveChildWithInterpolator = false;
    paramInt1 = 0;
    paramInt2 = getChildCount();
    for (;;)
    {
      if (paramInt1 < paramInt2)
      {
        if (((LayoutParams)getChildAt(paramInt1).getLayoutParams()).getScrollInterpolator() != null) {
          this.mHaveChildWithInterpolator = true;
        }
      }
      else {
        return;
      }
      paramInt1 += 1;
    }
  }
  
  public void removeOnOffsetChangedListener(OnOffsetChangedListener paramOnOffsetChangedListener)
  {
    Iterator localIterator = this.mListeners.iterator();
    while (localIterator.hasNext())
    {
      OnOffsetChangedListener localOnOffsetChangedListener = (OnOffsetChangedListener)((WeakReference)localIterator.next()).get();
      if ((localOnOffsetChangedListener == paramOnOffsetChangedListener) || (localOnOffsetChangedListener == null)) {
        localIterator.remove();
      }
    }
  }
  
  public void setOrientation(int paramInt)
  {
    if (paramInt != 1) {
      throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
    }
    super.setOrientation(paramInt);
  }
  
  public void setTargetElevation(float paramFloat)
  {
    this.mTargetElevation = paramFloat;
  }
  
  public static class Behavior
    extends ViewOffsetBehavior<AppBarLayout>
  {
    private static final int INVALID_POSITION = -1;
    private ValueAnimatorCompat mAnimator;
    private Runnable mFlingRunnable;
    private int mOffsetDelta;
    private int mOffsetToChildIndexOnLayout = -1;
    private boolean mOffsetToChildIndexOnLayoutIsMinHeight;
    private float mOffsetToChildIndexOnLayoutPerc;
    private ScrollerCompat mScroller;
    private boolean mSkipNestedPreScroll;
    
    public Behavior() {}
    
    public Behavior(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }
    
    private void animateOffsetTo(final CoordinatorLayout paramCoordinatorLayout, final AppBarLayout paramAppBarLayout, int paramInt)
    {
      if (this.mAnimator == null)
      {
        this.mAnimator = ViewUtils.createAnimator();
        this.mAnimator.setInterpolator(AnimationUtils.DECELERATE_INTERPOLATOR);
        this.mAnimator.setUpdateListener(new ValueAnimatorCompat.AnimatorUpdateListener()
        {
          public void onAnimationUpdate(ValueAnimatorCompat paramAnonymousValueAnimatorCompat)
          {
            AppBarLayout.Behavior.this.setAppBarTopBottomOffset(paramCoordinatorLayout, paramAppBarLayout, paramAnonymousValueAnimatorCompat.getAnimatedIntValue());
          }
        });
      }
      for (;;)
      {
        this.mAnimator.setIntValues(getTopBottomOffsetForScrollingSibling(), paramInt);
        this.mAnimator.start();
        return;
        this.mAnimator.cancel();
      }
    }
    
    private void dispatchOffsetUpdates(AppBarLayout paramAppBarLayout)
    {
      List localList = paramAppBarLayout.mListeners;
      int i = 0;
      int j = localList.size();
      if (i < j)
      {
        Object localObject = (WeakReference)localList.get(i);
        if (localObject != null) {}
        for (localObject = (AppBarLayout.OnOffsetChangedListener)((WeakReference)localObject).get();; localObject = null)
        {
          if (localObject != null) {
            ((AppBarLayout.OnOffsetChangedListener)localObject).onOffsetChanged(paramAppBarLayout, getTopAndBottomOffset());
          }
          i += 1;
          break;
        }
      }
    }
    
    private boolean fling(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, int paramInt1, int paramInt2, float paramFloat)
    {
      if (this.mFlingRunnable != null) {
        paramAppBarLayout.removeCallbacks(this.mFlingRunnable);
      }
      if (this.mScroller == null) {
        this.mScroller = ScrollerCompat.create(paramAppBarLayout.getContext());
      }
      this.mScroller.fling(0, getTopBottomOffsetForScrollingSibling(), 0, Math.round(paramFloat), 0, 0, paramInt1, paramInt2);
      if (this.mScroller.computeScrollOffset())
      {
        this.mFlingRunnable = new FlingRunnable(paramCoordinatorLayout, paramAppBarLayout);
        ViewCompat.postOnAnimation(paramAppBarLayout, this.mFlingRunnable);
        return true;
      }
      this.mFlingRunnable = null;
      return false;
    }
    
    private int interpolateOffset(AppBarLayout paramAppBarLayout, int paramInt)
    {
      int k = Math.abs(paramInt);
      int i = 0;
      int m = paramAppBarLayout.getChildCount();
      for (;;)
      {
        int j = paramInt;
        if (i < m)
        {
          View localView = paramAppBarLayout.getChildAt(i);
          AppBarLayout.LayoutParams localLayoutParams = (AppBarLayout.LayoutParams)localView.getLayoutParams();
          Interpolator localInterpolator = localLayoutParams.getScrollInterpolator();
          if ((k < localView.getTop()) || (k > localView.getBottom())) {
            break label173;
          }
          j = paramInt;
          if (localInterpolator != null)
          {
            i = 0;
            m = localLayoutParams.getScrollFlags();
            if ((m & 0x1) != 0)
            {
              j = 0 + localView.getHeight();
              i = j;
              if ((m & 0x2) != 0) {
                i = j - ViewCompat.getMinimumHeight(localView);
              }
            }
            j = paramInt;
            if (i > 0)
            {
              j = localView.getTop();
              i = Math.round(i * localInterpolator.getInterpolation((k - j) / i));
              j = Integer.signum(paramInt) * (localView.getTop() + i);
            }
          }
        }
        return j;
        label173:
        i += 1;
      }
    }
    
    private int scroll(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, int paramInt1, int paramInt2, int paramInt3)
    {
      return setAppBarTopBottomOffset(paramCoordinatorLayout, paramAppBarLayout, getTopBottomOffsetForScrollingSibling() - paramInt1, paramInt2, paramInt3);
    }
    
    final int getTopBottomOffsetForScrollingSibling()
    {
      return getTopAndBottomOffset() + this.mOffsetDelta;
    }
    
    public boolean onLayoutChild(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, int paramInt)
    {
      boolean bool = super.onLayoutChild(paramCoordinatorLayout, paramAppBarLayout, paramInt);
      if (this.mOffsetToChildIndexOnLayout >= 0)
      {
        paramCoordinatorLayout = paramAppBarLayout.getChildAt(this.mOffsetToChildIndexOnLayout);
        paramInt = -paramCoordinatorLayout.getBottom();
        if (!this.mOffsetToChildIndexOnLayoutIsMinHeight) {
          break label64;
        }
        paramInt += ViewCompat.getMinimumHeight(paramCoordinatorLayout);
      }
      for (;;)
      {
        setTopAndBottomOffset(paramInt);
        this.mOffsetToChildIndexOnLayout = -1;
        dispatchOffsetUpdates(paramAppBarLayout);
        return bool;
        label64:
        paramInt += Math.round(paramCoordinatorLayout.getHeight() * this.mOffsetToChildIndexOnLayoutPerc);
      }
    }
    
    public boolean onNestedFling(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean)
    {
      boolean bool = false;
      if (!paramBoolean) {
        paramBoolean = fling(paramCoordinatorLayout, paramAppBarLayout, -paramAppBarLayout.getTotalScrollRange(), 0, -paramFloat2);
      }
      int i;
      do
      {
        return paramBoolean;
        if (paramFloat2 >= 0.0F) {
          break;
        }
        i = -paramAppBarLayout.getTotalScrollRange() + paramAppBarLayout.getDownNestedPreScrollRange();
        paramBoolean = bool;
      } while (getTopBottomOffsetForScrollingSibling() > i);
      int j;
      do
      {
        paramBoolean = bool;
        if (getTopBottomOffsetForScrollingSibling() == i) {
          break;
        }
        animateOffsetTo(paramCoordinatorLayout, paramAppBarLayout, i);
        return true;
        j = -paramAppBarLayout.getUpNestedPreScrollRange();
        i = j;
      } while (getTopBottomOffsetForScrollingSibling() >= j);
      return false;
    }
    
    public void onNestedPreScroll(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt)
    {
      if ((paramInt2 != 0) && (!this.mSkipNestedPreScroll))
      {
        if (paramInt2 >= 0) {
          break label50;
        }
        paramInt1 = -paramAppBarLayout.getTotalScrollRange();
      }
      for (int i = paramInt1 + paramAppBarLayout.getDownNestedPreScrollRange();; i = 0)
      {
        paramArrayOfInt[1] = scroll(paramCoordinatorLayout, paramAppBarLayout, paramInt2, paramInt1, i);
        return;
        label50:
        paramInt1 = -paramAppBarLayout.getUpNestedPreScrollRange();
      }
    }
    
    public void onNestedScroll(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      if (paramInt4 < 0)
      {
        scroll(paramCoordinatorLayout, paramAppBarLayout, paramInt4, -paramAppBarLayout.getDownNestedScrollRange(), 0);
        this.mSkipNestedPreScroll = true;
        return;
      }
      this.mSkipNestedPreScroll = false;
    }
    
    public void onRestoreInstanceState(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, Parcelable paramParcelable)
    {
      if ((paramParcelable instanceof SavedState))
      {
        paramParcelable = (SavedState)paramParcelable;
        super.onRestoreInstanceState(paramCoordinatorLayout, paramAppBarLayout, paramParcelable.getSuperState());
        this.mOffsetToChildIndexOnLayout = paramParcelable.firstVisibleChildIndex;
        this.mOffsetToChildIndexOnLayoutPerc = paramParcelable.firstVisibileChildPercentageShown;
        this.mOffsetToChildIndexOnLayoutIsMinHeight = paramParcelable.firstVisibileChildAtMinimumHeight;
        return;
      }
      super.onRestoreInstanceState(paramCoordinatorLayout, paramAppBarLayout, paramParcelable);
      this.mOffsetToChildIndexOnLayout = -1;
    }
    
    public Parcelable onSaveInstanceState(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout)
    {
      Parcelable localParcelable = super.onSaveInstanceState(paramCoordinatorLayout, paramAppBarLayout);
      int j = getTopAndBottomOffset();
      int i = 0;
      int k = paramAppBarLayout.getChildCount();
      while (i < k)
      {
        paramCoordinatorLayout = paramAppBarLayout.getChildAt(i);
        int m = paramCoordinatorLayout.getBottom() + j;
        if ((paramCoordinatorLayout.getTop() + j <= 0) && (m >= 0))
        {
          paramAppBarLayout = new SavedState(localParcelable);
          paramAppBarLayout.firstVisibleChildIndex = i;
          if (m == ViewCompat.getMinimumHeight(paramCoordinatorLayout)) {}
          for (boolean bool = true;; bool = false)
          {
            paramAppBarLayout.firstVisibileChildAtMinimumHeight = bool;
            paramAppBarLayout.firstVisibileChildPercentageShown = (m / paramCoordinatorLayout.getHeight());
            return paramAppBarLayout;
          }
        }
        i += 1;
      }
      return localParcelable;
    }
    
    public boolean onStartNestedScroll(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, View paramView1, View paramView2, int paramInt)
    {
      if (((paramInt & 0x2) != 0) && (paramAppBarLayout.hasScrollableChildren()) && (paramCoordinatorLayout.getHeight() - paramView2.getHeight() <= paramAppBarLayout.getHeight())) {}
      for (boolean bool = true;; bool = false)
      {
        if ((bool) && (this.mAnimator != null)) {
          this.mAnimator.cancel();
        }
        return bool;
      }
    }
    
    public void onStopNestedScroll(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, View paramView)
    {
      this.mSkipNestedPreScroll = false;
    }
    
    final int setAppBarTopBottomOffset(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, int paramInt)
    {
      return setAppBarTopBottomOffset(paramCoordinatorLayout, paramAppBarLayout, paramInt, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }
    
    final int setAppBarTopBottomOffset(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, int paramInt1, int paramInt2, int paramInt3)
    {
      int k = getTopBottomOffsetForScrollingSibling();
      int j = 0;
      int i = j;
      if (paramInt2 != 0)
      {
        i = j;
        if (k >= paramInt2)
        {
          i = j;
          if (k <= paramInt3)
          {
            paramInt2 = MathUtils.constrain(paramInt1, paramInt2, paramInt3);
            i = j;
            if (k != paramInt2) {
              if (!paramAppBarLayout.hasChildWithInterpolator()) {
                break label123;
              }
            }
          }
        }
      }
      label123:
      for (paramInt1 = interpolateOffset(paramAppBarLayout, paramInt2);; paramInt1 = paramInt2)
      {
        boolean bool = setTopAndBottomOffset(paramInt1);
        i = k - paramInt2;
        this.mOffsetDelta = (paramInt2 - paramInt1);
        if ((!bool) && (paramAppBarLayout.hasChildWithInterpolator())) {
          paramCoordinatorLayout.dispatchDependentViewsChanged(paramAppBarLayout);
        }
        dispatchOffsetUpdates(paramAppBarLayout);
        return i;
      }
    }
    
    private class FlingRunnable
      implements Runnable
    {
      private final AppBarLayout mLayout;
      private final CoordinatorLayout mParent;
      
      FlingRunnable(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout)
      {
        this.mParent = paramCoordinatorLayout;
        this.mLayout = paramAppBarLayout;
      }
      
      public void run()
      {
        if ((this.mLayout != null) && (AppBarLayout.Behavior.this.mScroller != null) && (AppBarLayout.Behavior.this.mScroller.computeScrollOffset()))
        {
          AppBarLayout.Behavior.this.setAppBarTopBottomOffset(this.mParent, this.mLayout, AppBarLayout.Behavior.this.mScroller.getCurrY());
          ViewCompat.postOnAnimation(this.mLayout, this);
        }
      }
    }
    
    protected static class SavedState
      extends View.BaseSavedState
    {
      public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
      {
        public AppBarLayout.Behavior.SavedState createFromParcel(Parcel paramAnonymousParcel)
        {
          return new AppBarLayout.Behavior.SavedState(paramAnonymousParcel);
        }
        
        public AppBarLayout.Behavior.SavedState[] newArray(int paramAnonymousInt)
        {
          return new AppBarLayout.Behavior.SavedState[paramAnonymousInt];
        }
      };
      boolean firstVisibileChildAtMinimumHeight;
      float firstVisibileChildPercentageShown;
      int firstVisibleChildIndex;
      
      public SavedState(Parcel paramParcel)
      {
        super();
        this.firstVisibleChildIndex = paramParcel.readInt();
        this.firstVisibileChildPercentageShown = paramParcel.readFloat();
        if (paramParcel.readByte() != 0) {}
        for (boolean bool = true;; bool = false)
        {
          this.firstVisibileChildAtMinimumHeight = bool;
          return;
        }
      }
      
      public SavedState(Parcelable paramParcelable)
      {
        super();
      }
      
      public void writeToParcel(Parcel paramParcel, int paramInt)
      {
        super.writeToParcel(paramParcel, paramInt);
        paramParcel.writeInt(this.firstVisibleChildIndex);
        paramParcel.writeFloat(this.firstVisibileChildPercentageShown);
        if (this.firstVisibileChildAtMinimumHeight) {}
        for (paramInt = 1;; paramInt = 0)
        {
          paramParcel.writeByte((byte)paramInt);
          return;
        }
      }
    }
  }
  
  public static class LayoutParams
    extends LinearLayout.LayoutParams
  {
    static final int FLAG_QUICK_RETURN = 5;
    public static final int SCROLL_FLAG_ENTER_ALWAYS = 4;
    public static final int SCROLL_FLAG_ENTER_ALWAYS_COLLAPSED = 8;
    public static final int SCROLL_FLAG_EXIT_UNTIL_COLLAPSED = 2;
    public static final int SCROLL_FLAG_SCROLL = 1;
    int mScrollFlags = 1;
    Interpolator mScrollInterpolator;
    
    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }
    
    public LayoutParams(int paramInt1, int paramInt2, float paramFloat)
    {
      super(paramInt2, paramFloat);
    }
    
    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.AppBarLayout_LayoutParams);
      this.mScrollFlags = paramAttributeSet.getInt(R.styleable.AppBarLayout_LayoutParams_layout_scrollFlags, 0);
      if (paramAttributeSet.hasValue(R.styleable.AppBarLayout_LayoutParams_layout_scrollInterpolator)) {
        this.mScrollInterpolator = android.view.animation.AnimationUtils.loadInterpolator(paramContext, paramAttributeSet.getResourceId(R.styleable.AppBarLayout_LayoutParams_layout_scrollInterpolator, 0));
      }
      paramAttributeSet.recycle();
    }
    
    public LayoutParams(LayoutParams paramLayoutParams)
    {
      super();
      this.mScrollFlags = paramLayoutParams.mScrollFlags;
      this.mScrollInterpolator = paramLayoutParams.mScrollInterpolator;
    }
    
    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
    }
    
    public LayoutParams(LinearLayout.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public int getScrollFlags()
    {
      return this.mScrollFlags;
    }
    
    public Interpolator getScrollInterpolator()
    {
      return this.mScrollInterpolator;
    }
    
    public void setScrollFlags(int paramInt)
    {
      this.mScrollFlags = paramInt;
    }
    
    public void setScrollInterpolator(Interpolator paramInterpolator)
    {
      this.mScrollInterpolator = paramInterpolator;
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public static @interface ScrollFlags {}
  }
  
  public static abstract interface OnOffsetChangedListener
  {
    public abstract void onOffsetChanged(AppBarLayout paramAppBarLayout, int paramInt);
  }
  
  public static class ScrollingViewBehavior
    extends ViewOffsetBehavior<View>
  {
    private int mOverlayTop;
    
    public ScrollingViewBehavior() {}
    
    public ScrollingViewBehavior(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ScrollingViewBehavior_Params);
      this.mOverlayTop = paramContext.getDimensionPixelSize(R.styleable.ScrollingViewBehavior_Params_behavior_overlapTop, 0);
      paramContext.recycle();
    }
    
    private static AppBarLayout findFirstAppBarLayout(List<View> paramList)
    {
      int i = 0;
      int j = paramList.size();
      while (i < j)
      {
        View localView = (View)paramList.get(i);
        if ((localView instanceof AppBarLayout)) {
          return (AppBarLayout)localView;
        }
        i += 1;
      }
      return null;
    }
    
    public int getOverlayTop()
    {
      return this.mOverlayTop;
    }
    
    public boolean layoutDependsOn(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2)
    {
      return paramView2 instanceof AppBarLayout;
    }
    
    public boolean onDependentViewChanged(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2)
    {
      CoordinatorLayout.Behavior localBehavior = ((CoordinatorLayout.LayoutParams)paramView2.getLayoutParams()).getBehavior();
      int i;
      if ((localBehavior instanceof AppBarLayout.Behavior))
      {
        i = ((AppBarLayout.Behavior)localBehavior).getTopBottomOffsetForScrollingSibling();
        int j = paramView2.getHeight();
        int k = this.mOverlayTop;
        int m = paramCoordinatorLayout.getHeight();
        int n = paramView1.getHeight();
        if ((this.mOverlayTop == 0) || (!(paramView2 instanceof AppBarLayout))) {
          break label107;
        }
        int i1 = ((AppBarLayout)paramView2).getTotalScrollRange();
        setTopAndBottomOffset(AnimationUtils.lerp(j - k, m - n, Math.abs(i) / i1));
      }
      for (;;)
      {
        return false;
        label107:
        setTopAndBottomOffset(paramView2.getHeight() - this.mOverlayTop + i);
      }
    }
    
    public boolean onMeasureChild(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      if (paramView.getLayoutParams().height == -1)
      {
        Object localObject = paramCoordinatorLayout.getDependencies(paramView);
        if (((List)localObject).isEmpty()) {
          return false;
        }
        localObject = findFirstAppBarLayout((List)localObject);
        if ((localObject != null) && (ViewCompat.isLaidOut((View)localObject)))
        {
          if (ViewCompat.getFitsSystemWindows((View)localObject)) {
            ViewCompat.setFitsSystemWindows(paramView, true);
          }
          int i = View.MeasureSpec.getSize(paramInt3);
          paramInt3 = i;
          if (i == 0) {
            paramInt3 = paramCoordinatorLayout.getHeight();
          }
          paramCoordinatorLayout.onMeasureChild(paramView, paramInt1, paramInt2, View.MeasureSpec.makeMeasureSpec(paramInt3 - ((AppBarLayout)localObject).getMeasuredHeight() + ((AppBarLayout)localObject).getTotalScrollRange(), Integer.MIN_VALUE), paramInt4);
          return true;
        }
      }
      return false;
    }
    
    public void setOverlayTop(int paramInt)
    {
      this.mOverlayTop = paramInt;
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\Simplelink_Sensortag\classes-dex2jar.jar!\android\support\design\widget\AppBarLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */