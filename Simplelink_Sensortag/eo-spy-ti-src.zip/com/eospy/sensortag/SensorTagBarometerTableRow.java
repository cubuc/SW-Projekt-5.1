package com.eospy.sensortag;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import com.eospy.util.GenericCharacteristicTableRow;
import com.eospy.util.SparkLineView;

public class SensorTagBarometerTableRow
  extends GenericCharacteristicTableRow
{
  public SensorTagBarometerTableRow(Context paramContext)
  {
    super(paramContext);
    this.calibrateButton.setOnClickListener(this);
  }
  
  public void calibrationButtonTouched()
  {
    Intent localIntent = new Intent("com.eospy.util.ACTION_CALIBRATE");
    localIntent.putExtra("com.eospy.util.EXTRA_SERVICE_UUID", this.uuidLabel.getText());
    this.context.sendBroadcast(localIntent);
  }
  
  public void grayedOut(boolean paramBoolean)
  {
    super.grayedOut(paramBoolean);
    if (paramBoolean)
    {
      this.calibrateButton.setAlpha(0.4F);
      return;
    }
    this.calibrateButton.setAlpha(1.0F);
  }
  
  public void onAnimationEnd(Animation paramAnimation)
  {
    if (this.config == true)
    {
      this.sl1.setVisibility(4);
      if (this.sl2.isEnabled()) {
        this.sl2.setVisibility(4);
      }
      if (this.sl3.isEnabled()) {
        this.sl3.setVisibility(4);
      }
      this.onOff.setVisibility(0);
      this.onOffLegend.setVisibility(0);
      this.periodBar.setVisibility(0);
      this.periodLegend.setVisibility(0);
      this.calibrateButton.setVisibility(0);
      return;
    }
    this.sl1.setVisibility(0);
    if (this.sl2.isEnabled()) {
      this.sl2.setVisibility(0);
    }
    if (this.sl3.isEnabled()) {
      this.sl3.setVisibility(0);
    }
    this.onOff.setVisibility(4);
    this.onOffLegend.setVisibility(4);
    this.periodBar.setVisibility(4);
    this.periodLegend.setVisibility(4);
    this.calibrateButton.setVisibility(4);
  }
  
  public void onAnimationRepeat(Animation paramAnimation) {}
  
  public void onAnimationStart(Animation paramAnimation) {}
  
  public void onClick(View paramView)
  {
    if (paramView.equals(this.calibrateButton))
    {
      calibrationButtonTouched();
      return;
    }
    if (!this.config) {}
    AlphaAnimation localAlphaAnimation;
    for (boolean bool = true;; bool = false)
    {
      this.config = bool;
      paramView = new AlphaAnimation(1.0F, 0.0F);
      paramView.setAnimationListener(this);
      paramView.setDuration(500L);
      paramView.setStartOffset(0L);
      localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
      localAlphaAnimation.setAnimationListener(this);
      localAlphaAnimation.setDuration(500L);
      localAlphaAnimation.setStartOffset(250L);
      if (this.config != true) {
        break;
      }
      this.sl1.startAnimation(paramView);
      if (this.sl2.isEnabled()) {
        this.sl2.startAnimation(paramView);
      }
      if (this.sl3.isEnabled()) {
        this.sl3.startAnimation(paramView);
      }
      this.value.startAnimation(paramView);
      this.onOffLegend.startAnimation(localAlphaAnimation);
      this.onOff.startAnimation(localAlphaAnimation);
      this.periodLegend.startAnimation(localAlphaAnimation);
      this.periodBar.startAnimation(localAlphaAnimation);
      this.calibrateButton.startAnimation(localAlphaAnimation);
      return;
    }
    this.sl1.startAnimation(localAlphaAnimation);
    if (this.sl2.isEnabled()) {
      this.sl2.startAnimation(localAlphaAnimation);
    }
    if (this.sl3.isEnabled()) {
      this.sl3.startAnimation(localAlphaAnimation);
    }
    this.value.startAnimation(localAlphaAnimation);
    this.onOffLegend.startAnimation(paramView);
    this.onOff.startAnimation(paramView);
    this.periodLegend.startAnimation(paramView);
    this.periodBar.startAnimation(paramView);
    this.calibrateButton.startAnimation(paramView);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\SensorTagBarometerTableRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */