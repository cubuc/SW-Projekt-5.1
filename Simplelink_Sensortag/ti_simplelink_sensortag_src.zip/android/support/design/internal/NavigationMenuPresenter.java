package android.support.design.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.R.dimen;
import android.support.design.R.layout;
import android.support.v7.internal.view.menu.MenuBuilder;
import android.support.v7.internal.view.menu.MenuItemImpl;
import android.support.v7.internal.view.menu.MenuPresenter;
import android.support.v7.internal.view.menu.MenuPresenter.Callback;
import android.support.v7.internal.view.menu.MenuView;
import android.support.v7.internal.view.menu.SubMenuBuilder;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;

public class NavigationMenuPresenter
  implements MenuPresenter, AdapterView.OnItemClickListener
{
  private static final String STATE_ADAPTER = "android:menu:adapter";
  private static final String STATE_HIERARCHY = "android:menu:list";
  private NavigationMenuAdapter mAdapter;
  private MenuPresenter.Callback mCallback;
  private LinearLayout mHeader;
  private ColorStateList mIconTintList;
  private int mId;
  private Drawable mItemBackground;
  private LayoutInflater mLayoutInflater;
  private MenuBuilder mMenu;
  private NavigationMenuView mMenuView;
  private int mPaddingSeparator;
  private int mPaddingTopDefault;
  private ColorStateList mTextColor;
  
  public void addHeaderView(@NonNull View paramView)
  {
    this.mHeader.addView(paramView);
    this.mMenuView.setPadding(0, 0, 0, this.mMenuView.getPaddingBottom());
  }
  
  public boolean collapseItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl)
  {
    return false;
  }
  
  public boolean expandItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl)
  {
    return false;
  }
  
  public boolean flagActionItems()
  {
    return false;
  }
  
  public int getId()
  {
    return this.mId;
  }
  
  public Drawable getItemBackground()
  {
    return this.mItemBackground;
  }
  
  @Nullable
  public ColorStateList getItemTextColor()
  {
    return this.mTextColor;
  }
  
  @Nullable
  public ColorStateList getItemTintList()
  {
    return this.mIconTintList;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup)
  {
    if (this.mMenuView == null)
    {
      this.mMenuView = ((NavigationMenuView)this.mLayoutInflater.inflate(R.layout.design_navigation_menu, paramViewGroup, false));
      if (this.mAdapter == null) {
        this.mAdapter = new NavigationMenuAdapter();
      }
      this.mHeader = ((LinearLayout)this.mLayoutInflater.inflate(R.layout.design_navigation_item_header, this.mMenuView, false));
      this.mMenuView.addHeaderView(this.mHeader);
      this.mMenuView.setAdapter(this.mAdapter);
      this.mMenuView.setOnItemClickListener(this);
    }
    return this.mMenuView;
  }
  
  public View inflateHeaderView(@LayoutRes int paramInt)
  {
    View localView = this.mLayoutInflater.inflate(paramInt, this.mHeader, false);
    addHeaderView(localView);
    return localView;
  }
  
  public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder)
  {
    this.mLayoutInflater = LayoutInflater.from(paramContext);
    this.mMenu = paramMenuBuilder;
    paramContext = paramContext.getResources();
    this.mPaddingTopDefault = paramContext.getDimensionPixelOffset(R.dimen.navigation_padding_top_default);
    this.mPaddingSeparator = paramContext.getDimensionPixelOffset(R.dimen.navigation_separator_vertical_padding);
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    if (this.mCallback != null) {
      this.mCallback.onCloseMenu(paramMenuBuilder, paramBoolean);
    }
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    paramInt -= this.mMenuView.getHeaderViewsCount();
    if (paramInt >= 0) {
      this.mMenu.performItemAction(this.mAdapter.getItem(paramInt).getMenuItem(), this, 0);
    }
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    paramParcelable = (Bundle)paramParcelable;
    SparseArray localSparseArray = paramParcelable.getSparseParcelableArray("android:menu:list");
    if (localSparseArray != null) {
      this.mMenuView.restoreHierarchyState(localSparseArray);
    }
    paramParcelable = paramParcelable.getBundle("android:menu:adapter");
    if (paramParcelable != null) {
      this.mAdapter.restoreInstanceState(paramParcelable);
    }
  }
  
  public Parcelable onSaveInstanceState()
  {
    Bundle localBundle = new Bundle();
    if (this.mMenuView != null)
    {
      SparseArray localSparseArray = new SparseArray();
      this.mMenuView.saveHierarchyState(localSparseArray);
      localBundle.putSparseParcelableArray("android:menu:list", localSparseArray);
    }
    if (this.mAdapter != null) {
      localBundle.putBundle("android:menu:adapter", this.mAdapter.createInstanceState());
    }
    return localBundle;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    return false;
  }
  
  public void removeHeaderView(@NonNull View paramView)
  {
    this.mHeader.removeView(paramView);
    if (this.mHeader.getChildCount() == 0) {
      this.mMenuView.setPadding(0, this.mPaddingTopDefault, 0, this.mMenuView.getPaddingBottom());
    }
  }
  
  public void setCallback(MenuPresenter.Callback paramCallback)
  {
    this.mCallback = paramCallback;
  }
  
  public void setId(int paramInt)
  {
    this.mId = paramInt;
  }
  
  public void setItemBackground(Drawable paramDrawable)
  {
    this.mItemBackground = paramDrawable;
  }
  
  public void setItemIconTintList(@Nullable ColorStateList paramColorStateList)
  {
    this.mIconTintList = paramColorStateList;
  }
  
  public void setItemTextColor(@Nullable ColorStateList paramColorStateList)
  {
    this.mTextColor = paramColorStateList;
  }
  
  public void setUpdateSuspended(boolean paramBoolean)
  {
    if (this.mAdapter != null) {
      this.mAdapter.setUpdateSuspended(paramBoolean);
    }
  }
  
  public void updateMenuView(boolean paramBoolean)
  {
    if (this.mAdapter != null) {
      this.mAdapter.notifyDataSetChanged();
    }
  }
  
  private class NavigationMenuAdapter
    extends BaseAdapter
  {
    private static final String STATE_CHECKED_ITEMS = "android:menu:checked";
    private static final int VIEW_TYPE_NORMAL = 0;
    private static final int VIEW_TYPE_SEPARATOR = 2;
    private static final int VIEW_TYPE_SUBHEADER = 1;
    private final ArrayList<NavigationMenuPresenter.NavigationMenuItem> mItems = new ArrayList();
    private ColorDrawable mTransparentIcon;
    private boolean mUpdateSuspended;
    
    NavigationMenuAdapter()
    {
      prepareMenuItems();
    }
    
    private void appendTransparentIconIfMissing(int paramInt1, int paramInt2)
    {
      while (paramInt1 < paramInt2)
      {
        MenuItemImpl localMenuItemImpl = ((NavigationMenuPresenter.NavigationMenuItem)this.mItems.get(paramInt1)).getMenuItem();
        if (localMenuItemImpl.getIcon() == null)
        {
          if (this.mTransparentIcon == null) {
            this.mTransparentIcon = new ColorDrawable(17170445);
          }
          localMenuItemImpl.setIcon(this.mTransparentIcon);
        }
        paramInt1 += 1;
      }
    }
    
    private void prepareMenuItems()
    {
      if (this.mUpdateSuspended) {}
      int i1;
      int k;
      int m;
      int n;
      Object localObject;
      int j;
      int i3;
      int i;
      for (;;)
      {
        return;
        this.mItems.clear();
        i1 = -1;
        k = 0;
        m = 0;
        n = 0;
        int i4 = NavigationMenuPresenter.this.mMenu.getVisibleItems().size();
        while (n < i4)
        {
          localObject = (MenuItemImpl)NavigationMenuPresenter.this.mMenu.getVisibleItems().get(n);
          if (!((MenuItemImpl)localObject).hasSubMenu()) {
            break label296;
          }
          SubMenu localSubMenu = ((MenuItemImpl)localObject).getSubMenu();
          j = m;
          i2 = i1;
          i3 = k;
          if (localSubMenu.hasVisibleItems())
          {
            if (n != 0) {
              this.mItems.add(NavigationMenuPresenter.NavigationMenuItem.separator(NavigationMenuPresenter.this.mPaddingSeparator, 0));
            }
            this.mItems.add(NavigationMenuPresenter.NavigationMenuItem.of((MenuItemImpl)localObject));
            i = 0;
            int i5 = this.mItems.size();
            i2 = 0;
            i3 = localSubMenu.size();
            while (i2 < i3)
            {
              localObject = localSubMenu.getItem(i2);
              j = i;
              if (((MenuItem)localObject).isVisible())
              {
                j = i;
                if (i == 0)
                {
                  j = i;
                  if (((MenuItem)localObject).getIcon() != null) {
                    j = 1;
                  }
                }
                this.mItems.add(NavigationMenuPresenter.NavigationMenuItem.of((MenuItemImpl)localObject));
              }
              i2 += 1;
              i = j;
            }
            j = m;
            i2 = i1;
            i3 = k;
            if (i != 0)
            {
              appendTransparentIconIfMissing(i5, this.mItems.size());
              i3 = k;
              i2 = i1;
              j = m;
            }
          }
          n += 1;
          m = j;
          i1 = i2;
          k = i3;
        }
      }
      label296:
      int i2 = ((MenuItemImpl)localObject).getGroupId();
      if (i2 != i1)
      {
        m = this.mItems.size();
        if (((MenuItemImpl)localObject).getIcon() != null)
        {
          k = 1;
          label329:
          j = k;
          i = m;
          if (n != 0)
          {
            i = m + 1;
            this.mItems.add(NavigationMenuPresenter.NavigationMenuItem.separator(NavigationMenuPresenter.this.mPaddingSeparator, NavigationMenuPresenter.this.mPaddingSeparator));
            j = k;
          }
        }
      }
      for (;;)
      {
        if ((j != 0) && (((MenuItemImpl)localObject).getIcon() == null)) {
          ((MenuItemImpl)localObject).setIcon(17170445);
        }
        this.mItems.add(NavigationMenuPresenter.NavigationMenuItem.of((MenuItemImpl)localObject));
        i3 = i;
        break;
        k = 0;
        break label329;
        j = m;
        i = k;
        if (m == 0)
        {
          j = m;
          i = k;
          if (((MenuItemImpl)localObject).getIcon() != null)
          {
            j = 1;
            appendTransparentIconIfMissing(k, this.mItems.size());
            i = k;
          }
        }
      }
    }
    
    public boolean areAllItemsEnabled()
    {
      return false;
    }
    
    public Bundle createInstanceState()
    {
      Bundle localBundle = new Bundle();
      ArrayList localArrayList = new ArrayList();
      Iterator localIterator = this.mItems.iterator();
      while (localIterator.hasNext())
      {
        MenuItemImpl localMenuItemImpl = ((NavigationMenuPresenter.NavigationMenuItem)localIterator.next()).getMenuItem();
        if ((localMenuItemImpl != null) && (localMenuItemImpl.isChecked())) {
          localArrayList.add(Integer.valueOf(localMenuItemImpl.getItemId()));
        }
      }
      localBundle.putIntegerArrayList("android:menu:checked", localArrayList);
      return localBundle;
    }
    
    public int getCount()
    {
      return this.mItems.size();
    }
    
    public NavigationMenuPresenter.NavigationMenuItem getItem(int paramInt)
    {
      return (NavigationMenuPresenter.NavigationMenuItem)this.mItems.get(paramInt);
    }
    
    public long getItemId(int paramInt)
    {
      return paramInt;
    }
    
    public int getItemViewType(int paramInt)
    {
      NavigationMenuPresenter.NavigationMenuItem localNavigationMenuItem = getItem(paramInt);
      if (localNavigationMenuItem.isSeparator()) {
        return 2;
      }
      if (localNavigationMenuItem.getMenuItem().hasSubMenu()) {
        return 1;
      }
      return 0;
    }
    
    public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      NavigationMenuPresenter.NavigationMenuItem localNavigationMenuItem = getItem(paramInt);
      switch (getItemViewType(paramInt))
      {
      default: 
        return paramView;
      case 0: 
        localView = paramView;
        if (paramView == null) {
          localView = NavigationMenuPresenter.this.mLayoutInflater.inflate(R.layout.design_navigation_item, paramViewGroup, false);
        }
        paramViewGroup = (NavigationMenuItemView)localView;
        paramViewGroup.setIconTintList(NavigationMenuPresenter.this.mIconTintList);
        paramViewGroup.setTextColor(NavigationMenuPresenter.this.mTextColor);
        if (NavigationMenuPresenter.this.mItemBackground != null) {}
        for (paramView = NavigationMenuPresenter.this.mItemBackground.getConstantState().newDrawable();; paramView = null)
        {
          paramViewGroup.setBackgroundDrawable(paramView);
          paramViewGroup.initialize(localNavigationMenuItem.getMenuItem(), 0);
          return localView;
        }
      case 1: 
        localView = paramView;
        if (paramView == null) {
          localView = NavigationMenuPresenter.this.mLayoutInflater.inflate(R.layout.design_navigation_item_subheader, paramViewGroup, false);
        }
        ((TextView)localView).setText(localNavigationMenuItem.getMenuItem().getTitle());
        return localView;
      }
      View localView = paramView;
      if (paramView == null) {
        localView = NavigationMenuPresenter.this.mLayoutInflater.inflate(R.layout.design_navigation_item_separator, paramViewGroup, false);
      }
      localView.setPadding(0, localNavigationMenuItem.getPaddingTop(), 0, localNavigationMenuItem.getPaddingBottom());
      return localView;
    }
    
    public int getViewTypeCount()
    {
      return 3;
    }
    
    public boolean isEnabled(int paramInt)
    {
      return getItem(paramInt).isEnabled();
    }
    
    public void notifyDataSetChanged()
    {
      prepareMenuItems();
      super.notifyDataSetChanged();
    }
    
    public void restoreInstanceState(Bundle paramBundle)
    {
      paramBundle = paramBundle.getIntegerArrayList("android:menu:checked");
      if (paramBundle != null)
      {
        this.mUpdateSuspended = true;
        Iterator localIterator = this.mItems.iterator();
        while (localIterator.hasNext())
        {
          MenuItemImpl localMenuItemImpl = ((NavigationMenuPresenter.NavigationMenuItem)localIterator.next()).getMenuItem();
          if ((localMenuItemImpl != null) && (paramBundle.contains(Integer.valueOf(localMenuItemImpl.getItemId())))) {
            localMenuItemImpl.setChecked(true);
          }
        }
        this.mUpdateSuspended = false;
        prepareMenuItems();
      }
    }
    
    public void setUpdateSuspended(boolean paramBoolean)
    {
      this.mUpdateSuspended = paramBoolean;
    }
  }
  
  private static class NavigationMenuItem
  {
    private final MenuItemImpl mMenuItem;
    private final int mPaddingBottom;
    private final int mPaddingTop;
    
    private NavigationMenuItem(MenuItemImpl paramMenuItemImpl, int paramInt1, int paramInt2)
    {
      this.mMenuItem = paramMenuItemImpl;
      this.mPaddingTop = paramInt1;
      this.mPaddingBottom = paramInt2;
    }
    
    public static NavigationMenuItem of(MenuItemImpl paramMenuItemImpl)
    {
      return new NavigationMenuItem(paramMenuItemImpl, 0, 0);
    }
    
    public static NavigationMenuItem separator(int paramInt1, int paramInt2)
    {
      return new NavigationMenuItem(null, paramInt1, paramInt2);
    }
    
    public MenuItemImpl getMenuItem()
    {
      return this.mMenuItem;
    }
    
    public int getPaddingBottom()
    {
      return this.mPaddingBottom;
    }
    
    public int getPaddingTop()
    {
      return this.mPaddingTop;
    }
    
    public boolean isEnabled()
    {
      return (this.mMenuItem != null) && (!this.mMenuItem.hasSubMenu()) && (this.mMenuItem.isEnabled());
    }
    
    public boolean isSeparator()
    {
      return this.mMenuItem == null;
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\Simplelink_Sensortag\classes-dex2jar.jar!\android\support\design\internal\NavigationMenuPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */