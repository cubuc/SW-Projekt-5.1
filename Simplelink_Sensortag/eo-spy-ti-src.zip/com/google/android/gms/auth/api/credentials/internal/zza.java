package com.google.android.gms.auth.api.credentials.internal;

import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.common.api.Status;

public class zza
  extends zzg.zza
{
  public void zza(Status paramStatus, Credential paramCredential)
  {
    throw new UnsupportedOperationException();
  }
  
  public void zzg(Status paramStatus)
  {
    throw new UnsupportedOperationException();
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\google\android\gms\auth\api\credentials\internal\zza.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */