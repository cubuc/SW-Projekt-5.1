package com.eospy.client;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import java.util.Date;

public class DatabaseHelper
  extends SQLiteOpenHelper
{
  public static final String DATABASE_NAME = "eospy.db";
  public static final int DATABASE_VERSION = 1;
  private SQLiteDatabase db = getWritableDatabase();
  
  public DatabaseHelper(Context paramContext)
  {
    super(paramContext, "eospy.db", null, 1);
  }
  
  public void deletePosition(long paramLong)
  {
    if (this.db.delete("position", "id = ?", new String[] { String.valueOf(paramLong) }) != 1) {
      throw new SQLException();
    }
  }
  
  public void deletePositionAsync(final long paramLong, DatabaseHandler<Void> paramDatabaseHandler)
  {
    new DatabaseAsyncTask(paramDatabaseHandler)
    {
      protected Void executeMethod()
      {
        DatabaseHelper.this.deletePosition(paramLong);
        return null;
      }
    }.execute(new Void[0]);
  }
  
  public void insertPosition(Position paramPosition)
  {
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("deviceId", paramPosition.getDeviceId());
    localContentValues.put("time", Long.valueOf(paramPosition.getTime().getTime()));
    localContentValues.put("latitude", Double.valueOf(paramPosition.getLatitude()));
    localContentValues.put("longitude", Double.valueOf(paramPosition.getLongitude()));
    localContentValues.put("altitude", Double.valueOf(paramPosition.getAltitude()));
    localContentValues.put("speed", Double.valueOf(paramPosition.getSpeed()));
    localContentValues.put("course", Double.valueOf(paramPosition.getCourse()));
    localContentValues.put("battery", Double.valueOf(paramPosition.getBattery()));
    localContentValues.put("temp", Double.valueOf(paramPosition.getTemp()));
    localContentValues.put("ir_temp", Double.valueOf(paramPosition.getIR_Temp()));
    localContentValues.put("humidity", Double.valueOf(paramPosition.getHumidity()));
    localContentValues.put("mbar", Double.valueOf(paramPosition.getMbar()));
    localContentValues.put("accel_x", Double.valueOf(paramPosition.getAccel_x()));
    localContentValues.put("accel_y", Double.valueOf(paramPosition.getAccel_y()));
    localContentValues.put("accel_z", Double.valueOf(paramPosition.getAccel_z()));
    localContentValues.put("gyro_x", Double.valueOf(paramPosition.getGyro_x()));
    localContentValues.put("gyro_y", Double.valueOf(paramPosition.getGyro_y()));
    localContentValues.put("gyro_z", Double.valueOf(paramPosition.getGyro_z()));
    localContentValues.put("magnet_x", Double.valueOf(paramPosition.getMagnet_x()));
    localContentValues.put("magnet_y", Double.valueOf(paramPosition.getMagnet_y()));
    localContentValues.put("magnet_z", Double.valueOf(paramPosition.getMagnet_z()));
    localContentValues.put("light", Double.valueOf(paramPosition.getLight()));
    localContentValues.put("keypress", Double.valueOf(paramPosition.getKeyPress()));
    this.db.insertOrThrow("position", null, localContentValues);
  }
  
  public void insertPositionAsync(final Position paramPosition, DatabaseHandler<Void> paramDatabaseHandler)
  {
    new DatabaseAsyncTask(paramDatabaseHandler)
    {
      protected Void executeMethod()
      {
        DatabaseHelper.this.insertPosition(paramPosition);
        return null;
      }
    }.execute(new Void[0]);
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
    paramSQLiteDatabase.execSQL("CREATE TABLE position (id INTEGER PRIMARY KEY AUTOINCREMENT,deviceId TEXT,time INTEGER,latitude REAL,longitude REAL,altitude REAL,speed REAL,course REAL,battery REAL,temp REAL,ir_temp REAL,humidity REAL,mbar REAL,accel_x REAL,accel_y REAL,accel_z REAL,gyro_x REAL,gyro_y REAL,gyro_z REAL,magnet_x REAL,magnet_y REAL,magnet_z REAL,light REAL,keypress REAL)");
  }
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
  {
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS position;");
    onCreate(paramSQLiteDatabase);
  }
  
  public Position selectPosition()
  {
    Position localPosition = new Position();
    Cursor localCursor = this.db.rawQuery("SELECT * FROM position ORDER BY id LIMIT 1", null);
    try
    {
      if (localCursor.getCount() > 0)
      {
        localCursor.moveToFirst();
        localPosition.setId(localCursor.getLong(localCursor.getColumnIndex("id")));
        localPosition.setDeviceId(localCursor.getString(localCursor.getColumnIndex("deviceId")));
        localPosition.setTime(new Date(localCursor.getLong(localCursor.getColumnIndex("time"))));
        localPosition.setLatitude(localCursor.getDouble(localCursor.getColumnIndex("latitude")));
        localPosition.setLongitude(localCursor.getDouble(localCursor.getColumnIndex("longitude")));
        localPosition.setAltitude(localCursor.getDouble(localCursor.getColumnIndex("altitude")));
        localPosition.setSpeed(localCursor.getDouble(localCursor.getColumnIndex("speed")));
        localPosition.setCourse(localCursor.getDouble(localCursor.getColumnIndex("course")));
        localPosition.setBattery(localCursor.getDouble(localCursor.getColumnIndex("battery")));
        localPosition.setTemp(localCursor.getDouble(localCursor.getColumnIndex("temp")));
        localPosition.setIR_Temp(localCursor.getDouble(localCursor.getColumnIndex("ir_temp")));
        localPosition.setHumidity(localCursor.getDouble(localCursor.getColumnIndex("humidity")));
        localPosition.setMbar(localCursor.getDouble(localCursor.getColumnIndex("mbar")));
        localPosition.setAccel_x(localCursor.getDouble(localCursor.getColumnIndex("accel_x")));
        localPosition.setAccel_y(localCursor.getDouble(localCursor.getColumnIndex("accel_y")));
        localPosition.setAccel_z(localCursor.getDouble(localCursor.getColumnIndex("accel_z")));
        localPosition.setGyro_x(localCursor.getDouble(localCursor.getColumnIndex("gyro_x")));
        localPosition.setGyro_y(localCursor.getDouble(localCursor.getColumnIndex("gyro_y")));
        localPosition.setGyro_z(localCursor.getDouble(localCursor.getColumnIndex("gyro_z")));
        localPosition.setMagnet_x(localCursor.getDouble(localCursor.getColumnIndex("magnet_x")));
        localPosition.setMagnet_y(localCursor.getDouble(localCursor.getColumnIndex("magnet_y")));
        localPosition.setMagnet_z(localCursor.getDouble(localCursor.getColumnIndex("magnet_z")));
        localPosition.setLight(localCursor.getDouble(localCursor.getColumnIndex("light")));
        localPosition.setKeyPress(localCursor.getDouble(localCursor.getColumnIndex("keypress")));
        return localPosition;
      }
      return null;
    }
    finally
    {
      localCursor.close();
    }
  }
  
  public void selectPositionAsync(DatabaseHandler<Position> paramDatabaseHandler)
  {
    new DatabaseAsyncTask(paramDatabaseHandler)
    {
      protected Position executeMethod()
      {
        return DatabaseHelper.this.selectPosition();
      }
    }.execute(new Void[0]);
  }
  
  private static abstract class DatabaseAsyncTask<T>
    extends AsyncTask<Void, Void, T>
  {
    private RuntimeException error;
    private DatabaseHelper.DatabaseHandler<T> handler;
    
    public DatabaseAsyncTask(DatabaseHelper.DatabaseHandler<T> paramDatabaseHandler)
    {
      this.handler = paramDatabaseHandler;
    }
    
    protected T doInBackground(Void... paramVarArgs)
    {
      try
      {
        paramVarArgs = executeMethod();
        return paramVarArgs;
      }
      catch (RuntimeException paramVarArgs)
      {
        this.error = paramVarArgs;
      }
      return null;
    }
    
    protected abstract T executeMethod();
    
    protected void onPostExecute(T paramT)
    {
      DatabaseHelper.DatabaseHandler localDatabaseHandler = this.handler;
      if (this.error == null) {}
      for (boolean bool = true;; bool = false)
      {
        localDatabaseHandler.onComplete(bool, paramT);
        return;
      }
    }
  }
  
  public static abstract interface DatabaseHandler<T>
  {
    public abstract void onComplete(boolean paramBoolean, T paramT);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\DatabaseHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */