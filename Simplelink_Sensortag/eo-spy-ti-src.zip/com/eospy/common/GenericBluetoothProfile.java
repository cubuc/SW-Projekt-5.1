package com.eospy.common;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Switch;
import android.widget.TableRow;
import android.widget.TextView;
import com.eospy.util.GenericCharacteristicTableRow;
import java.util.Map;
import java.util.UUID;

public class GenericBluetoothProfile
{
  protected static final int GATT_TIMEOUT = 250;
  protected BluetoothGattCharacteristic configC;
  protected Context context;
  protected BluetoothGattCharacteristic dataC;
  private final BroadcastReceiver guiReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      paramAnonymousContext = paramAnonymousIntent.getAction();
      String str = paramAnonymousIntent.getStringExtra("com.eospy.util.EXTRA_SERVICE_UUID");
      Log.d("Test", str + "!=" + GenericBluetoothProfile.this.tRow.uuidLabel.getText().toString());
      if (GenericBluetoothProfile.this.tRow.uuidLabel.getText().toString().compareTo(str) == 0)
      {
        if (paramAnonymousContext.compareTo("com.eospy.util.ACTION_PERIOD_UPDATE") != 0) {
          break label114;
        }
        int i = paramAnonymousIntent.getIntExtra("com.eospy.util.EXTRA_PERIOD", 1000);
        GenericBluetoothProfile.this.periodWasUpdated(i);
      }
      label114:
      do
      {
        return;
        if (paramAnonymousContext.compareTo("com.eospy.util.ACTION_ONOFF_UPDATE") == 0)
        {
          boolean bool = paramAnonymousIntent.getBooleanExtra("com.eospy.util.EXTRA_ONOFF", false);
          GenericBluetoothProfile.this.onOffWasUpdated(bool);
          return;
        }
      } while (paramAnonymousContext.compareTo("com.eospy.util.ACTION_CALIBRATE") != 0);
      GenericBluetoothProfile.this.calibrationButtonTouched();
    }
  };
  public boolean isConfigured;
  public boolean isEnabled;
  protected boolean isRegistered;
  protected BluetoothDevice mBTDevice;
  protected BluetoothLeService mBTLeService;
  protected BluetoothGattService mBTService;
  protected BluetoothGattCharacteristic periodC;
  protected GenericCharacteristicTableRow tRow;
  
  public GenericBluetoothProfile(Context paramContext, BluetoothDevice paramBluetoothDevice, BluetoothGattService paramBluetoothGattService, BluetoothLeService paramBluetoothLeService)
  {
    this.mBTDevice = paramBluetoothDevice;
    this.mBTService = paramBluetoothGattService;
    this.mBTLeService = paramBluetoothLeService;
    this.tRow = new GenericCharacteristicTableRow(paramContext);
    this.dataC = null;
    this.periodC = null;
    this.configC = null;
    this.context = paramContext;
    this.isRegistered = false;
  }
  
  public static boolean isCorrectService(BluetoothGattService paramBluetoothGattService)
  {
    return false;
  }
  
  private static IntentFilter makeFilter()
  {
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("com.eospy.util.ACTION_PERIOD_UPDATE");
    localIntentFilter.addAction("com.eospy.util.ACTION_ONOFF_UPDATE");
    localIntentFilter.addAction("com.eospy.util.ACTION_CALIBRATE");
    return localIntentFilter;
  }
  
  protected void calibrationButtonTouched() {}
  
  public void configureService()
  {
    int i = this.mBTLeService.setCharacteristicNotification(this.dataC, true);
    if ((i != 0) && (this.dataC != null)) {
      printError("Sensor notification enable failed: ", this.dataC, i);
    }
    this.isConfigured = true;
  }
  
  public void deConfigureService()
  {
    int i = this.mBTLeService.setCharacteristicNotification(this.dataC, false);
    if ((i != 0) && (this.dataC != null)) {
      printError("Sensor notification disable failed: ", this.dataC, i);
    }
    this.isConfigured = false;
  }
  
  public void didReadValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic)
  {
    if ((this.periodC != null) && (paramBluetoothGattCharacteristic.equals(this.periodC))) {
      periodWasUpdated(paramBluetoothGattCharacteristic.getValue()[0] * 10);
    }
  }
  
  public void didUpdateFirmwareRevision(String paramString) {}
  
  public void didUpdateValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic) {}
  
  public void didWriteValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic) {}
  
  public void disableService()
  {
    int i = this.mBTLeService.writeCharacteristic(this.configC, (byte)0);
    if ((i != 0) && (this.configC != null)) {
      printError("Sensor disable failed: ", this.configC, i);
    }
    this.isConfigured = false;
  }
  
  public void enableService()
  {
    int i = this.mBTLeService.writeCharacteristic(this.configC, (byte)1);
    if ((i != 0) && (this.configC != null)) {
      printError("Sensor enable failed: ", this.configC, i);
    }
    this.isEnabled = true;
  }
  
  public String getIconPrefix()
  {
    if (this.mBTDevice.getName().equals("CC2650 SensorTag")) {
      return "sensortag2";
    }
    return "";
  }
  
  public Map<String, String> getMQTTMap()
  {
    return null;
  }
  
  public TableRow getTableRow()
  {
    return this.tRow;
  }
  
  public void grayOutCell(boolean paramBoolean)
  {
    if (paramBoolean == true)
    {
      this.tRow.setAlpha(0.4F);
      this.tRow.onOff.setChecked(false);
      return;
    }
    this.tRow.setAlpha(1.0F);
    this.tRow.onOff.setChecked(true);
  }
  
  public boolean isDataC(BluetoothGattCharacteristic paramBluetoothGattCharacteristic)
  {
    if (this.dataC == null) {}
    while (!paramBluetoothGattCharacteristic.equals(this.dataC)) {
      return false;
    }
    return true;
  }
  
  public boolean isEnabledByPrefs(String paramString)
  {
    paramString = "pref_" + paramString;
    return PreferenceManager.getDefaultSharedPreferences(this.mBTLeService).getBoolean(paramString, Boolean.valueOf(true).booleanValue());
  }
  
  public void onOffWasUpdated(boolean paramBoolean)
  {
    Log.d("GenericBluetoothProfile", "Config characteristic set to :" + paramBoolean);
    if (paramBoolean)
    {
      configureService();
      enableService();
      this.tRow.grayedOut(false);
      return;
    }
    deConfigureService();
    disableService();
    this.tRow.grayedOut(true);
  }
  
  public void onPause()
  {
    if (this.isRegistered == true)
    {
      this.context.unregisterReceiver(this.guiReceiver);
      this.isRegistered = false;
    }
  }
  
  public void onResume()
  {
    if (!this.isRegistered)
    {
      this.context.registerReceiver(this.guiReceiver, makeFilter());
      this.isRegistered = true;
    }
  }
  
  public void periodWasUpdated(int paramInt)
  {
    int i = paramInt;
    if (paramInt > 2450) {
      i = 2450;
    }
    paramInt = i;
    if (i < 100) {
      paramInt = 100;
    }
    byte b = (byte)(paramInt / 10 + 10);
    Log.d("GenericBluetoothProfile", "Period characteristic set to :" + paramInt);
    i = this.mBTLeService.writeCharacteristic(this.periodC, b);
    if ((i != 0) && (this.periodC != null)) {
      printError("Sensor period failed: ", this.periodC, i);
    }
    this.tRow.periodLegend.setText("Sensor period (currently : " + paramInt + "ms)");
  }
  
  public void printError(String paramString, BluetoothGattCharacteristic paramBluetoothGattCharacteristic, int paramInt)
  {
    try
    {
      Log.d("GenericBluetoothProfile", paramString + paramBluetoothGattCharacteristic.getUuid().toString() + " Error: " + paramInt);
      return;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\common\GenericBluetoothProfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */