package com.eospy.sensortag;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.widget.SeekBar;
import android.widget.TextView;
import com.eospy.common.BluetoothLeService;
import com.eospy.common.GenericBluetoothProfile;
import com.eospy.util.GenericCharacteristicTableRow;
import com.eospy.util.Point3D;
import com.eospy.util.SparkLineView;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SensorTagIRTemperatureProfile
  extends GenericBluetoothProfile
{
  public SensorTagIRTemperatureProfile(Context paramContext, BluetoothDevice paramBluetoothDevice, BluetoothGattService paramBluetoothGattService, BluetoothLeService paramBluetoothLeService)
  {
    super(paramContext, paramBluetoothDevice, paramBluetoothGattService, paramBluetoothLeService);
    this.tRow = new GenericCharacteristicTableRow(paramContext);
    paramContext = this.mBTService.getCharacteristics().iterator();
    while (paramContext.hasNext())
    {
      paramBluetoothDevice = (BluetoothGattCharacteristic)paramContext.next();
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_IRT_DATA.toString())) {
        this.dataC = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_IRT_CONF.toString())) {
        this.configC = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_IRT_PERI.toString())) {
        this.periodC = paramBluetoothDevice;
      }
    }
    this.tRow.sl1.autoScale = true;
    this.tRow.sl1.autoScaleBounceBack = true;
    this.tRow.setIcon(getIconPrefix(), this.dataC.getUuid().toString());
    this.tRow.title.setText("IR Temperature Data");
    this.tRow.uuidLabel.setText(this.dataC.getUuid().toString());
    this.tRow.value.setText("0.0'C");
    this.tRow.periodMinVal = 200;
    this.tRow.periodBar.setMax(255 - this.tRow.periodMinVal / 10);
    this.tRow.periodBar.setProgress(100);
  }
  
  public static boolean isCorrectService(BluetoothGattService paramBluetoothGattService)
  {
    return paramBluetoothGattService.getUuid().toString().compareTo(SensorTagGatt.UUID_IRT_SERV.toString()) == 0;
  }
  
  public void didUpdateValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic)
  {
    byte[] arrayOfByte = paramBluetoothGattCharacteristic.getValue();
    if (paramBluetoothGattCharacteristic.equals(this.dataC))
    {
      if (!this.mBTDevice.getName().equals("CC2650 SensorTag")) {
        break label151;
      }
      paramBluetoothGattCharacteristic = Sensor.IR_TEMPERATURE.convert(arrayOfByte);
      if (isEnabledByPrefs("imperial") != true) {
        break label119;
      }
      this.tRow.value.setText(String.format("%.1f'F", new Object[] { Double.valueOf(paramBluetoothGattCharacteristic.z * 1.8D + 32.0D) }));
    }
    for (;;)
    {
      this.tRow.sl1.addValue((float)paramBluetoothGattCharacteristic.z);
      com.eospy.client.PositionProvider.ir_tempSensor = (float)paramBluetoothGattCharacteristic.z * 9.0F / 5.0F + 32.0F;
      return;
      label119:
      this.tRow.value.setText(String.format("%.1f'C", new Object[] { Double.valueOf(paramBluetoothGattCharacteristic.z) }));
    }
    label151:
    paramBluetoothGattCharacteristic = Sensor.IR_TEMPERATURE.convert(arrayOfByte);
    if (!this.tRow.config)
    {
      if (isEnabledByPrefs("imperial") != true) {
        break label249;
      }
      this.tRow.value.setText(String.format("%.1f'F", new Object[] { Double.valueOf(paramBluetoothGattCharacteristic.y * 1.8D + 32.0D) }));
    }
    for (;;)
    {
      this.tRow.sl1.addValue((float)paramBluetoothGattCharacteristic.y);
      com.eospy.client.PositionProvider.ir_tempSensor = (float)paramBluetoothGattCharacteristic.y * 9.0F / 5.0F + 32.0F;
      return;
      label249:
      this.tRow.value.setText(String.format("%.1f'C", new Object[] { Double.valueOf(paramBluetoothGattCharacteristic.y) }));
    }
  }
  
  public Map<String, String> getMQTTMap()
  {
    Point3D localPoint3D = Sensor.IR_TEMPERATURE.convert(this.dataC.getValue());
    HashMap localHashMap = new HashMap();
    if (this.mBTDevice.getName().equals("CC2650 SensorTag"))
    {
      localHashMap.put("object_temp", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.z) }));
      return localHashMap;
    }
    localHashMap.put("object_temp", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.y) }));
    return localHashMap;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\SensorTagIRTemperatureProfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */