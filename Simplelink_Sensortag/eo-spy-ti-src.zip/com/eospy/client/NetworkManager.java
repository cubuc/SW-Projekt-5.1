package com.eospy.client;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

public class NetworkManager
  extends BroadcastReceiver
{
  private static final String TAG = NetworkManager.class.getSimpleName();
  private ConnectivityManager connectivityManager;
  private Context context;
  private NetworkHandler handler;
  
  public NetworkManager(Context paramContext, NetworkHandler paramNetworkHandler)
  {
    this.context = paramContext;
    this.handler = paramNetworkHandler;
    this.connectivityManager = ((ConnectivityManager)paramContext.getSystemService("connectivity"));
  }
  
  public boolean isOnline()
  {
    NetworkInfo localNetworkInfo = this.connectivityManager.getActiveNetworkInfo();
    return (localNetworkInfo != null) && (localNetworkInfo.isConnectedOrConnecting());
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    boolean bool;
    StringBuilder localStringBuilder;
    if ((paramIntent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")) && (this.handler != null))
    {
      bool = isOnline();
      paramIntent = TAG;
      localStringBuilder = new StringBuilder().append("network ");
      if (!bool) {
        break label74;
      }
    }
    label74:
    for (paramContext = "on";; paramContext = "off")
    {
      Log.i(paramIntent, paramContext);
      this.handler.onNetworkUpdate(bool);
      return;
    }
  }
  
  public void start()
  {
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
    this.context.registerReceiver(this, localIntentFilter);
  }
  
  public void stop()
  {
    this.context.unregisterReceiver(this);
  }
  
  public static abstract interface NetworkHandler
  {
    public abstract void onNetworkUpdate(boolean paramBoolean);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\NetworkManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */