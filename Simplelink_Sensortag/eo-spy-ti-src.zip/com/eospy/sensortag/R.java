package com.eospy.sensortag;

public final class R
{
  public static final class array
  {
    public static final int device_filter = 2131099648;
    public static final int settings_provider_names = 2131099649;
    public static final int settings_provider_values = 2131099650;
  }
  
  public static final class attr
  {
    public static final int circleCrop = 2130771970;
    public static final int imageAspectRatio = 2130771969;
    public static final int imageAspectRatioAdjust = 2130771968;
  }
  
  public static final class color
  {
    public static final int common_action_bar_splitter = 2131165184;
    public static final int common_signin_btn_dark_text_default = 2131165185;
    public static final int common_signin_btn_dark_text_disabled = 2131165186;
    public static final int common_signin_btn_dark_text_focused = 2131165187;
    public static final int common_signin_btn_dark_text_pressed = 2131165188;
    public static final int common_signin_btn_default_background = 2131165189;
    public static final int common_signin_btn_light_text_default = 2131165190;
    public static final int common_signin_btn_light_text_disabled = 2131165191;
    public static final int common_signin_btn_light_text_focused = 2131165192;
    public static final int common_signin_btn_light_text_pressed = 2131165193;
    public static final int common_signin_btn_text_dark = 2131165194;
    public static final int common_signin_btn_text_light = 2131165195;
  }
  
  public static final class dimen
  {
    public static final int about_margin = 2131230720;
    public static final int about_spacing = 2131230721;
  }
  
  public static final class drawable
  {
    public static final int accelerometer = 2130837504;
    public static final int accelerometer_300 = 2130837505;
    public static final int accelerometer_450 = 2130837506;
    public static final int barometer = 2130837507;
    public static final int barometer_300 = 2130837508;
    public static final int barometer_450 = 2130837509;
    public static final int bluetooth = 2130837510;
    public static final int buttonsoffoff = 2130837511;
    public static final int buttonsoffon = 2130837512;
    public static final int buttonsonoff = 2130837513;
    public static final int buttonsonon = 2130837514;
    public static final int cloud_connected = 2130837515;
    public static final int cloud_connected_tx = 2130837516;
    public static final int cloud_disconnected = 2130837517;
    public static final int common_full_open_on_phone = 2130837518;
    public static final int common_ic_googleplayservices = 2130837519;
    public static final int deviceinfo = 2130837520;
    public static final int deviceinfo_300 = 2130837521;
    public static final int deviceinfo_450 = 2130837522;
    public static final int gyroscope = 2130837523;
    public static final int gyroscope_300 = 2130837524;
    public static final int gyroscope_450 = 2130837525;
    public static final int humidity = 2130837526;
    public static final int humidity_300 = 2130837527;
    public static final int humidity_450 = 2130837528;
    public static final int ic_action_about = 2130837529;
    public static final int ic_action_bluetooth = 2130837530;
    public static final int ic_action_cancel = 2130837531;
    public static final int ic_action_refresh = 2130837532;
    public static final int ic_action_settings = 2130837533;
    public static final int irtemperature = 2130837534;
    public static final int irtemperature_300 = 2130837535;
    public static final int irtemperature_450 = 2130837536;
    public static final int leftkey_300 = 2130837537;
    public static final int leftkeyoff_300 = 2130837538;
    public static final int leftkeyon_300 = 2130837539;
    public static final int list_item_normal = 2130837540;
    public static final int logo = 2130837541;
    public static final int magnetometer = 2130837542;
    public static final int magnetometer_300 = 2130837543;
    public static final int magnetometer_450 = 2130837544;
    public static final int reed_closed = 2130837545;
    public static final int reed_open = 2130837546;
    public static final int reedrelayoff_300 = 2130837547;
    public static final int reedrelayon_300 = 2130837548;
    public static final int rightkey_300 = 2130837549;
    public static final int rightkeyoff_300 = 2130837550;
    public static final int rightkeyon_300 = 2130837551;
    public static final int sensortag = 2130837552;
    public static final int sensortag2 = 2130837553;
    public static final int sensortag2_300 = 2130837554;
    public static final int sensortag2accelerometer = 2130837555;
    public static final int sensortag2accelerometer_300 = 2130837556;
    public static final int sensortag2barometer = 2130837557;
    public static final int sensortag2barometer_300 = 2130837558;
    public static final int sensortag2ccs = 2130837559;
    public static final int sensortag2ccs_300 = 2130837560;
    public static final int sensortag2cloudservice = 2130837561;
    public static final int sensortag2cloudservice_300 = 2130837562;
    public static final int sensortag2cloudservice_450 = 2130837563;
    public static final int sensortag2deviceinfo = 2130837564;
    public static final int sensortag2deviceinfo_300 = 2130837565;
    public static final int sensortag2gyroscope = 2130837566;
    public static final int sensortag2gyroscope_300 = 2130837567;
    public static final int sensortag2humidity = 2130837568;
    public static final int sensortag2humidity_300 = 2130837569;
    public static final int sensortag2irtemperature = 2130837570;
    public static final int sensortag2irtemperature_300 = 2130837571;
    public static final int sensortag2lightsensor = 2130837572;
    public static final int sensortag2lightsensor_300 = 2130837573;
    public static final int sensortag2magnetometer = 2130837574;
    public static final int sensortag2magnetometer_300 = 2130837575;
    public static final int sensortag2motion = 2130837576;
    public static final int sensortag2motion_300 = 2130837577;
    public static final int sensortag2motion_450 = 2130837578;
    public static final int sensortag2oad = 2130837579;
    public static final int sensortag2oad_300 = 2130837580;
    public static final int sensortag2oad_450 = 2130837581;
    public static final int sensortag2rssi = 2130837582;
    public static final int sensortag2rssi_300 = 2130837583;
    public static final int sensortag2simplekeys = 2130837584;
    public static final int sensortag2simplekeys_300 = 2130837585;
    public static final int sensortag2temperature = 2130837586;
    public static final int sensortag2temperature_300 = 2130837587;
    public static final int sensortag_300 = 2130837588;
    public static final int sensortag_450 = 2130837589;
    public static final int sensortag_magnetometer = 2130837590;
    public static final int sensortag_simplekeys = 2130837591;
    public static final int simplekeys = 2130837592;
    public static final int simplekeys_300 = 2130837593;
    public static final int simplekeys_450 = 2130837594;
    public static final int st2 = 2130837595;
    public static final int temperature = 2130837596;
    public static final int temperature_300 = 2130837597;
    public static final int temperature_450 = 2130837598;
    public static final int unknown = 2130837599;
  }
  
  public static final class id
  {
    public static final int adjust_height = 2131492864;
    public static final int adjust_width = 2131492865;
    public static final int btnConnect = 2131492889;
    public static final int btn_confirm = 2131492869;
    public static final int btn_load_a = 2131492872;
    public static final int btn_load_b = 2131492873;
    public static final int btn_load_c = 2131492874;
    public static final int btn_scan = 2131492894;
    public static final int btn_start = 2131492878;
    public static final int buttonOK = 2131492882;
    public static final int descr = 2131492888;
    public static final int devImage = 2131492887;
    public static final int device_list = 2131492892;
    public static final int footer = 2131492881;
    public static final int generic_services_layout = 2131492895;
    public static final int header = 2131492880;
    public static final int info = 2131492886;
    public static final int lw_file = 2131492868;
    public static final int name = 2131492884;
    public static final int no_device = 2131492893;
    public static final int none = 2131492866;
    public static final int opt_about = 2131492900;
    public static final int opt_bt = 2131492901;
    public static final int opt_exit = 2131492902;
    public static final int opt_prefs = 2131492898;
    public static final int opt_progress = 2131492897;
    public static final int opt_status = 2131492899;
    public static final int pager = 2131492891;
    public static final int pb_progress = 2131492876;
    public static final int status = 2131492883;
    public static final int title = 2131492879;
    public static final int tw_directory = 2131492867;
    public static final int tw_file = 2131492871;
    public static final int tw_info = 2131492875;
    public static final int tw_log = 2131492877;
    public static final int tw_target = 2131492870;
    public static final int uuid = 2131492885;
    public static final int view2 = 2131492896;
    public static final int webpage = 2131492890;
  }
  
  public static final class integer
  {
    public static final int google_play_services_version = 2131296256;
  }
  
  public static final class layout
  {
    public static final int activity_file = 2130903040;
    public static final int activity_fwupdate = 2130903041;
    public static final int dialog_about = 2130903042;
    public static final int dialog_status = 2130903043;
    public static final int element_characteristic = 2130903044;
    public static final int element_device = 2130903045;
    public static final int element_file = 2130903046;
    public static final int fragment_help = 2130903047;
    public static final int fragment_pager = 2130903048;
    public static final int fragment_scan = 2130903049;
    public static final int frame_progress = 2130903050;
    public static final int generic_services_browser = 2130903051;
  }
  
  public static final class menu
  {
    public static final int device_activity_actions = 2131427328;
    public static final int main_activity_actions = 2131427329;
  }
  
  public static final class string
  {
    public static final int about = 2131034142;
    public static final int about_description = 2131034143;
    public static final int about_license = 2131034144;
    public static final int about_web = 2131034145;
    public static final int acc = 2131034146;
    public static final int app_closing = 2131034147;
    public static final int app_logo = 2131034148;
    public static final int app_name = 2131034149;
    public static final int auth_google_play_services_client_facebook_display_name = 2131034150;
    public static final int auth_google_play_services_client_google_display_name = 2131034151;
    public static final int bar = 2131034152;
    public static final int ble_not_supported = 2131034153;
    public static final int bt = 2131034154;
    public static final int bt_adapter_disable = 2131034155;
    public static final int bt_adapter_reset = 2131034156;
    public static final int bt_not_on = 2131034157;
    public static final int bt_not_supported = 2131034158;
    public static final int bt_on = 2131034159;
    public static final int btn_txt_confirm = 2131034160;
    public static final int button_scan = 2131034161;
    public static final int cancel = 2131034162;
    public static final int common_android_wear_notification_needs_update_text = 2131034112;
    public static final int common_android_wear_update_text = 2131034113;
    public static final int common_android_wear_update_title = 2131034114;
    public static final int common_google_play_services_api_unavailable_text = 2131034115;
    public static final int common_google_play_services_enable_button = 2131034116;
    public static final int common_google_play_services_enable_text = 2131034117;
    public static final int common_google_play_services_enable_title = 2131034118;
    public static final int common_google_play_services_error_notification_requested_by_msg = 2131034119;
    public static final int common_google_play_services_install_button = 2131034120;
    public static final int common_google_play_services_install_text_phone = 2131034121;
    public static final int common_google_play_services_install_text_tablet = 2131034122;
    public static final int common_google_play_services_install_title = 2131034123;
    public static final int common_google_play_services_invalid_account_text = 2131034124;
    public static final int common_google_play_services_invalid_account_title = 2131034125;
    public static final int common_google_play_services_needs_enabling_title = 2131034126;
    public static final int common_google_play_services_network_error_text = 2131034127;
    public static final int common_google_play_services_network_error_title = 2131034128;
    public static final int common_google_play_services_notification_needs_update_title = 2131034129;
    public static final int common_google_play_services_notification_ticker = 2131034130;
    public static final int common_google_play_services_sign_in_failed_text = 2131034131;
    public static final int common_google_play_services_sign_in_failed_title = 2131034132;
    public static final int common_google_play_services_unknown_issue = 2131034133;
    public static final int common_google_play_services_unsupported_text = 2131034134;
    public static final int common_google_play_services_unsupported_title = 2131034135;
    public static final int common_google_play_services_update_button = 2131034136;
    public static final int common_google_play_services_update_text = 2131034137;
    public static final int common_google_play_services_update_title = 2131034138;
    public static final int common_google_play_services_updating_text = 2131034139;
    public static final int common_google_play_services_updating_title = 2131034140;
    public static final int common_open_on_phone = 2131034141;
    public static final int connect = 2131034163;
    public static final int control = 2131034164;
    public static final int cur_image = 2131034165;
    public static final int dev_addr = 2131034166;
    public static final int device = 2131034167;
    public static final int disconnected = 2131034168;
    public static final int discovering_services = 2131034169;
    public static final int empty1 = 2131034170;
    public static final int empty3 = 2131034171;
    public static final int eospyweb = 2131034172;
    public static final int exit = 2131034173;
    public static final int gyro = 2131034174;
    public static final int header = 2131034175;
    public static final int hum = 2131034176;
    public static final int idle = 2131034177;
    public static final int image = 2131034178;
    public static final int keys = 2131034179;
    public static final int load_image_a = 2131034180;
    public static final int load_image_b = 2131034181;
    public static final int load_image_c = 2131034182;
    public static final int lux = 2131034183;
    public static final int mag = 2131034184;
    public static final int new_image = 2131034185;
    public static final int no_image = 2131034186;
    public static final int no_image_sel = 2131034187;
    public static final int nodevice = 2131034188;
    public static final int prefs = 2131034189;
    public static final int progress = 2131034190;
    public static final int progress_info = 2131034191;
    public static final int progress_title = 2131034192;
    public static final int scan_advice = 2131034193;
    public static final int sensor_name = 2131034194;
    public static final int settings_address_summary = 2131034195;
    public static final int settings_address_title = 2131034196;
    public static final int settings_foreground_summary = 2131034197;
    public static final int settings_foreground_title = 2131034198;
    public static final int settings_id_title = 2131034199;
    public static final int settings_interval_summary = 2131034200;
    public static final int settings_interval_title = 2131034201;
    public static final int settings_port_summary = 2131034202;
    public static final int settings_port_title = 2131034203;
    public static final int settings_provider_gps = 2131034204;
    public static final int settings_provider_mixed = 2131034205;
    public static final int settings_provider_network = 2131034206;
    public static final int settings_provider_summary = 2131034207;
    public static final int settings_provider_title = 2131034208;
    public static final int settings_secure_off = 2131034209;
    public static final int settings_secure_off_summary = 2131034210;
    public static final int settings_secure_on = 2131034211;
    public static final int settings_secure_on_summary = 2131034212;
    public static final int settings_secure_title = 2131034213;
    public static final int settings_status_off = 2131034214;
    public static final int settings_status_off_summary = 2131034215;
    public static final int settings_status_on = 2131034216;
    public static final int settings_status_on_summary = 2131034217;
    public static final int settings_status_title = 2131034218;
    public static final int shortcut_sos = 2131034219;
    public static final int shortcut_start = 2131034220;
    public static final int shortcut_stop = 2131034221;
    public static final int start_prog = 2131034222;
    public static final int status = 2131034223;
    public static final int status_connectivity_change = 2131034224;
    public static final int status_location_update = 2131034225;
    public static final int status_send_fail = 2131034226;
    public static final int status_send_success = 2131034227;
    public static final int status_service_create = 2131034228;
    public static final int status_service_destroy = 2131034229;
    public static final int tAmb = 2131034230;
    public static final int tObj = 2131034231;
    public static final int title_device_list = 2131034232;
    public static final int unitDeg = 2131034233;
    public static final int unitDegSec3 = 2131034234;
    public static final int unitG3 = 2131034235;
    public static final int unitLux = 2131034236;
    public static final int unitPA_Meter = 2131034237;
    public static final int unitRH = 2131034238;
    public static final int unitT3 = 2131034239;
    public static final int xyz3 = 2131034240;
  }
  
  public static final class style
  {
    public static final int AppBaseTheme = 2131361792;
    public static final int AppTheme = 2131361793;
    public static final int ServiceHeaderItem = 2131361794;
    public static final int ServiceHeaderRow = 2131361795;
    public static final int ServiceItem = 2131361796;
    public static final int ServiceItemValue = 2131361797;
    public static final int ServiceRow = 2131361798;
    public static final int aboutStyle = 2131361799;
    public static final int dataStyle = 2131361800;
    public static final int dataStyle1 = 2131361801;
    public static final int dataStyle2 = 2131361802;
    public static final int devlistStyle = 2131361803;
    public static final int dirStyle = 2131361804;
    public static final int infoStyle = 2131361805;
    public static final int listItemStyle = 2131361806;
    public static final int logStyle = 2131361807;
    public static final int nameStyle = 2131361808;
    public static final int nameStyleSelected = 2131361810;
    public static final int nameStyle_inactive = 2131361809;
    public static final int statusStyle = 2131361811;
    public static final int statusStyleSmall = 2131361816;
    public static final int statusStyle_Busy = 2131361812;
    public static final int statusStyle_Disabled = 2131361813;
    public static final int statusStyle_Failure = 2131361814;
    public static final int statusStyle_Success = 2131361815;
    public static final int tabwidgetStyle = 2131361817;
    public static final int tbStartStyle = 2131361818;
  }
  
  public static final class styleable
  {
    public static final int[] LoadingImageView = { 2130771968, 2130771969, 2130771970 };
    public static final int LoadingImageView_circleCrop = 2;
    public static final int LoadingImageView_imageAspectRatio = 1;
    public static final int LoadingImageView_imageAspectRatioAdjust = 0;
  }
  
  public static final class xml
  {
    public static final int gatt_uuid = 2130968576;
    public static final int list_gradient = 2130968577;
    public static final int popup = 2130968578;
    public static final int preferences = 2130968579;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */