package com.eospy.client;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Toast;

public class ShortcutActivity
  extends Activity
{
  private static final String ALARM_SOS = "sos";
  public static final String EXTRA_ACTION = "action";
  public static final String EXTRA_ACTION_SOS = "sos";
  public static final String EXTRA_ACTION_START = "start";
  public static final String EXTRA_ACTION_STOP = "stop";
  
  private void checkShortcutAction(Intent paramIntent)
  {
    int i;
    if (paramIntent.hasExtra("shortcutAction")) {
      if (paramIntent.getBooleanExtra("shortcutAction", false))
      {
        paramIntent = "start";
        i = -1;
        switch (paramIntent.hashCode())
        {
        default: 
          label64:
          switch (i)
          {
          }
          break;
        }
      }
    }
    for (;;)
    {
      finish();
      return;
      paramIntent = "stop";
      break;
      paramIntent = paramIntent.getStringExtra("action");
      break;
      if (!paramIntent.equals("start")) {
        break label64;
      }
      i = 0;
      break label64;
      if (!paramIntent.equals("stop")) {
        break label64;
      }
      i = 1;
      break label64;
      if (!paramIntent.equals("sos")) {
        break label64;
      }
      i = 2;
      break label64;
      PreferenceManager.getDefaultSharedPreferences(this).edit().putBoolean("status", true).commit();
      startService(new Intent(this, TrackingService.class));
      Toast.makeText(this, 2131034228, 0).show();
      continue;
      PreferenceManager.getDefaultSharedPreferences(this).edit().putBoolean("status", false).commit();
      stopService(new Intent(this, TrackingService.class));
      Toast.makeText(this, 2131034229, 0).show();
      continue;
      sendAlarm();
    }
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    checkShortcutAction(getIntent());
  }
  
  protected void onNewIntent(Intent paramIntent)
  {
    super.onNewIntent(paramIntent);
    checkShortcutAction(paramIntent);
  }
  
  public void sendAlarm()
  {
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
    LocationManager localLocationManager = (LocationManager)getSystemService("location");
    Location localLocation = localLocationManager.getLastKnownLocation("gps");
    Object localObject = localLocation;
    if (localLocation == null) {
      localObject = localLocationManager.getLastKnownLocation("network");
    }
    if (localObject != null)
    {
      localObject = new Position(localSharedPreferences.getString("id", null), (Location)localObject, PositionProvider.getBatteryLevel(this), 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
      RequestManager.sendRequestAsync(ProtocolFormatter.formatRequest(localSharedPreferences.getString("address", null), Integer.parseInt(localSharedPreferences.getString("port", null)), localSharedPreferences.getBoolean("secure", false), (Position)localObject, "sos"), new RequestManager.RequestHandler()
      {
        public void onComplete(boolean paramAnonymousBoolean)
        {
          if (paramAnonymousBoolean)
          {
            Toast.makeText(ShortcutActivity.this, 2131034227, 0).show();
            return;
          }
          Toast.makeText(ShortcutActivity.this, 2131034226, 0).show();
        }
      });
      return;
    }
    Toast.makeText(this, 2131034226, 0).show();
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\ShortcutActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */