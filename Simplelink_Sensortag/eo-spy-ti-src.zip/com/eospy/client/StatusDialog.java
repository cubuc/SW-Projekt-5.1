package com.eospy.client;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

public class StatusDialog
  extends Dialog
{
  private static final int LIMIT = 20;
  private static final Set<ArrayAdapter<String>> adapters = new HashSet();
  private static StatusDialog mDialog;
  private static OkListener mOkListener;
  private static final LinkedList<String> messages = new LinkedList();
  private String statusMessage = "";
  
  public StatusDialog(Context paramContext)
  {
    super(paramContext);
    mDialog = this;
    mOkListener = new OkListener(null);
  }
  
  public static void addMessage(String paramString)
  {
    DateFormat localDateFormat = DateFormat.getTimeInstance(3);
    paramString = localDateFormat.format(new Date()) + " - " + paramString;
    messages.add(paramString);
    while (messages.size() > 20) {
      messages.removeFirst();
    }
    notifyAdapters();
  }
  
  private static void notifyAdapters()
  {
    Iterator localIterator = adapters.iterator();
    while (localIterator.hasNext()) {
      ((ArrayAdapter)localIterator.next()).notifyDataSetChanged();
    }
  }
  
  public void clearMessages()
  {
    messages.clear();
    notifyAdapters();
  }
  
  public void onCreate(Bundle paramBundle)
  {
    requestWindowFeature(1);
    setContentView(2130903043);
    if (messages.size() == 0) {
      addMessage("Service not started");
    }
    int i = 0;
    while (i < messages.size())
    {
      this.statusMessage = (this.statusMessage + (String)messages.get(i) + "\n");
      i += 1;
    }
    ((TextView)findViewById(2131492883)).setText(this.statusMessage);
    ((Button)findViewById(2131492882)).setOnClickListener(mOkListener);
  }
  
  private class OkListener
    implements View.OnClickListener
  {
    private OkListener() {}
    
    public void onClick(View paramView)
    {
      StatusDialog.mDialog.dismiss();
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\StatusDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */