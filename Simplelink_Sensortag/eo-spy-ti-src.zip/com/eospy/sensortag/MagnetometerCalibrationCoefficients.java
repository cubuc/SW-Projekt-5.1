package com.eospy.sensortag;

import com.eospy.util.Point3D;

public enum MagnetometerCalibrationCoefficients
{
  INSTANCE;
  
  Point3D val = new Point3D(0.0D, 0.0D, 0.0D);
  
  private MagnetometerCalibrationCoefficients() {}
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\MagnetometerCalibrationCoefficients.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */