package com.google.android.gms.appindexing;

import com.google.android.gms.appdatasearch.zza;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.internal.zzju;

public final class AppIndex
{
  public static final Api<Api.ApiOptions.NoOptions> API = zza.zzPV;
  public static final Api<Api.ApiOptions.NoOptions> APP_INDEX_API = zza.zzPV;
  public static final AppIndexApi AppIndexApi = new zzju();
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\google\android\gms\appindexing\AppIndex.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */