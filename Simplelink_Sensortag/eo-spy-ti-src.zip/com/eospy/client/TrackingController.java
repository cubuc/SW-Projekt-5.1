package com.eospy.client;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.preference.PreferenceManager;
import android.util.Log;
import java.util.Date;

public class TrackingController
  implements PositionProvider.PositionListener, NetworkManager.NetworkHandler
{
  private static final int RETRY_DELAY = 30000;
  private static final String TAG = TrackingController.class.getSimpleName();
  private static final int WAKE_LOCK_TIMEOUT = 120000;
  private String address;
  private Context context;
  private DatabaseHelper databaseHelper;
  private Handler handler;
  private boolean isOnline;
  private boolean isWaiting;
  private NetworkManager networkManager;
  private int port;
  private PositionProvider positionProvider;
  private SharedPreferences preferences;
  private boolean secure;
  private PowerManager.WakeLock wakeLock;
  
  public TrackingController(Context paramContext)
  {
    this.context = paramContext;
    this.handler = new Handler();
    this.preferences = PreferenceManager.getDefaultSharedPreferences(paramContext);
    if (this.preferences.getString("provider", "gps").equals("mixed")) {}
    for (this.positionProvider = new MixedPositionProvider(paramContext, this);; this.positionProvider = new SimplePositionProvider(paramContext, this))
    {
      this.databaseHelper = new DatabaseHelper(paramContext);
      this.networkManager = new NetworkManager(paramContext, this);
      this.isOnline = this.networkManager.isOnline();
      this.address = this.preferences.getString("address", null);
      this.port = Integer.parseInt(this.preferences.getString("port", null));
      this.secure = this.preferences.getBoolean("secure", false);
      this.wakeLock = ((PowerManager)paramContext.getSystemService("power")).newWakeLock(1, getClass().getName());
      return;
    }
  }
  
  private void delete(Position paramPosition)
  {
    log("delete", paramPosition);
    lock();
    this.databaseHelper.deletePositionAsync(paramPosition.getId(), new DatabaseHelper.DatabaseHandler()
    {
      public void onComplete(boolean paramAnonymousBoolean, Void paramAnonymousVoid)
      {
        if (paramAnonymousBoolean) {
          TrackingController.this.read();
        }
        for (;;)
        {
          TrackingController.this.unlock();
          return;
          TrackingController.this.retry();
        }
      }
    });
  }
  
  private void lock()
  {
    if (Build.VERSION.SDK_INT <= 10)
    {
      this.wakeLock.acquire();
      return;
    }
    this.wakeLock.acquire(120000L);
  }
  
  private void log(String paramString, Position paramPosition)
  {
    String str = paramString;
    if (paramPosition != null) {
      str = paramString + " (id:" + paramPosition.getId() + " time:" + paramPosition.getTime().getTime() / 1000L + " lat:" + paramPosition.getLatitude() + " lon:" + paramPosition.getLongitude() + ")";
    }
    Log.d(TAG, str);
  }
  
  private void read()
  {
    log("read", null);
    lock();
    this.databaseHelper.selectPositionAsync(new DatabaseHelper.DatabaseHandler()
    {
      public void onComplete(boolean paramAnonymousBoolean, Position paramAnonymousPosition)
      {
        if (paramAnonymousBoolean) {
          if (paramAnonymousPosition != null) {
            if (paramAnonymousPosition.getDeviceId().equals(TrackingController.this.preferences.getString("id", null))) {
              TrackingController.this.send(paramAnonymousPosition);
            }
          }
        }
        for (;;)
        {
          TrackingController.this.unlock();
          return;
          TrackingController.this.delete(paramAnonymousPosition);
          continue;
          TrackingController.access$102(TrackingController.this, true);
          continue;
          TrackingController.this.retry();
        }
      }
    });
  }
  
  private void retry()
  {
    log("retry", null);
    this.handler.postDelayed(new Runnable()
    {
      public void run()
      {
        if (TrackingController.this.isOnline) {
          TrackingController.this.read();
        }
      }
    }, 30000L);
  }
  
  private void send(final Position paramPosition)
  {
    log("send", paramPosition);
    lock();
    RequestManager.sendRequestAsync(ProtocolFormatter.formatRequest(this.address, this.port, this.secure, paramPosition), new RequestManager.RequestHandler()
    {
      public void onComplete(boolean paramAnonymousBoolean)
      {
        if (paramAnonymousBoolean) {
          TrackingController.this.delete(paramPosition);
        }
        for (;;)
        {
          TrackingController.this.unlock();
          return;
          StatusDialog.addMessage(TrackingController.this.context.getString(2131034226));
          TrackingController.this.retry();
        }
      }
    });
  }
  
  private void unlock()
  {
    if (this.wakeLock.isHeld()) {
      this.wakeLock.release();
    }
  }
  
  private void write(Position paramPosition)
  {
    log("write", paramPosition);
    lock();
    this.databaseHelper.insertPositionAsync(paramPosition, new DatabaseHelper.DatabaseHandler()
    {
      public void onComplete(boolean paramAnonymousBoolean, Void paramAnonymousVoid)
      {
        if ((paramAnonymousBoolean) && (TrackingController.this.isOnline) && (TrackingController.this.isWaiting))
        {
          TrackingController.this.read();
          TrackingController.access$102(TrackingController.this, false);
        }
        TrackingController.this.unlock();
      }
    });
  }
  
  public void onNetworkUpdate(boolean paramBoolean)
  {
    StatusDialog.addMessage(this.context.getString(2131034224));
    if ((!this.isOnline) && (paramBoolean)) {
      read();
    }
    this.isOnline = paramBoolean;
  }
  
  public void onPositionUpdate(Position paramPosition)
  {
    StatusDialog.addMessage(this.context.getString(2131034225));
    if (paramPosition != null) {
      write(paramPosition);
    }
  }
  
  public void start()
  {
    if (this.isOnline) {
      read();
    }
    try
    {
      this.positionProvider.startUpdates();
      this.networkManager.start();
      return;
    }
    catch (SecurityException localSecurityException)
    {
      for (;;)
      {
        Log.w(TAG, localSecurityException);
      }
    }
  }
  
  public void stop()
  {
    this.networkManager.stop();
    try
    {
      this.positionProvider.stopUpdates();
      this.handler.removeCallbacksAndMessages(null);
      return;
    }
    catch (SecurityException localSecurityException)
    {
      for (;;)
      {
        Log.w(TAG, localSecurityException);
      }
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\TrackingController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */