package com.eospy.sensortag;

import android.app.Dialog;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class AboutDialog
  extends Dialog
{
  private static AboutDialog mDialog;
  private static OkListener mOkListener;
  private Context mContext;
  
  public AboutDialog(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    mDialog = this;
    mOkListener = new OkListener(null);
  }
  
  public void onCreate(Bundle paramBundle)
  {
    requestWindowFeature(1);
    setContentView(2130903042);
    paramBundle = this.mContext.getResources().getString(2131034149);
    ((TextView)findViewById(2131492879)).setText("Executive Order " + paramBundle);
    TextView localTextView = (TextView)findViewById(2131492880);
    paramBundle = "Revision: ";
    try
    {
      String str = "Revision: " + this.mContext.getPackageManager().getPackageInfo(this.mContext.getPackageName(), 0).versionName;
      paramBundle = str;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      for (;;) {}
    }
    localTextView.setText(paramBundle);
    ((Button)findViewById(2131492882)).setOnClickListener(mOkListener);
    ((TextView)findViewById(2131492881)).setText(Build.MANUFACTURER.toUpperCase() + " " + Build.MODEL + " Android " + Build.VERSION.RELEASE + " " + Build.DISPLAY);
  }
  
  private class OkListener
    implements View.OnClickListener
  {
    private OkListener() {}
    
    public void onClick(View paramView)
    {
      AboutDialog.mDialog.dismiss();
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\AboutDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */