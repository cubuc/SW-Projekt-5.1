package com.eospy.sensortag;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.util.Log;
import java.util.Locale;
import java.util.Random;

public class PreferencesFragment
  extends PreferenceFragment
{
  private static final String TAG = "PreferencesFragment";
  private PreferencesListener preferencesListener;
  private SharedPreferences prefs;
  
  private void initPreferences()
  {
    PreferenceManager.setDefaultValues(getActivity(), 2130968579, false);
    if (!this.prefs.contains("id"))
    {
      String str = String.valueOf(new Random().nextInt(900000) + 100000);
      this.prefs.edit().putString("id", str).commit();
      ((EditTextPreference)findPreference("id")).setText(str);
    }
    findPreference("id").setSummary(this.prefs.getString("id", null));
  }
  
  public boolean isEnabledByPrefs(Sensor paramSensor)
  {
    paramSensor = "pref_" + paramSensor.name().toLowerCase(Locale.ENGLISH) + "_on";
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
    if (!localSharedPreferences.contains(paramSensor)) {
      return false;
    }
    return localSharedPreferences.getBoolean(paramSensor, true);
  }
  
  public void onCreate(Bundle paramBundle)
  {
    Log.i("PreferencesFragment", "created");
    super.onCreate(paramBundle);
    addPreferencesFromResource(2130968579);
    this.prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
    this.preferencesListener = new PreferencesListener(getActivity(), this.prefs, this);
    this.prefs.registerOnSharedPreferenceChangeListener(this.preferencesListener);
    initPreferences();
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\PreferencesFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */