package com.eospy.btsig.profiles;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.content.Intent;
import android.widget.TableRow;
import android.widget.TextView;
import com.eospy.common.BluetoothLeService;
import com.eospy.common.GenericBluetoothProfile;
import com.eospy.util.SparkLineView;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

public class DeviceInformationServiceProfile
  extends GenericBluetoothProfile
{
  public static final String ACTION_FW_REV_UPDATED = "com.eospy.ble.btsig.ACTION_FW_REV_UPDATED";
  public static final String EXTRA_FW_REV_STRING = "com.eospy.ble.btsig.EXTRA_FW_REV_STRING";
  private static final String dISFirmwareREV_UUID = "00002a26-0000-1000-8000-00805f9b34fb";
  private static final String dISHardwareREV_UUID = "00002a27-0000-1000-8000-00805f9b34fb";
  private static final String dISManifacturerNAME_UUID = "00002a29-0000-1000-8000-00805f9b34fb";
  private static final String dISModelNR_UUID = "00002a24-0000-1000-8000-00805f9b34fb";
  private static final String dISSerialNR_UUID = "00002a25-0000-1000-8000-00805f9b34fb";
  private static final String dISService_UUID = "0000180a-0000-1000-8000-00805f9b34fb";
  private static final String dISSoftwareREV_UUID = "00002a28-0000-1000-8000-00805f9b34fb";
  private static final String dISSystemID_UUID = "00002a23-0000-1000-8000-00805f9b34fb";
  BluetoothGattCharacteristic ManifacturerNAMEc;
  BluetoothGattCharacteristic firmwareREVc;
  BluetoothGattCharacteristic hardwareREVc;
  BluetoothGattCharacteristic modelNRc;
  BluetoothGattCharacteristic serialNRc;
  BluetoothGattCharacteristic softwareREVc;
  BluetoothGattCharacteristic systemIDc;
  DeviceInformationServiceTableRow tRow;
  
  public DeviceInformationServiceProfile(Context paramContext, BluetoothDevice paramBluetoothDevice, BluetoothGattService paramBluetoothGattService, BluetoothLeService paramBluetoothLeService)
  {
    super(paramContext, paramBluetoothDevice, paramBluetoothGattService, paramBluetoothLeService);
    this.tRow = new DeviceInformationServiceTableRow(paramContext);
    paramContext = this.mBTService.getCharacteristics().iterator();
    while (paramContext.hasNext())
    {
      paramBluetoothDevice = (BluetoothGattCharacteristic)paramContext.next();
      if (paramBluetoothDevice.getUuid().toString().equals("00002a23-0000-1000-8000-00805f9b34fb")) {
        this.systemIDc = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals("00002a24-0000-1000-8000-00805f9b34fb")) {
        this.modelNRc = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals("00002a25-0000-1000-8000-00805f9b34fb")) {
        this.serialNRc = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals("00002a26-0000-1000-8000-00805f9b34fb")) {
        this.firmwareREVc = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals("00002a27-0000-1000-8000-00805f9b34fb")) {
        this.hardwareREVc = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals("00002a28-0000-1000-8000-00805f9b34fb")) {
        this.softwareREVc = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals("00002a29-0000-1000-8000-00805f9b34fb")) {
        this.ManifacturerNAMEc = paramBluetoothDevice;
      }
    }
    this.tRow.title.setText("Device Information Service");
    this.tRow.sl1.setVisibility(4);
    this.tRow.setIcon(getIconPrefix(), paramBluetoothGattService.getUuid().toString());
  }
  
  public static boolean isCorrectService(BluetoothGattService paramBluetoothGattService)
  {
    return paramBluetoothGattService.getUuid().toString().compareTo("0000180a-0000-1000-8000-00805f9b34fb") == 0;
  }
  
  public void configureService() {}
  
  public void deConfigureService() {}
  
  public void didReadValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic)
  {
    String str;
    Object localObject;
    if ((this.systemIDc != null) && (paramBluetoothGattCharacteristic.equals(this.systemIDc)))
    {
      str = "System ID: ";
      localObject = paramBluetoothGattCharacteristic.getValue();
      int j = localObject.length;
      int i = 0;
      while (i < j)
      {
        byte b = localObject[i];
        str = str + String.format("%02x:", new Object[] { Byte.valueOf(b) });
        i += 1;
      }
      this.tRow.SystemIDLabel.setText(str);
    }
    if ((this.modelNRc != null) && (paramBluetoothGattCharacteristic.equals(this.modelNRc))) {}
    try
    {
      this.tRow.ModelNRLabel.setText("Model NR: " + new String(paramBluetoothGattCharacteristic.getValue(), "UTF-8"));
      if ((this.serialNRc == null) || (!paramBluetoothGattCharacteristic.equals(this.serialNRc))) {}
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException4)
    {
      try
      {
        this.tRow.SerialNRLabel.setText("Serial NR: " + new String(paramBluetoothGattCharacteristic.getValue(), "UTF-8"));
        if ((this.firmwareREVc == null) || (!paramBluetoothGattCharacteristic.equals(this.firmwareREVc))) {}
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException4)
      {
        try
        {
          str = new String(paramBluetoothGattCharacteristic.getValue(), "UTF-8");
          this.tRow.FirmwareREVLabel.setText("Firmware Revision: " + str);
          localObject = new Intent("com.eospy.ble.btsig.ACTION_FW_REV_UPDATED");
          ((Intent)localObject).putExtra("com.eospy.ble.btsig.EXTRA_FW_REV_STRING", str);
          this.context.sendBroadcast((Intent)localObject);
          if ((this.hardwareREVc == null) || (!paramBluetoothGattCharacteristic.equals(this.hardwareREVc))) {}
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException4)
        {
          try
          {
            this.tRow.HardwareREVLabel.setText("Hardware Revision: " + new String(paramBluetoothGattCharacteristic.getValue(), "UTF-8"));
            if ((this.softwareREVc == null) || (!paramBluetoothGattCharacteristic.equals(this.softwareREVc))) {}
          }
          catch (UnsupportedEncodingException localUnsupportedEncodingException4)
          {
            try
            {
              for (;;)
              {
                this.tRow.SoftwareREVLabel.setText("Software Revision: " + new String(paramBluetoothGattCharacteristic.getValue(), "UTF-8"));
                if ((this.ManifacturerNAMEc != null) && (paramBluetoothGattCharacteristic.equals(this.ManifacturerNAMEc))) {}
                try
                {
                  this.tRow.ManifacturerNAMELabel.setText("Manifacturer Name: " + new String(paramBluetoothGattCharacteristic.getValue(), "UTF-8"));
                  return;
                }
                catch (UnsupportedEncodingException paramBluetoothGattCharacteristic)
                {
                  paramBluetoothGattCharacteristic.printStackTrace();
                }
                localUnsupportedEncodingException1 = localUnsupportedEncodingException1;
                localUnsupportedEncodingException1.printStackTrace();
                continue;
                localUnsupportedEncodingException2 = localUnsupportedEncodingException2;
                localUnsupportedEncodingException2.printStackTrace();
                continue;
                localUnsupportedEncodingException3 = localUnsupportedEncodingException3;
                localUnsupportedEncodingException3.printStackTrace();
              }
              localUnsupportedEncodingException4 = localUnsupportedEncodingException4;
              localUnsupportedEncodingException4.printStackTrace();
            }
            catch (UnsupportedEncodingException localUnsupportedEncodingException5)
            {
              for (;;)
              {
                localUnsupportedEncodingException5.printStackTrace();
              }
            }
          }
        }
      }
    }
  }
  
  public void didUpdateValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic) {}
  
  public void didWriteValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic) {}
  
  public void disableService() {}
  
  public void enableService()
  {
    this.mBTLeService.readCharacteristic(this.systemIDc);
    this.mBTLeService.waitIdle(250);
    this.mBTLeService.readCharacteristic(this.modelNRc);
    this.mBTLeService.waitIdle(250);
    this.mBTLeService.readCharacteristic(this.serialNRc);
    this.mBTLeService.waitIdle(250);
    this.mBTLeService.readCharacteristic(this.firmwareREVc);
    this.mBTLeService.waitIdle(250);
    this.mBTLeService.readCharacteristic(this.hardwareREVc);
    this.mBTLeService.waitIdle(250);
    this.mBTLeService.readCharacteristic(this.softwareREVc);
    this.mBTLeService.waitIdle(250);
    this.mBTLeService.readCharacteristic(this.ManifacturerNAMEc);
  }
  
  public String getIconPrefix()
  {
    if (this.mBTDevice.getName().equals("CC2650 SensorTag")) {
      return "sensortag2";
    }
    return "";
  }
  
  public TableRow getTableRow()
  {
    return this.tRow;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\btsig\profiles\DeviceInformationServiceProfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */