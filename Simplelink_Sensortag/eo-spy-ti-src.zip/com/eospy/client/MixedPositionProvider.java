package com.eospy.client;

import android.content.Context;
import android.location.GpsStatus.Listener;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

public class MixedPositionProvider
  extends PositionProvider
  implements LocationListener, GpsStatus.Listener
{
  private static int FIX_TIMEOUT = 30000;
  private LocationListener backupListener;
  private long lastFixTime;
  
  public MixedPositionProvider(Context paramContext, PositionProvider.PositionListener paramPositionListener)
  {
    super(paramContext, paramPositionListener);
  }
  
  private void startBackupProvider()
  {
    Log.i(TAG, "backup provider start");
    if (this.backupListener == null)
    {
      this.backupListener = new LocationListener()
      {
        public void onLocationChanged(Location paramAnonymousLocation)
        {
          Log.i(PositionProvider.TAG, "backup provider location");
          MixedPositionProvider.this.updateLocation(paramAnonymousLocation);
        }
        
        public void onProviderDisabled(String paramAnonymousString) {}
        
        public void onProviderEnabled(String paramAnonymousString) {}
        
        public void onStatusChanged(String paramAnonymousString, int paramAnonymousInt, Bundle paramAnonymousBundle) {}
      };
      this.locationManager.requestLocationUpdates("network", this.period, 0.0F, this.backupListener);
    }
  }
  
  private void stopBackupProvider()
  {
    Log.i(TAG, "backup provider stop");
    if (this.backupListener != null)
    {
      this.locationManager.removeUpdates(this.backupListener);
      this.backupListener = null;
    }
  }
  
  public void onGpsStatusChanged(int paramInt)
  {
    if ((this.backupListener == null) && (System.currentTimeMillis() - (this.lastFixTime + this.period) > FIX_TIMEOUT)) {
      startBackupProvider();
    }
  }
  
  public void onLocationChanged(Location paramLocation)
  {
    Log.i(TAG, "provider location");
    stopBackupProvider();
    this.lastFixTime = System.currentTimeMillis();
    updateLocation(paramLocation);
  }
  
  public void onProviderDisabled(String paramString)
  {
    Log.i(TAG, "provider disabled");
    startBackupProvider();
  }
  
  public void onProviderEnabled(String paramString)
  {
    Log.i(TAG, "provider enabled");
    stopBackupProvider();
  }
  
  public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle) {}
  
  public void startUpdates()
  {
    this.lastFixTime = System.currentTimeMillis();
    this.locationManager.addGpsStatusListener(this);
    try
    {
      this.locationManager.requestLocationUpdates("gps", this.period, 0.0F, this);
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      Log.w(TAG, localIllegalArgumentException);
    }
  }
  
  public void stopUpdates()
  {
    this.locationManager.removeUpdates(this);
    this.locationManager.removeGpsStatusListener(this);
    stopBackupProvider();
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\MixedPositionProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */