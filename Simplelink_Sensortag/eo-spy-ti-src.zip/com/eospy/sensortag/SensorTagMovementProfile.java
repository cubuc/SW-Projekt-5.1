package com.eospy.sensortag;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.util.Log;
import android.widget.SeekBar;
import android.widget.TextView;
import com.eospy.common.BluetoothLeService;
import com.eospy.common.GattInfo;
import com.eospy.common.GenericBluetoothProfile;
import com.eospy.util.GenericCharacteristicTableRow;
import com.eospy.util.Point3D;
import com.eospy.util.SparkLineView;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SensorTagMovementProfile
  extends GenericBluetoothProfile
{
  public SensorTagMovementProfile(Context paramContext, BluetoothDevice paramBluetoothDevice, BluetoothGattService paramBluetoothGattService, BluetoothLeService paramBluetoothLeService)
  {
    super(paramContext, paramBluetoothDevice, paramBluetoothGattService, paramBluetoothLeService);
    this.tRow = new SensorTagMovementTableRow(paramContext);
    paramContext = this.mBTService.getCharacteristics().iterator();
    while (paramContext.hasNext())
    {
      paramBluetoothDevice = (BluetoothGattCharacteristic)paramContext.next();
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_MOV_DATA.toString())) {
        this.dataC = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_MOV_CONF.toString())) {
        this.configC = paramBluetoothDevice;
      }
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_MOV_PERI.toString())) {
        this.periodC = paramBluetoothDevice;
      }
    }
    this.tRow.setIcon(getIconPrefix(), this.dataC.getUuid().toString());
    this.tRow.title.setText(GattInfo.uuidToName(UUID.fromString(this.dataC.getUuid().toString())));
    this.tRow.uuidLabel.setText(this.dataC.getUuid().toString());
    this.tRow.value.setText("X:0.00G, Y:0.00G, Z:0.00G");
    paramContext = (SensorTagMovementTableRow)this.tRow;
    paramContext.gyroValue.setText("X:0.00'/s, Y:0.00'/s, Z:0.00'/s");
    paramContext.magValue.setText("X:0.00mT, Y:0.00mT, Z:0.00mT");
    this.tRow.periodBar.setProgress(100);
  }
  
  public static boolean isCorrectService(BluetoothGattService paramBluetoothGattService)
  {
    return paramBluetoothGattService.getUuid().toString().compareTo(SensorTagGatt.UUID_MOV_SERV.toString()) == 0;
  }
  
  public void didReadValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic) {}
  
  public void didUpdateValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic)
  {
    Object localObject = paramBluetoothGattCharacteristic.getValue();
    if (paramBluetoothGattCharacteristic.equals(this.dataC))
    {
      paramBluetoothGattCharacteristic = Sensor.MOVEMENT_ACC.convert((byte[])localObject);
      if (!this.tRow.config) {
        this.tRow.value.setText(String.format("X:%.2fG, Y:%.2fG, Z:%.2fG", new Object[] { Double.valueOf(paramBluetoothGattCharacteristic.x), Double.valueOf(paramBluetoothGattCharacteristic.y), Double.valueOf(paramBluetoothGattCharacteristic.z) }));
      }
      this.tRow.sl1.addValue((float)paramBluetoothGattCharacteristic.x);
      this.tRow.sl2.addValue((float)paramBluetoothGattCharacteristic.y);
      this.tRow.sl3.addValue((float)paramBluetoothGattCharacteristic.z);
      com.eospy.client.PositionProvider.accel_xSensor = (float)paramBluetoothGattCharacteristic.x;
      com.eospy.client.PositionProvider.accel_ySensor = (float)paramBluetoothGattCharacteristic.y;
      com.eospy.client.PositionProvider.accel_zSensor = (float)paramBluetoothGattCharacteristic.z;
      Point3D localPoint3D = Sensor.MOVEMENT_GYRO.convert((byte[])localObject);
      paramBluetoothGattCharacteristic = (SensorTagMovementTableRow)this.tRow;
      paramBluetoothGattCharacteristic.gyroValue.setText(String.format("X:%.2f'/s, Y:%.2f'/s, Z:%.2f'/s", new Object[] { Double.valueOf(localPoint3D.x), Double.valueOf(localPoint3D.y), Double.valueOf(localPoint3D.z) }));
      paramBluetoothGattCharacteristic.sl4.addValue((float)localPoint3D.x);
      paramBluetoothGattCharacteristic.sl5.addValue((float)localPoint3D.y);
      paramBluetoothGattCharacteristic.sl6.addValue((float)localPoint3D.z);
      com.eospy.client.PositionProvider.gyro_xSensor = (float)localPoint3D.x;
      com.eospy.client.PositionProvider.gyro_ySensor = (float)localPoint3D.y;
      com.eospy.client.PositionProvider.gyro_zSensor = (float)localPoint3D.z;
      localObject = Sensor.MOVEMENT_MAG.convert((byte[])localObject);
      paramBluetoothGattCharacteristic.magValue.setText(String.format("X:%.2fuT, Y:%.2fuT, Z:%.2fuT", new Object[] { Double.valueOf(((Point3D)localObject).x), Double.valueOf(((Point3D)localObject).y), Double.valueOf(((Point3D)localObject).z) }));
      paramBluetoothGattCharacteristic.sl7.addValue((float)((Point3D)localObject).x);
      paramBluetoothGattCharacteristic.sl8.addValue((float)((Point3D)localObject).y);
      paramBluetoothGattCharacteristic.sl9.addValue((float)((Point3D)localObject).z);
      com.eospy.client.PositionProvider.magnet_xSensor = (float)((Point3D)localObject).x;
      com.eospy.client.PositionProvider.magnet_ySensor = (float)((Point3D)localObject).y;
      com.eospy.client.PositionProvider.magnet_zSensor = (float)((Point3D)localObject).z;
    }
  }
  
  public void didWriteValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic) {}
  
  public void disableService()
  {
    int i = this.mBTLeService.writeCharacteristic(this.configC, new byte[] { 0, 0 });
    if ((i != 0) && (this.configC != null)) {
      Log.d("SensorTagMovementProfile", "Sensor config failed: " + this.configC.getUuid().toString() + " Error: " + i);
    }
    i = this.mBTLeService.setCharacteristicNotification(this.dataC, false);
    if ((i != 0) && (this.dataC != null)) {
      Log.d("SensorTagMovementProfile", "Sensor notification disable failed: " + this.configC.getUuid().toString() + " Error: " + i);
    }
    this.isEnabled = false;
  }
  
  public void enableService()
  {
    int i = this.mBTLeService.writeCharacteristic(this.configC, new byte[] { 127, 2 });
    if ((i != 0) && (this.configC != null)) {
      Log.d("SensorTagMovementProfile", "Sensor config failed: " + this.configC.getUuid().toString() + " Error: " + i);
    }
    i = this.mBTLeService.setCharacteristicNotification(this.dataC, true);
    if ((i != 0) && (this.dataC != null)) {
      Log.d("SensorTagMovementProfile", "Sensor notification enable failed: " + this.configC.getUuid().toString() + " Error: " + i);
    }
    periodWasUpdated(1000);
    this.isEnabled = true;
  }
  
  public Map<String, String> getMQTTMap()
  {
    Point3D localPoint3D = Sensor.MOVEMENT_ACC.convert(this.dataC.getValue());
    HashMap localHashMap = new HashMap();
    localHashMap.put("acc_x", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.x) }));
    localHashMap.put("acc_y", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.y) }));
    localHashMap.put("acc_z", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.z) }));
    localPoint3D = Sensor.MOVEMENT_GYRO.convert(this.dataC.getValue());
    localHashMap.put("gyro_x", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.x) }));
    localHashMap.put("gyro_y", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.y) }));
    localHashMap.put("gyro_z", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.z) }));
    localPoint3D = Sensor.MOVEMENT_MAG.convert(this.dataC.getValue());
    localHashMap.put("mag_x", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.x) }));
    localHashMap.put("mag_y", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.y) }));
    localHashMap.put("mag_z", String.format("%.2f", new Object[] { Double.valueOf(localPoint3D.z) }));
    return localHashMap;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\SensorTagMovementProfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */