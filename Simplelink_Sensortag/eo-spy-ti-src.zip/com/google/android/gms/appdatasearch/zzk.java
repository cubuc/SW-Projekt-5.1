package com.google.android.gms.appdatasearch;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;

public abstract interface zzk
{
  public abstract PendingResult<GetRecentContextCall.Response> zza(GoogleApiClient paramGoogleApiClient, GetRecentContextCall.Request paramRequest);
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\google\android\gms\appdatasearch\zzk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */