package com.google.android.gms.auth.api.signin.internal;

public class zzc
{
  static int zzTo = 31;
  private int zzTp = 1;
  
  public zzc zzP(boolean paramBoolean)
  {
    int j = zzTo;
    int k = this.zzTp;
    if (paramBoolean) {}
    for (int i = 1;; i = 0)
    {
      this.zzTp = (i + k * j);
      return this;
    }
  }
  
  public zzc zzl(Object paramObject)
  {
    int j = zzTo;
    int k = this.zzTp;
    if (paramObject == null) {}
    for (int i = 0;; i = paramObject.hashCode())
    {
      this.zzTp = (i + k * j);
      return this;
    }
  }
  
  public int zzmd()
  {
    return this.zzTp;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\google\android\gms\auth\api\signin\internal\zzc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */