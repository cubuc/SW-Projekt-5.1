package com.eospy.sensortag;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;

public class DeviceView
  extends Fragment
{
  public static DeviceView mInstance = null;
  public boolean first = true;
  private DeviceActivity mActivity;
  private boolean mBusy;
  private TableLayout table;
  View view;
  
  public void addRowToTable(TableRow paramTableRow)
  {
    if (this.first)
    {
      this.table.removeAllViews();
      this.table.addView(paramTableRow);
      this.table.requestLayout();
      this.first = false;
      return;
    }
    this.table.addView(paramTableRow);
    this.table.requestLayout();
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    mInstance = this;
    this.mActivity = ((DeviceActivity)getActivity());
    this.view = paramLayoutInflater.inflate(2130903051, paramViewGroup, false);
    this.table = ((TableLayout)this.view.findViewById(2131492895));
    this.mActivity.onViewInflated(this.view);
    return this.view;
  }
  
  public void onPause()
  {
    super.onPause();
  }
  
  public void onResume()
  {
    super.onResume();
  }
  
  public void removeRowsFromTable()
  {
    this.table.removeAllViews();
  }
  
  void setBusy(boolean paramBoolean)
  {
    if (paramBoolean != this.mBusy)
    {
      this.mActivity.showBusyIndicator(paramBoolean);
      this.mBusy = paramBoolean;
    }
  }
  
  public void showProgressOverlay(String paramString) {}
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\DeviceView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */