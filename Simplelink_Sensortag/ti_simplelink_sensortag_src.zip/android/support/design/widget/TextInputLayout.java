package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.support.design.R.style;
import android.support.design.R.styleable;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorCompat;
import android.support.v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup.LayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AccelerateInterpolator;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import java.util.List;

public class TextInputLayout
  extends LinearLayout
{
  private static final int ANIMATION_DURATION = 200;
  private static final int MSG_UPDATE_LABEL = 0;
  private ValueAnimatorCompat mAnimator;
  private final CollapsingTextHelper mCollapsingTextHelper;
  private int mDefaultTextColor;
  private EditText mEditText;
  private boolean mErrorEnabled;
  private int mErrorTextAppearance;
  private TextView mErrorView;
  private int mFocusedTextColor;
  private final Handler mHandler;
  private CharSequence mHint;
  
  public TextInputLayout(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public TextInputLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    setOrientation(1);
    setWillNotDraw(false);
    this.mCollapsingTextHelper = new CollapsingTextHelper(this);
    this.mHandler = new Handler(new Handler.Callback()
    {
      public boolean handleMessage(Message paramAnonymousMessage)
      {
        switch (paramAnonymousMessage.what)
        {
        default: 
          return false;
        }
        TextInputLayout.this.updateLabelVisibility(true);
        return true;
      }
    });
    this.mCollapsingTextHelper.setTextSizeInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
    this.mCollapsingTextHelper.setPositionInterpolator(new AccelerateInterpolator());
    this.mCollapsingTextHelper.setCollapsedTextVerticalGravity(48);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.TextInputLayout, 0, R.style.Widget_Design_TextInputLayout);
    this.mHint = paramContext.getText(R.styleable.TextInputLayout_android_hint);
    int i = paramContext.getResourceId(R.styleable.TextInputLayout_hintTextAppearance, -1);
    if (i != -1) {
      this.mCollapsingTextHelper.setCollapsedTextAppearance(i);
    }
    this.mErrorTextAppearance = paramContext.getResourceId(R.styleable.TextInputLayout_errorTextAppearance, 0);
    boolean bool = paramContext.getBoolean(R.styleable.TextInputLayout_errorEnabled, false);
    this.mDefaultTextColor = getThemeAttrColor(16842906);
    this.mFocusedTextColor = this.mCollapsingTextHelper.getCollapsedTextColor();
    this.mCollapsingTextHelper.setCollapsedTextColor(this.mDefaultTextColor);
    this.mCollapsingTextHelper.setExpandedTextColor(this.mDefaultTextColor);
    paramContext.recycle();
    if (bool) {
      setErrorEnabled(true);
    }
    if (ViewCompat.getImportantForAccessibility(this) == 0) {
      ViewCompat.setImportantForAccessibility(this, 1);
    }
    ViewCompat.setAccessibilityDelegate(this, new TextInputAccessibilityDelegate(null));
  }
  
  private void animateToExpansionFraction(float paramFloat)
  {
    if (this.mAnimator == null)
    {
      this.mAnimator = ViewUtils.createAnimator();
      this.mAnimator.setInterpolator(AnimationUtils.LINEAR_INTERPOLATOR);
      this.mAnimator.setDuration(200);
      this.mAnimator.setUpdateListener(new ValueAnimatorCompat.AnimatorUpdateListener()
      {
        public void onAnimationUpdate(ValueAnimatorCompat paramAnonymousValueAnimatorCompat)
        {
          TextInputLayout.this.mCollapsingTextHelper.setExpansionFraction(paramAnonymousValueAnimatorCompat.getAnimatedFloatValue());
        }
      });
    }
    for (;;)
    {
      this.mAnimator.setFloatValues(this.mCollapsingTextHelper.getExpansionFraction(), paramFloat);
      this.mAnimator.start();
      return;
      if (this.mAnimator.isRunning()) {
        this.mAnimator.cancel();
      }
    }
  }
  
  private void collapseHint(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      animateToExpansionFraction(1.0F);
      return;
    }
    this.mCollapsingTextHelper.setExpansionFraction(1.0F);
  }
  
  private void expandHint(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      animateToExpansionFraction(0.0F);
      return;
    }
    this.mCollapsingTextHelper.setExpansionFraction(0.0F);
  }
  
  private int getThemeAttrColor(int paramInt)
  {
    TypedValue localTypedValue = new TypedValue();
    if (getContext().getTheme().resolveAttribute(paramInt, localTypedValue, true)) {
      return localTypedValue.data;
    }
    return -65281;
  }
  
  private LinearLayout.LayoutParams setEditText(EditText paramEditText, ViewGroup.LayoutParams paramLayoutParams)
  {
    if (this.mEditText != null) {
      throw new IllegalArgumentException("We already have an EditText, can only have one");
    }
    this.mEditText = paramEditText;
    this.mCollapsingTextHelper.setExpandedTextSize(this.mEditText.getTextSize());
    this.mEditText.addTextChangedListener(new TextWatcher()
    {
      public void afterTextChanged(Editable paramAnonymousEditable)
      {
        TextInputLayout.this.mHandler.sendEmptyMessage(0);
      }
      
      public void beforeTextChanged(CharSequence paramAnonymousCharSequence, int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3) {}
      
      public void onTextChanged(CharSequence paramAnonymousCharSequence, int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3) {}
    });
    this.mDefaultTextColor = this.mEditText.getHintTextColors().getDefaultColor();
    this.mEditText.setOnFocusChangeListener(new View.OnFocusChangeListener()
    {
      public void onFocusChange(View paramAnonymousView, boolean paramAnonymousBoolean)
      {
        TextInputLayout.this.mHandler.sendEmptyMessage(0);
      }
    });
    if (TextUtils.isEmpty(this.mHint))
    {
      setHint(this.mEditText.getHint());
      this.mEditText.setHint(null);
    }
    if (this.mErrorView != null) {
      ViewCompat.setPaddingRelative(this.mErrorView, ViewCompat.getPaddingStart(this.mEditText), 0, ViewCompat.getPaddingEnd(this.mEditText), this.mEditText.getPaddingBottom());
    }
    updateLabelVisibility(false);
    paramEditText = new LinearLayout.LayoutParams(paramLayoutParams);
    paramLayoutParams = new Paint();
    paramLayoutParams.setTextSize(this.mCollapsingTextHelper.getExpandedTextSize());
    paramEditText.topMargin = ((int)-paramLayoutParams.ascent());
    return paramEditText;
  }
  
  private void updateLabelVisibility(boolean paramBoolean)
  {
    int i;
    boolean bool;
    CollapsingTextHelper localCollapsingTextHelper;
    if (!TextUtils.isEmpty(this.mEditText.getText()))
    {
      i = 1;
      bool = this.mEditText.isFocused();
      this.mCollapsingTextHelper.setExpandedTextColor(this.mDefaultTextColor);
      localCollapsingTextHelper = this.mCollapsingTextHelper;
      if (!bool) {
        break label77;
      }
    }
    label77:
    for (int j = this.mFocusedTextColor;; j = this.mDefaultTextColor)
    {
      localCollapsingTextHelper.setCollapsedTextColor(j);
      if ((i == 0) && (!bool)) {
        break label85;
      }
      collapseHint(paramBoolean);
      return;
      i = 0;
      break;
    }
    label85:
    expandHint(paramBoolean);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramView instanceof EditText))
    {
      super.addView(paramView, 0, setEditText((EditText)paramView, paramLayoutParams));
      return;
    }
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  public void draw(Canvas paramCanvas)
  {
    super.draw(paramCanvas);
    this.mCollapsingTextHelper.draw(paramCanvas);
  }
  
  public EditText getEditText()
  {
    return this.mEditText;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (this.mEditText != null)
    {
      paramInt1 = this.mEditText.getLeft() + this.mEditText.getCompoundPaddingLeft();
      paramInt3 = this.mEditText.getRight() - this.mEditText.getCompoundPaddingRight();
      this.mCollapsingTextHelper.setExpandedBounds(paramInt1, this.mEditText.getTop() + this.mEditText.getCompoundPaddingTop(), paramInt3, this.mEditText.getBottom() - this.mEditText.getCompoundPaddingBottom());
      this.mCollapsingTextHelper.setCollapsedBounds(paramInt1, getPaddingTop(), paramInt3, paramInt4 - paramInt2 - getPaddingBottom());
      this.mCollapsingTextHelper.recalculate();
    }
  }
  
  public void setError(CharSequence paramCharSequence)
  {
    if (!this.mErrorEnabled)
    {
      if (TextUtils.isEmpty(paramCharSequence)) {
        return;
      }
      setErrorEnabled(true);
    }
    if (!TextUtils.isEmpty(paramCharSequence))
    {
      this.mErrorView.setText(paramCharSequence);
      this.mErrorView.setVisibility(0);
      ViewCompat.setAlpha(this.mErrorView, 0.0F);
      ViewCompat.animate(this.mErrorView).alpha(1.0F).setDuration(200L).setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR).setListener(null).start();
    }
    for (;;)
    {
      sendAccessibilityEvent(2048);
      return;
      if (this.mErrorView.getVisibility() == 0) {
        ViewCompat.animate(this.mErrorView).alpha(0.0F).setDuration(200L).setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR).setListener(new ViewPropertyAnimatorListenerAdapter()
        {
          public void onAnimationEnd(View paramAnonymousView)
          {
            TextInputLayout.this.mErrorView.setText(null);
            TextInputLayout.this.mErrorView.setVisibility(4);
          }
        }).start();
      }
    }
  }
  
  public void setErrorEnabled(boolean paramBoolean)
  {
    if (this.mErrorEnabled != paramBoolean)
    {
      if (!paramBoolean) {
        break label100;
      }
      this.mErrorView = new TextView(getContext());
      this.mErrorView.setTextAppearance(getContext(), this.mErrorTextAppearance);
      this.mErrorView.setVisibility(4);
      addView(this.mErrorView);
      if (this.mEditText != null) {
        ViewCompat.setPaddingRelative(this.mErrorView, ViewCompat.getPaddingStart(this.mEditText), 0, ViewCompat.getPaddingEnd(this.mEditText), this.mEditText.getPaddingBottom());
      }
    }
    for (;;)
    {
      this.mErrorEnabled = paramBoolean;
      return;
      label100:
      removeView(this.mErrorView);
      this.mErrorView = null;
    }
  }
  
  public void setHint(CharSequence paramCharSequence)
  {
    this.mHint = paramCharSequence;
    this.mCollapsingTextHelper.setText(paramCharSequence);
    sendAccessibilityEvent(2048);
  }
  
  private class TextInputAccessibilityDelegate
    extends AccessibilityDelegateCompat
  {
    private TextInputAccessibilityDelegate() {}
    
    public void onInitializeAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      super.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
      paramAccessibilityEvent.setClassName(TextInputLayout.class.getSimpleName());
    }
    
    public void onInitializeAccessibilityNodeInfo(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
    {
      super.onInitializeAccessibilityNodeInfo(paramView, paramAccessibilityNodeInfoCompat);
      paramAccessibilityNodeInfoCompat.setClassName(TextInputLayout.class.getSimpleName());
      paramView = TextInputLayout.this.mCollapsingTextHelper.getText();
      if (!TextUtils.isEmpty(paramView)) {
        paramAccessibilityNodeInfoCompat.setText(paramView);
      }
      if (TextInputLayout.this.mEditText != null) {
        paramAccessibilityNodeInfoCompat.setLabelFor(TextInputLayout.this.mEditText);
      }
      if (TextInputLayout.this.mErrorView != null) {}
      for (paramView = TextInputLayout.this.mErrorView.getText();; paramView = null)
      {
        if (!TextUtils.isEmpty(paramView))
        {
          paramAccessibilityNodeInfoCompat.setContentInvalid(true);
          paramAccessibilityNodeInfoCompat.setError(paramView);
        }
        return;
      }
    }
    
    public void onPopulateAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      super.onPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
      paramView = TextInputLayout.this.mCollapsingTextHelper.getText();
      if (!TextUtils.isEmpty(paramView)) {
        paramAccessibilityEvent.getText().add(paramView);
      }
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\Simplelink_Sensortag\classes-dex2jar.jar!\android\support\design\widget\TextInputLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */