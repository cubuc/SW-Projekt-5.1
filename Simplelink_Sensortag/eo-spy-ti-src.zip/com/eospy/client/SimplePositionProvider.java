package com.eospy.client;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

public class SimplePositionProvider
  extends PositionProvider
  implements LocationListener
{
  public SimplePositionProvider(Context paramContext, PositionProvider.PositionListener paramPositionListener)
  {
    super(paramContext, paramPositionListener);
    if (!this.type.equals("network")) {
      this.type = "gps";
    }
  }
  
  public void onLocationChanged(Location paramLocation)
  {
    updateLocation(paramLocation);
  }
  
  public void onProviderDisabled(String paramString) {}
  
  public void onProviderEnabled(String paramString) {}
  
  public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle) {}
  
  public void startUpdates()
  {
    try
    {
      this.locationManager.requestLocationUpdates(this.type, this.period, 0.0F, this);
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      Log.w(TAG, localIllegalArgumentException);
    }
  }
  
  public void stopUpdates()
  {
    this.locationManager.removeUpdates(this);
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\SimplePositionProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */