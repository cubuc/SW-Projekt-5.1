package com.eospy.client;

import android.net.Uri;
import android.net.Uri.Builder;
import java.util.Date;

public class ProtocolFormatter
{
  public static String formatRequest(String paramString, int paramInt, boolean paramBoolean, Position paramPosition)
  {
    return formatRequest(paramString, paramInt, paramBoolean, paramPosition, null);
  }
  
  public static String formatRequest(String paramString1, int paramInt, boolean paramBoolean, Position paramPosition, String paramString2)
  {
    Uri.Builder localBuilder = new Uri.Builder();
    if (paramBoolean) {}
    for (String str = "https";; str = "http")
    {
      localBuilder.scheme(str).encodedAuthority(paramString1 + ':' + paramInt).appendQueryParameter("id", paramPosition.getDeviceId()).appendQueryParameter("timestamp", String.valueOf(paramPosition.getTime().getTime() / 1000L)).appendQueryParameter("lat", String.valueOf(paramPosition.getLatitude())).appendQueryParameter("lon", String.valueOf(paramPosition.getLongitude())).appendQueryParameter("speed", String.valueOf(paramPosition.getSpeed())).appendQueryParameter("bearing", String.valueOf(paramPosition.getCourse())).appendQueryParameter("altitude", String.valueOf(paramPosition.getAltitude())).appendQueryParameter("batt", String.valueOf(paramPosition.getBattery())).appendQueryParameter("temp", String.valueOf(String.format("%.1f", new Object[] { Double.valueOf(paramPosition.getTemp()) }))).appendQueryParameter("ir_temp", String.valueOf(String.format("%.1f", new Object[] { Double.valueOf(paramPosition.getIR_Temp()) }))).appendQueryParameter("humidity", String.valueOf(String.format("%.1f", new Object[] { Double.valueOf(paramPosition.getHumidity()) }))).appendQueryParameter("mbar", String.valueOf(String.format("%.1f", new Object[] { Double.valueOf(paramPosition.getMbar()) }))).appendQueryParameter("accel_x", String.valueOf(String.format("%.2f", new Object[] { Double.valueOf(paramPosition.getAccel_x()) }))).appendQueryParameter("accel_y", String.valueOf(String.format("%.2f", new Object[] { Double.valueOf(paramPosition.getAccel_y()) }))).appendQueryParameter("accel_z", String.valueOf(String.format("%.2f", new Object[] { Double.valueOf(paramPosition.getAccel_z()) }))).appendQueryParameter("gyro_x", String.valueOf(String.format("%.2f", new Object[] { Double.valueOf(paramPosition.getGyro_x()) }))).appendQueryParameter("gyro_y", String.valueOf(String.format("%.2f", new Object[] { Double.valueOf(paramPosition.getGyro_y()) }))).appendQueryParameter("gyro_z", String.valueOf(String.format("%.2f", new Object[] { Double.valueOf(paramPosition.getGyro_z()) }))).appendQueryParameter("magnet_x", String.valueOf(String.format("%.2f", new Object[] { Double.valueOf(paramPosition.getMagnet_x()) }))).appendQueryParameter("magnet_y", String.valueOf(String.format("%.2f", new Object[] { Double.valueOf(paramPosition.getMagnet_y()) }))).appendQueryParameter("magnet_z", String.valueOf(String.format("%.2f", new Object[] { Double.valueOf(paramPosition.getMagnet_z()) }))).appendQueryParameter("light", String.valueOf(String.format("%.1f", new Object[] { Double.valueOf(paramPosition.getLight()) }))).appendQueryParameter("keypress", String.valueOf(String.format("%.1f", new Object[] { Double.valueOf(paramPosition.getKeyPress()) })));
      if (paramString2 != null) {
        localBuilder.appendQueryParameter("alarm", paramString2);
      }
      return localBuilder.build().toString();
    }
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\client\ProtocolFormatter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */