package com.eospy.sensortag;

import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothAdapter.LeScanCallback;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import com.eospy.client.TrackingService;
import com.eospy.common.BleDeviceInfo;
import com.eospy.common.BluetoothLeService;
import com.eospy.common.HCIDefines;
import com.eospy.common.HelpView;
import com.eospy.util.CustomToast;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity
  extends ViewPagerActivity
{
  private static final int NO_DEVICE = -1;
  private static final int REQ_DEVICE_ACT = 1;
  private static final int REQ_ENABLE_BT = 0;
  private static final int STATUS_DURATION = 5;
  private static final Uri URL_FORUM = Uri.parse("http://e2e.ti.com/support/low_power_rf/default.aspx?DCMP=hpa_hpa_community&HQS=NotApplicable+OT+lprf-forum");
  private static final Uri URL_STHOME = Uri.parse("http://www.ti.com/ww/en/wireless_connectivity/sensortag/index.shtml?INTC=SensorTagGatt&HQS=sensortag");
  private static BluetoothManager mBluetoothManager;
  public static MainActivity mThis = null;
  private boolean mBleSupported = true;
  private BluetoothDevice mBluetoothDevice = null;
  private BluetoothLeService mBluetoothLeService = null;
  private BluetoothAdapter mBtAdapter = null;
  private boolean mBtAdapterEnabled = false;
  private int mConnIndex = -1;
  private String[] mDeviceFilter = null;
  private List<BleDeviceInfo> mDeviceInfoList;
  private Intent mDeviceIntent;
  private IntentFilter mFilter;
  private boolean mInitialised = false;
  private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback()
  {
    public void onLeScan(final BluetoothDevice paramAnonymousBluetoothDevice, final int paramAnonymousInt, byte[] paramAnonymousArrayOfByte)
    {
      MainActivity.this.runOnUiThread(new Runnable()
      {
        public void run()
        {
          if (MainActivity.this.checkDeviceFilter(paramAnonymousBluetoothDevice.getName()))
          {
            if (!MainActivity.this.deviceInfoExists(paramAnonymousBluetoothDevice.getAddress()))
            {
              BleDeviceInfo localBleDeviceInfo = MainActivity.this.createDeviceInfo(paramAnonymousBluetoothDevice, paramAnonymousInt);
              MainActivity.this.addDevice(localBleDeviceInfo);
            }
          }
          else {
            return;
          }
          MainActivity.this.findDeviceInfo(paramAnonymousBluetoothDevice).updateRssi(paramAnonymousInt);
          MainActivity.this.mScanView.notifyDataSetChanged();
        }
      });
    }
  };
  private int mNumDevs = 0;
  private BroadcastReceiver mReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      String str = paramAnonymousIntent.getAction();
      if ("android.bluetooth.adapter.action.STATE_CHANGED".equals(str)) {
        switch (MainActivity.this.mBtAdapter.getState())
        {
        case 11: 
        default: 
          MainActivity.this.updateGuiState();
        }
      }
      do
      {
        return;
        MainActivity.access$202(MainActivity.this, -1);
        break;
        Toast.makeText(paramAnonymousContext, 2131034147, 1).show();
        MainActivity.this.finish();
        break;
        if ("com.eospy.common.ACTION_GATT_CONNECTED".equals(str))
        {
          i = paramAnonymousIntent.getIntExtra("com.eospy.common.EXTRA_STATUS", 257);
          if (i == 0)
          {
            MainActivity.this.setBusy(false);
            MainActivity.this.startDeviceActivity();
            return;
          }
          MainActivity.this.setError("Connect failed. Status: " + i);
          return;
        }
      } while (!"com.eospy.common.ACTION_GATT_DISCONNECTED".equals(str));
      int i = paramAnonymousIntent.getIntExtra("com.eospy.common.EXTRA_STATUS", 257);
      MainActivity.this.stopDeviceActivity();
      if (i == 0)
      {
        MainActivity.this.setBusy(false);
        MainActivity.this.mScanView.setStatus(MainActivity.this.mBluetoothDevice.getName() + " disconnected", 5);
      }
      for (;;)
      {
        MainActivity.access$202(MainActivity.this, -1);
        MainActivity.this.mBluetoothLeService.close();
        return;
        MainActivity.this.setError("Disconnect Status: " + (String)HCIDefines.hciErrorCodeStrings.get(Integer.valueOf(i)));
      }
    }
  };
  private ScanView mScanView;
  private boolean mScanning = false;
  SharedPreferences prefs = null;
  
  public MainActivity()
  {
    mThis = this;
    this.mResourceFragmentPager = 2130903048;
    this.mResourceIdPager = 2131492891;
  }
  
  private void addDevice(BleDeviceInfo paramBleDeviceInfo)
  {
    this.mNumDevs += 1;
    this.mDeviceInfoList.add(paramBleDeviceInfo);
    this.mScanView.notifyDataSetChanged();
    if (this.mNumDevs > 1)
    {
      this.mScanView.setStatus(this.mNumDevs + " devices");
      return;
    }
    this.mScanView.setStatus("1 device");
  }
  
  private BleDeviceInfo createDeviceInfo(BluetoothDevice paramBluetoothDevice, int paramInt)
  {
    return new BleDeviceInfo(paramBluetoothDevice, paramInt);
  }
  
  private boolean deviceInfoExists(String paramString)
  {
    int i = 0;
    while (i < this.mDeviceInfoList.size())
    {
      if (((BleDeviceInfo)this.mDeviceInfoList.get(i)).getBluetoothDevice().getAddress().equals(paramString)) {
        return true;
      }
      i += 1;
    }
    return false;
  }
  
  private BleDeviceInfo findDeviceInfo(BluetoothDevice paramBluetoothDevice)
  {
    int i = 0;
    while (i < this.mDeviceInfoList.size())
    {
      if (((BleDeviceInfo)this.mDeviceInfoList.get(i)).getBluetoothDevice().getAddress().equals(paramBluetoothDevice.getAddress())) {
        return (BleDeviceInfo)this.mDeviceInfoList.get(i);
      }
      i += 1;
    }
    return null;
  }
  
  private void onAbout()
  {
    new AboutDialog(this).show();
  }
  
  private void onBluetooth()
  {
    startActivity(new Intent("android.settings.BLUETOOTH_SETTINGS"));
  }
  
  private void onUrl(Uri paramUri)
  {
    startActivity(new Intent("android.intent.action.VIEW", paramUri));
  }
  
  private boolean scanLeDevice(boolean paramBoolean)
  {
    if (paramBoolean) {
      this.mScanning = this.mBtAdapter.startLeScan(this.mLeScanCallback);
    }
    for (;;)
    {
      return this.mScanning;
      this.mScanning = false;
      this.mBtAdapter.stopLeScan(this.mLeScanCallback);
    }
  }
  
  private void setBusy(boolean paramBoolean)
  {
    this.mScanView.setBusy(paramBoolean);
  }
  
  private void startDeviceActivity()
  {
    this.mDeviceIntent = new Intent(this, DeviceActivity.class);
    this.mDeviceIntent.putExtra("EXTRA_DEVICE", this.mBluetoothDevice);
    startActivityForResult(this.mDeviceIntent, 1);
  }
  
  private void startScan()
  {
    if (this.mBleSupported)
    {
      this.mNumDevs = 0;
      this.mDeviceInfoList.clear();
      this.mScanView.notifyDataSetChanged();
      scanLeDevice(true);
      this.mScanView.updateGui(this.mScanning);
      if (!this.mScanning)
      {
        setError("Device discovery start failed");
        setBusy(false);
      }
      return;
    }
    setError("BLE not supported on this device");
  }
  
  private void stopDeviceActivity()
  {
    finishActivity(1);
  }
  
  private void stopScan()
  {
    this.mScanning = false;
    this.mScanView.updateGui(false);
    scanLeDevice(false);
  }
  
  boolean checkDeviceFilter(String paramString)
  {
    boolean bool2;
    if (paramString == null)
    {
      bool2 = false;
      return bool2;
    }
    int j = this.mDeviceFilter.length;
    if (j > 0)
    {
      boolean bool1 = false;
      int i = 0;
      for (;;)
      {
        bool2 = bool1;
        if (i >= j) {
          break;
        }
        bool2 = bool1;
        if (bool1) {
          break;
        }
        bool1 = paramString.equals(this.mDeviceFilter[i]);
        i += 1;
      }
    }
    return true;
  }
  
  List<BleDeviceInfo> getDeviceInfoList()
  {
    return this.mDeviceInfoList;
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    switch (paramInt1)
    {
    default: 
      CustomToast.middleBottom(this, "Unknown request code: " + paramInt1);
    case 1: 
      do
      {
        return;
      } while (this.mConnIndex == -1);
      this.mBluetoothLeService.disconnect(this.mBluetoothDevice.getAddress());
      return;
    }
    if (paramInt2 == -1)
    {
      Toast.makeText(this, 2131034159, 0).show();
      return;
    }
    Toast.makeText(this, 2131034157, 0).show();
    finish();
  }
  
  public void onBtnScan(View paramView)
  {
    if (this.mScanning)
    {
      stopScan();
      return;
    }
    startScan();
  }
  
  void onConnect()
  {
    if (this.mNumDevs > 0) {
      switch (mBluetoothManager.getConnectionState(this.mBluetoothDevice, 7))
      {
      case 1: 
      default: 
        setError("Device busy (connecting/disconnecting)");
      }
    }
    do
    {
      return;
      this.mBluetoothLeService.disconnect(null);
      return;
    } while (this.mBluetoothLeService.connect(this.mBluetoothDevice.getAddress()));
    setError("Connect failed");
  }
  
  public void onConnectTimeout()
  {
    runOnUiThread(new Runnable()
    {
      public void run()
      {
        MainActivity.this.setError("Connection timed out");
      }
    });
    if (this.mConnIndex != -1)
    {
      this.mBluetoothLeService.disconnect(this.mBluetoothDevice.getAddress());
      this.mConnIndex = -1;
    }
  }
  
  public void onCreate(Bundle paramBundle)
  {
    requestWindowFeature(5);
    super.onCreate(paramBundle);
    this.prefs = PreferenceManager.getDefaultSharedPreferences(this);
    this.mDeviceInfoList = new ArrayList();
    this.mDeviceFilter = getResources().getStringArray(2131099648);
    this.mScanView = new ScanView();
    this.mSectionsPagerAdapter.addSection(this.mScanView, "BLE Device List");
    paramBundle = new HelpView();
    paramBundle.setParameters("help_scan.html", 2130903047, 2131492890);
    this.mSectionsPagerAdapter.addSection(paramBundle, "Help");
    this.mFilter = new IntentFilter("android.bluetooth.adapter.action.STATE_CHANGED");
    this.mFilter.addAction("com.eospy.common.ACTION_GATT_CONNECTED");
    this.mFilter.addAction("com.eospy.common.ACTION_GATT_DISCONNECTED");
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    this.optionsMenu = paramMenu;
    getMenuInflater().inflate(2131427329, paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    this.mBtAdapter = null;
    String str = getCacheDir().getPath();
    try
    {
      Runtime.getRuntime().exec(String.format("rm -rf %s", new Object[] { str }));
      return;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
  
  public void onDeviceClick(int paramInt)
  {
    if (this.mScanning) {
      stopScan();
    }
    setBusy(true);
    this.mBluetoothDevice = ((BleDeviceInfo)this.mDeviceInfoList.get(paramInt)).getBluetoothDevice();
    if (this.mConnIndex == -1)
    {
      this.mScanView.setStatus("Connecting");
      this.mConnIndex = paramInt;
      onConnect();
    }
    do
    {
      return;
      this.mScanView.setStatus("Disconnecting");
    } while (this.mConnIndex == -1);
    this.mBluetoothLeService.disconnect(this.mBluetoothDevice.getAddress());
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    switch (paramMenuItem.getItemId())
    {
    default: 
      return super.onOptionsItemSelected(paramMenuItem);
    case 16908332: 
      onBackPressed();
      return true;
    case 2131492901: 
      onBluetooth();
      return true;
    case 2131492900: 
      onAbout();
      return true;
    }
    Toast.makeText(this, "Exit...", 0).show();
    if (this.prefs.getBoolean("status", true)) {
      stopService(new Intent(this, TrackingService.class));
    }
    finish();
    return true;
  }
  
  public void onScanTimeout()
  {
    runOnUiThread(new Runnable()
    {
      public void run()
      {
        MainActivity.this.stopScan();
      }
    });
  }
  
  void onScanViewReady(View paramView)
  {
    if (!this.mInitialised)
    {
      this.mBluetoothLeService = BluetoothLeService.getInstance();
      paramView = this.mBluetoothLeService;
      mBluetoothManager = BluetoothLeService.getBtManager();
      this.mBtAdapter = mBluetoothManager.getAdapter();
      registerReceiver(this.mReceiver, this.mFilter);
      this.mBtAdapterEnabled = this.mBtAdapter.isEnabled();
      if (this.mBtAdapterEnabled) {
        this.mInitialised = true;
      }
    }
    for (;;)
    {
      updateGuiState();
      return;
      startActivityForResult(new Intent("android.bluetooth.adapter.action.REQUEST_ENABLE"), 0);
      break;
      this.mScanView.notifyDataSetChanged();
    }
  }
  
  void setError(String paramString)
  {
    this.mScanView.setError(paramString);
  }
  
  public void updateGuiState()
  {
    if (this.mBtAdapter.isEnabled())
    {
      if (this.mScanning)
      {
        if (this.mConnIndex != -1)
        {
          String str = this.mBluetoothDevice.getName() + " connected";
          this.mScanView.setStatus(str);
        }
      }
      else {
        return;
      }
      this.mScanView.setStatus(this.mNumDevs + " devices");
      return;
    }
    this.mDeviceInfoList.clear();
    this.mScanView.notifyDataSetChanged();
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */