package com.eospy.sensortag;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.widget.ImageView;
import android.widget.TextView;
import com.eospy.client.PositionProvider;
import com.eospy.common.BluetoothLeService;
import com.eospy.common.GattInfo;
import com.eospy.common.GenericBluetoothProfile;
import com.eospy.util.GenericCharacteristicTableRow;
import com.eospy.util.SparkLineView;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SensorTagSimpleKeysProfile
  extends GenericBluetoothProfile
{
  public SensorTagSimpleKeysProfile(Context paramContext, BluetoothDevice paramBluetoothDevice, BluetoothGattService paramBluetoothGattService, BluetoothLeService paramBluetoothLeService)
  {
    super(paramContext, paramBluetoothDevice, paramBluetoothGattService, paramBluetoothLeService);
    this.tRow = new SensorTagSimpleKeysTableRow(paramContext);
    paramContext = this.mBTService.getCharacteristics().iterator();
    while (paramContext.hasNext())
    {
      paramBluetoothDevice = (BluetoothGattCharacteristic)paramContext.next();
      if (paramBluetoothDevice.getUuid().toString().equals(SensorTagGatt.UUID_KEY_DATA.toString())) {
        this.dataC = paramBluetoothDevice;
      }
    }
    this.tRow.setIcon(getIconPrefix(), this.dataC.getUuid().toString());
    this.tRow.title.setText(GattInfo.uuidToName(UUID.fromString(this.dataC.getUuid().toString())));
    this.tRow.uuidLabel.setText(this.dataC.getUuid().toString());
    if (!this.mBTDevice.getName().equals("CC2650 SensorTag"))
    {
      paramContext = (SensorTagSimpleKeysTableRow)this.tRow;
      paramContext.sl3.setVisibility(4);
      paramContext.reedStateImage.setVisibility(4);
    }
  }
  
  public static boolean isCorrectService(BluetoothGattService paramBluetoothGattService)
  {
    return paramBluetoothGattService.getUuid().toString().compareTo(SensorTagGatt.UUID_KEY_SERV.toString()) == 0;
  }
  
  public void didUpdateValueForCharacteristic(BluetoothGattCharacteristic paramBluetoothGattCharacteristic)
  {
    SensorTagSimpleKeysTableRow localSensorTagSimpleKeysTableRow = (SensorTagSimpleKeysTableRow)this.tRow;
    if (paramBluetoothGattCharacteristic.equals(this.dataC))
    {
      paramBluetoothGattCharacteristic = paramBluetoothGattCharacteristic.getValue();
      switch (paramBluetoothGattCharacteristic[0])
      {
      default: 
        localSensorTagSimpleKeysTableRow.leftKeyPressStateImage.setImageResource(2130837538);
        localSensorTagSimpleKeysTableRow.rightKeyPressStateImage.setImageResource(2130837550);
        localSensorTagSimpleKeysTableRow.reedStateImage.setImageResource(2130837547);
      }
    }
    for (;;)
    {
      localSensorTagSimpleKeysTableRow.lastKeys = paramBluetoothGattCharacteristic[0];
      if (paramBluetoothGattCharacteristic[0] > 0)
      {
        PositionProvider.keypressSensor = paramBluetoothGattCharacteristic[0];
        PositionProvider.getSendAlarm();
      }
      return;
      localSensorTagSimpleKeysTableRow.leftKeyPressStateImage.setImageResource(2130837539);
      localSensorTagSimpleKeysTableRow.rightKeyPressStateImage.setImageResource(2130837550);
      localSensorTagSimpleKeysTableRow.reedStateImage.setImageResource(2130837547);
      continue;
      localSensorTagSimpleKeysTableRow.leftKeyPressStateImage.setImageResource(2130837538);
      localSensorTagSimpleKeysTableRow.rightKeyPressStateImage.setImageResource(2130837551);
      localSensorTagSimpleKeysTableRow.reedStateImage.setImageResource(2130837547);
      continue;
      localSensorTagSimpleKeysTableRow.leftKeyPressStateImage.setImageResource(2130837539);
      localSensorTagSimpleKeysTableRow.rightKeyPressStateImage.setImageResource(2130837551);
      localSensorTagSimpleKeysTableRow.reedStateImage.setImageResource(2130837547);
      continue;
      localSensorTagSimpleKeysTableRow.leftKeyPressStateImage.setImageResource(2130837538);
      localSensorTagSimpleKeysTableRow.rightKeyPressStateImage.setImageResource(2130837550);
      localSensorTagSimpleKeysTableRow.reedStateImage.setImageResource(2130837548);
      continue;
      localSensorTagSimpleKeysTableRow.leftKeyPressStateImage.setImageResource(2130837539);
      localSensorTagSimpleKeysTableRow.rightKeyPressStateImage.setImageResource(2130837550);
      localSensorTagSimpleKeysTableRow.reedStateImage.setImageResource(2130837548);
      continue;
      localSensorTagSimpleKeysTableRow.leftKeyPressStateImage.setImageResource(2130837538);
      localSensorTagSimpleKeysTableRow.rightKeyPressStateImage.setImageResource(2130837551);
      localSensorTagSimpleKeysTableRow.reedStateImage.setImageResource(2130837548);
      continue;
      localSensorTagSimpleKeysTableRow.leftKeyPressStateImage.setImageResource(2130837539);
      localSensorTagSimpleKeysTableRow.rightKeyPressStateImage.setImageResource(2130837551);
      localSensorTagSimpleKeysTableRow.reedStateImage.setImageResource(2130837548);
    }
  }
  
  public void disableService()
  {
    this.isEnabled = false;
  }
  
  public void enableService()
  {
    this.isEnabled = true;
  }
  
  public Map<String, String> getMQTTMap()
  {
    byte[] arrayOfByte = this.dataC.getValue();
    HashMap localHashMap = new HashMap();
    localHashMap.put("key_1", String.format("%d", new Object[] { Integer.valueOf(arrayOfByte[0] & 0x1) }));
    localHashMap.put("key_2", String.format("%d", new Object[] { Integer.valueOf(arrayOfByte[0] & 0x2) }));
    localHashMap.put("reed_relay", String.format("%d", new Object[] { Integer.valueOf(arrayOfByte[0] & 0x4) }));
    return localHashMap;
  }
}


/* Location:              C:\Users\Fabi\ownCloud\Uni_FK\4\SW_P\eo-spy-ti\classes-dex2jar.jar!\com\eospy\sensortag\SensorTagSimpleKeysProfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */